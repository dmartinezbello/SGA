<?php require_once('Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['usuario'])) {
  $loginUsername=$_POST['usuario'];
  $password=$_POST['password'];
  $MM_fldUserAuthorization = "";
  $MM_redirectLoginSuccess = "paginas/sga.php";
  $MM_redirectLoginFailed = "indexError.php";
  $MM_redirecttoReferrer = true;
  mysql_select_db($database_conex, $conex);
  
  $LoginRS__query=sprintf("SELECT Usuario, Password FROM usuario WHERE Usuario=%s AND Password=%s",
    GetSQLValueString($loginUsername, "text"), GetSQLValueString($password, "text")); 
   
  $LoginRS = mysql_query($LoginRS__query, $conex) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
     $loginStrGroup = "";
    
	if (PHP_VERSION >= 5.1) {session_regenerate_id(true);} else {session_regenerate_id();}
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;	      

    if (isset($_SESSION['PrevUrl']) && true) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
    header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
    $error=1;
  }
}
?>
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
<title>.:: SGA ::.</title>
<link href="Css/cabecera.css" rel="stylesheet" type="text/css">
<link href="css/estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0" align="left" cellpadding="0" cellspacing="0">
  <tr class="borde">
    <td align="left" valign="bottom" bgcolor="#003366" class="bordeInferior">&nbsp;</td>
    <td width="190" align="left" valign="bottom" bgcolor="#003366" class="bordeInferior"><img src="img/logo_slb_header_blanco.gif" width="178" height="67"></td>
  </tr>
</table>
<form name="form1" method="POST" action="<?php echo $loginFormAction; ?>" style=" clear:both;">
  <table width="35%" border="0" align="center" cellpadding="5" cellspacing="2" style="clear:both; ">
    <tr>
      <td colspan="2" align="center"><h2 style="text-align:center;">Bienvenido al Sistema de Gesti&oacute;n de Almec&eacute;n (SGA)</h2></td>
    </tr>
    <tr>
      <td colspan="2" align="center"><img src="img/logo-sga.jpg" width="95" height="200" alt="logo-sga"></td>
    </tr>
    <tr>
      <td colspan="2" align="center" valign="middle"><p style="text-align:center;"><strong>Version (beta)</strong></p></td>
    </tr>
    <tr>
      <td align="right" valign="bottom"><p><strong>Usuario:</strong></p></td>
      <td width="90%"><input name="usuario" type="text" class="textInput" id="usuario" style="width:100%;"></td>
    </tr>
    <tr>
      <td align="right" valign="bottom"><p><strong>Contrase&ntilde;a:</strong></p></td>
      <td><input name="password" type="password" class="textInput" id="password" style="width:100%;"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input name="enviar" type="submit" class="button der" id="enviar" value="Ingresar"></td>
    </tr>
    <tr>
      <td colspan="2" align="center">Haga click en Ingresar para iniciar Sesi&oacute;n</td>
    </tr>
    <tr>
      <td colspan="2" align="center"><?php if ($error==1){echo "<p class='obligatorio'>El proceso de inicio de sesion fallo, compruebe su nombre de usuario o contrasena</p>" ;} ?></td>
    </tr>
    <tr>
      <td colspan="2" align="center"><a href="mailto:DMartinezBello@slb.com?subject=Olvide contrasena SGA">
&iquest;Has olvidado tu contrase&ntilde;a?</a></td>
    </tr>
    <tr>
      <td colspan="2" align="center"><span style="font-size:10px;">Creado por: Daniel Martinez <a href="mailto:DMartinezBello@slb.com?subject=Soporte SGA">DMartinezBello@slb.com</a> (2013)</span></td>
    </tr>
  </table>
</form>
</body>
</html>