<?php require_once('Connections/SGA.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['usuario'])) {
  $loginUsername=$_POST['usuario'];
  $password=$_POST['password'];
  $MM_fldUserAuthorization = "";
  $MM_redirectLoginSuccess = "paginasWeb/Principal.php";
  $MM_redirectLoginFailed = "indexError.php";
  $MM_redirecttoReferrer = false;
  mysql_select_db($database_SGA, $SGA);
  
  $LoginRS__query=sprintf("SELECT Usuario, Password FROM usuario WHERE Usuario=%s AND Password=%s",
    GetSQLValueString($loginUsername, "text"), GetSQLValueString($password, "text")); 
   
  $LoginRS = mysql_query($LoginRS__query, $SGA) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
     $loginStrGroup = "";
    
	if (PHP_VERSION >= 5.1) {session_regenerate_id(true);} else {session_regenerate_id();}
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;	      

    if (isset($_SESSION['PrevUrl']) && false) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
    header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
    header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
<title>.:: SGA ::.</title>
<link href="Css/cabecera.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0" align="left" cellpadding="0" cellspacing="0">
  <tr class="borde">
    <td align="left" valign="bottom" bgcolor="#FFFFFF" class="bordeInferior"><div class="titulo"> GSA </div>
      <div class="subtitulo"> Sistema para la Gesti&oacute;n de Almacenes</div></td>
    <td width="190" align="left" valign="bottom" class="bordeInferior"><img src="Img/logo_slb_header.gif" width="190" height="88" alt="Logo_SLB" /></td>
  </tr>
</table>
<p>&nbsp;</p>
<form name="form1" method="POST" action="<?php echo $loginFormAction; ?>" style="clear:both;">
  <table width="35%" align="center" cellspacing="10" style="clear:both; ">
    <tr>
      <td colspan="2" align="center">
      <svg
   xmlns:dc="http://purl.org/dc/elements/1.1/"
   xmlns:cc="http://creativecommons.org/ns#"
   xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
   xmlns:svg="http://www.w3.org/2000/svg"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:xlink="http://www.w3.org/1999/xlink"
   version="1.1"
   width="189"
   height="191"
   id="svg2">
  <metadata
     id="metadata8">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
        <dc:title></dc:title>
      </cc:Work>
    </rdf:RDF>
  </metadata>
  <defs
     id="defs6" />
  <image
     xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAYUAAAGHCAYAAABf605DAAAABHNCSVQICAgIfAhkiAAAIABJREFU
eJztnXd4FNX6x7+bRhqBBDAJGEJoSSihGEGUFAhIUYpUywVUOgiIUhV/WPBehaso+iBeEcGCLci1
C6JUxQbSpaaSAmmkkLrJ/v7AyU3Z3ezsnjNnZvb9PM88ymb2Pe+cmZ3vKe95j8FkMplAEE5CUVER
9u/fj2PHjiErKwt5eXmorq5GVVUVampq4OXlhYCAALRv3x5RUVGIj4+Hr6+vaLcJQimKDCQKhDNw
7NgxfPbZZzh16hSqqqps/p67uzu6deuGCRMmoHfv3hw9JAhVQKJA6Jvk5GS8/vrruHDhAhx51A0G
A8LDwzF37lx07NiRoYcEoSpIFAj9sm3bNuzcuRPV1dXMbLq5uWHcuHGYMmUKM5sEoSJIFAj9YTQa
sXr1apw4cYJbGb169cLq1avh7u7OrQyCEACJAqEvKisr8cQTT+DcuXPcy+rUqRP+9a9/wcvLi3tZ
BKEQJAqEfigrK8Py5cuRnJysWJnt2rXD2rVr4efnp1iZBMGRIhfRHhAEC0QIAgBkZGRg2bJlKCoq
UrRcguAFiQKhecrLy4UIgkRGRgaWL19OwkDoAhIFQtOUl5dj2bJlwgRB4vLlyyQMhC4gUSA0i1oE
QYKEgdADJAqEJlGbIEhIwlBcXCzaFYKwCxIFQnOoVRAkLl++jGXLlpEwEJqERIHQFGoXBAkSBkKr
kCgQmkErgiBBwkBoERIFQhNoTRAkSBgIrUGiQKgerQqCBAkDoSVIFAhVo3VBkCBhILQCiQKhWvQi
CBIkDIQWIFEgVIneBEGChIFQOyQKhOrQqyBI0AI3Qs2QKBCqQu+CIJGenk7CQKgSEgVCNYjOdqo0
JAyEGiFRIFSBJAhJSUmiXVEUSRhKSkpEu0IQAEgUCBXgrIIgkZ6ejmXLlpEwEKpAV9txlpVX4Ou9
v+LnI6eRlZOHy1k5KCuvFO1Wk/h4eyIkuA2Cb2qF+Nt6YejAaHi4u4l2SxGcXRDqEhISgrVr18LX
11e0K4Tzoo89mlMzruC5197Dx1/tQ0lpmWh3HKalny+m3DMUT8y7H0FtAkS7ww0ShMaQMBCC0bYo
GKurseqlLXhlyw5UVFaJdoc5Pt6eeGLeA1g59z4YDAbR7jCFBMEyJAyEQLQrCnkFRZi84Dn88PNR
0a5w555hA/HuSyvg6+0l2hUmkCA0DQkDIQhtisL10nIMnLQIx85cFO2KYgyM7oEfPnhJ83MNJAi2
ExISgnXr1sHHx0e0K4TzUKTJ6KO5T73iVIIAAIf+OIWVa98S7YZDkCDIIz09HUuXLsX169dFu0I4
EZoTha/3/oL3dn4v2g0hrN+yA4ePnhHthl2QINiHFK5KwkAohaZEoabGhKdefke0G8IwmUz4v/Xa
u34SBMdIS0sjYSAUQ1OicOiPk/jztHMNGzVkz09HceZCqmg3bIYEgQ0kDIRSaEoUdu4+JNoFVaCV
eiBBYAsJA6EEmhKFvYePiXZBFWihHkgQ+EDCQPBGU6KQnnVVtAuq4HJ2jmgXrEKCwBcSBoInmhGF
isoqFBRSwjAAyLqaJ9oFi5AgKAMJA8ELzYhCWXkFNLjOjgvXy8pFu2AWEgRlSUtLw8qVK1Fers7n
gdAmmhEFQt2QIIghOTkZy5YtI2EgmEGiQDgMCYJYSBgIlpAoEA5BgqAOSBgIVpAoEHZDgqAukpOT
sXTpUhIGwiFIFAi7KC8vx4oVK0gQVEZKSgoJA+EQJAqEbCRBuHTpkmhXCDOQMBCOQKJAyKKqqgpP
PfWUrgTB3d0dw4cPh6urq2hXmJGSkoInnngCVVX625GQ4AuJAmEz5eXlWLp0Kc6ePSvaFWZ4eHhg
2bJlmDdvHpYsWQJ3d3fRLjHjwoULeOyxx6jHQMiCRIGwCT0OGXl4eGDp0qXo378/AOCOO+7AY489
pithoKEkQi4kCkSTOIMgSNxxxx1YtGiR7oaSSBgIWyFRIKziTIIgERsbi4ULF5IwEE4JiQJhEWcU
BIlBgwbpUhhogRvRFCQKhFn0LAj9+vWDyWRq8oiPj9edMNDKZ6IpSBSIRuhdEORAwkA4GyQKRD30
KghLliyRLQgSJAyEM0GiQNSiZ0Foag6hKUgYCGeBRIEAoE9BcHd3ZyIIEiQMhDNAokDoVhBsiTKS
CwkDoXdIFJwcPQuCrVFGco+4uDgSBkK3kCg4MXoXBJ6QMBB6hUTBSSFBcBwSBkKPkCg4ISQI7IiL
i8OCBQtIGAjdQKLgZJAgsCc+Pp6EgdANJApOBAkCP/QqDMuXLydhcDJIFJwEEgT+SMLg5uYm2hVm
JCUlkTA4GSQKToCeBeHWW2/lEnbqSLjqI488QsJAaBYSBZ2jd0FQIyQMhJYhUdAxJAjiIGEgtAqJ
gk4hQRAPCQOhRUgUdEhFRQUJgkrQqzCsWLECFRUVol0hOECioDMqKiqwfPly3QnC448/jujoaOET
yfYcsbGxmD9/vq6E4dKlS1i+fDkJgw4hUdARehYEtYSd2ktcXBwJA6EJSBR0AgmC+omLi8O8efNI
GAhVQ6KgA0gQtEN8fDwJA6FqSBQ0DgmC9iBhINQMiYKGIUHQLiQMhFohUdAoehWExx57TPeCIEHC
QKgRg8lkMol2whauFZXAv/cY0W6oAnc3F8wb2Z0EQSfs378fGzduhNFoFO0KMzp37owXXngBzZo1
E+0KIY8i6iloDBcD0LedOwmCjtBjVNLFixdpgZtGIVHQEC4GIDqkGdr46idnv7MLgkRcXBzmzp1L
wkAIh0RBI0iCcFNzEgS9Eh8fT8JACIdEQQOQIDgPJAyEaEgUVA4JgvNBwkCIhERBxZAgOC8kDIQo
KCRVpehZELSW/lok+/fvxxtvvEHhqoRSUEiqGiFBICT0HJVUWVkp2hXCDCQKKoMEgWiIXoVh+fLl
JAwqhERBRZAgEJYgYSCUgkRBJZAgEE1BwkAoAYmCCiBBIGyFhIHgDYmCYEgQCLmQMBA8oZBUgehV
EBYvXkyCoAAHDhzQZbjqiy++CA8PD9GuOCsUkioKEgTCUWJjY6nHQDCHREEAJAgEKyRhcHXVz7NE
wiAWEgWFIUEgWBMbG4t58+bpThhogZsYSBQUhASB4IUeheHChQskDAKgiWaF0LMgREdHi3aF+JuD
Bw9i48aNqK6uFu0KM7p06YIXXniBJp+VgSaalYAEgVCKmJgY6jEQDkGiwBkSBEJpSBgIRyBR4Ihe
BeHRRx8lQVA5JAyEvZAocELPgkCTytqAhIGwBxIFDpAgEGqBhIGQC4kCY0gQCLURExOjuwVuJAz8
oJBUhuhVEBYtWkSCoAMOHDiATZs2UbgqYQ0KSWUFCQKhdmJjYzFnzhzd9RiefPJJVFVViXZFN5Ao
MECvgrBw4UISBJ2hR2E4e/YsCQNDSBQcxMUARLfXlyC4urpi/vz56Nevn2hXCA7oURj++usvEgZG
kCg4QK0g+Ornx+Xq6ooFCxZgwIABol0hOELCQFiCRMFOSBAIrUPCQJiDoo/sQM+CcNttt4l2hVCY
AwcO4M0339RVVFJkZCSef/55uLu7i3ZFa1D0kVxIEAi9ERsbi9mzZ+uux7Bq1SrqMdgBiYIMSBAI
vaJHYThz5gwJgx2QKNgICQKhd2JjYzFjxgwSBieHRMEGSBAIZ2HQoEGYPn06CYMTQ6LQBCQIhLMx
ePBgEgYnhkTBCiQIhLNCwuC8UEiqBfQsCP379xftCqERfvzxR2zZskVX4ardunXDmjVrKFzVPBSS
ag4SBIK4weDBg/Hwww9Tj8GJIFFogF4F4ZFHHiFBIOyChMG5IFGog54FgeYQCEcgYXAeSBT+hgSB
IKxDwuAckChAn4Lg5uZGgkAwh4RB/zh99JFeBWH+/Pk0h0BwY+/evRSVpE+cO/qIBIEg7GPQoEHU
Y9ApTisKehWEefPmkSAQiqBXYXjqqaecWhicUhT0Kghz586lOQRCUfQoDKdPn3ZqYXA6UdCzINCO
aYQISBj0hVOJgl4FYd68eSQIhFD0LAxGo1G0K4riNNFHehUEGjIi1MS+fft0F5XUvXt3rFmzBm5u
bqJdUQLniD4iQSAIZYiPj9dlj2HVqlVO02PQvSjoURBqTMCcOXNIEAhVQsKgbXQtCnoVhLihd9Ec
AqFq4uPj8eCDD5IwaBDdioKeBWHOQ/eLdoUgmmTw4MEkDBpEl6JAgkAQ6oCEQXvoThRIEAhCXUjC
4OKin9eNnoVBVyGpehWE2KEjMedBEgRC2+zduxfvvPMOampqRLvCDB2Gq+onJJUEgSDUzaBBg/DQ
Qw/prsegtwVuurg7BgB9b9ahIAwZQYJA6Ao9CsOpU6d0JQyavzMGALe0b4YgPx0KwkMPiHaFIJhD
wqBuNH1XagWhOQkCQWgJEgb1otk7QoJAENpGz8Kg5dxPmrwbJAgEoQ/0KgyrVq3SrDBoLiRVz4Iw
myaVCSdl3759ugtX7dGjB9asWaO1hXvaCkklQSAIfSLlStJbj+HJJ5/UXI9BM3fAaDTqUhAGJgwn
QSAI3BhKmjp1qq6EQVrHoCVh0ETtG41GbHhlve4EIXbICMylOQSCqCUhIUF3PYaTJ0/ixRdf1Iww
qL7mjUYjXnjhBfz551HRrjCDhowIwjKDBg3SnTAcPnxYM8Kg6olmSRB+/fVX0a4wQxKEWdPuE+0K
Qaiaffv2YevWrbqafB4wYACWL1+u5sln9U40kyAQhHOjx8lnLfQYVFnb+hWEkSQIBCEDEgblUV1N
61sQ7hXtCkFoDhIGZVFVLZMgEARhDhIG5VBNDRuNRqxdu5YEgSAIs8THx2PatGm6E4Z169apShhU
UbtGoxHr1q3D4cOHRbvCDBIEgmCPHsNVf/rpJ/z73/9WjTAI30NOEoSff/5ZtCvMkARh5tTJUHHE
L0Fokri4OJhMJmzbtk034aqHDh0CACxZskR4uKpQudW7IBAEwQc9DiUdOnQIL730kvAeg7AaJUEg
CMIR9CgMBw8eFC4MQmqTBIEgCBaQMLBH8ZokQSAIgiUkDGxRtBZJEAiC4AEJAzsUiz7SryCMkC0I
RUVFOH/+PHJzcwEAR4/eyAB7+vRpfPfdd01+/6GHHkJAQAAAICYmBpGRkWjdurVM7/VLUVER0tLS
cPToUVy+fBkvvfSSTd8bPnw4unfvjhYtWqBTp05o3bo1unbtCj8/P84eEyyIj48HAF1FJR08eBAA
8PjjjysWlaRIllS9CkJMwnDMnPq/dQguLi4wGAz1DgC1/83IyEBKSgo++OAD5v7ExMSgb9++aNu2
LZo3b87cvtq5evUq0tLScOHChdofEiseeOABREZG1goxwZa6ryCTyVR71NTU2BXSvW/fPrz77ru6
EQbgxu9bIWEo4i4KehaEWdPug4uLS+1hjpycHFy6dAkff/yxYv7dfvvt6N27N0JCQuDp6alYuSJI
TU3F999/j9OnT3Mvq3v37oiLi0NwcDB8fX25l0fcoLq6GjU1NbJe8noUhtjYWDz22GO8hYGvKOhV
EO68eyweun+i1fHL06dP4/Dhw4q8rCzRvXt3jBkzBm3atBHmAw/Ky8uRnp6O/fv3C6vfyZMno3fv
3roX3bp8+umnQn7L3bt3x4wZMwDceKfYOsZOwmAX/ERBj4Lg29wP90y8DyOHxls8p6SkBAcOHMDu
3buVc6wJpk2bhsjISF28wAoKCpCYmChUbCW6d++OsWPH6k50LfHoo48KK/uFF16o9/xWV1fDaDQ2
+T0SBtkUcZlo1psguLq6omOnzhgybCRib+9n8byUlBSsX79eQc9sY+vWrejRo4fmX2CnT5/Gf/7z
H9Fu1HLq1CmcOnUKs2bNQvfu3UW7w5WCggKhKVuKi4vriYKrqytcXFxgNBqtvvClyWc9CcOBAwcA
3Jh85hFt5fr0008/zdKg3gTBz88Pt0RHY8DAeIuCUF5ejoMHD2Lr1q3KOieDq1ev4sCBAwgMDERw
cLBod2RRXl6O3bt345NPPhHtilmOHDmC4uJihIaGwsPDQ7Q7XLhy5Qp++eUXYeVHRUWhVatW9T4z
GAxwdXWFwWCw+sLv0KEDWrRogRMnTugmF1lqaioyMzMxYMCA2kAWRlQw7SnoTRCCg4MRERGJiB69
LArC1atXsWbNGoU9s5+tW7fC398fYWFhol2xifz8fDBut3Dh0KFDOHToEJYvX4527dqJdoc5JSUl
Ql+oRUVFFv8mCUNVVZVFH+Pi4gBQj8EWmPUU9CYIISEhCI+IQHi3KMTd0d/sOfn5+XjmmWcU9sxx
Dh8+jOjoaPj4+Ih2xSrFxcV46qmnRLshi0OHDmmibuXy22+/4eLFi8LKDwwMRNeuXS3+Xeo1NNVj
aNmyJfUYrFPBRF70JghBQUHo3KUrukb2tCgIZWVlWL16tcKeseO5555Dfn6+aDcsUlZWhm+++Ua0
G3ah9rq1h4yMDKHl79q1q8lzDAYD3N3drb4c4+LiMGXKFF2tfD5w4AA2bNjATOgc7inoTRD8/f3R
o2fPv3sIlucQPv/8c6SlpSnsHVuqqqrQqVMnuLkJ31ajHlL9SjnmtYha69YeysvL8f7774t2AzEx
MU3O2RgMBri4uFgNW5XmGE6ePKmbHkNycjKuXr2K/v37O9pjcGxOQW+C4Obmhshu3dAlsqdFQQBu
pKVgvWpWBNI1TJ6srrxNe/bs0Xz9Hjx4EK1bt0ZCQoJoVxymqKhIFS/P0tJSmxYNGgwGuLm5WQ1Z
laKS3nvvPd3MMfzwww8AgEWLFjkkDHb3ofQmCADQuUsXdO91CwYNvM3iOefPn8f27dsV9IovBw8e
REpKimg3ajl//rxN+Z+0wM6dO3HkyBHRbjjMtWvXRLsA4EZQh61IIavWiI+Px5QpU1hH7wjlhx9+
wKuvvuqQiNvVU9CjIPg2b46B8QlWBeHy5ct49dVXFfRKGb777jvMmTNHtBsoLi7WXf1u2bIFAQEB
mon2MkdOTo4qegqFhYWyznd1dW1y9XPdqCQ1XCMLHO0xyO4p6FEQTABG3TMRg2Nut3rel19+WS9h
l16OEydOIDk5WZnKtsK+ffuE1wWPY926dSgrKxNdvXaTn58vvA5NJpPsyXsXFxebVv3GxcVh6tSp
1GP4G1mioFdBGDTsbowaPsTqecnJyTh58qQyTglA9JDNuXPn8O233wr1gScXLlwQ7YLdqOW+2OOH
rakg4uLicP/998u2r2bsFQabh4/0Kgi3xQ7B9H9MbrLivvvuO7tUVytIvYUOHTooXnZZWRleeeUV
xctVkjfeeAMvvfQSvLy8RLsiC9GL1hqSl5cnK4W5FI1ky2SyFBTAI7W9KOwZSrKpp6BnQZj94P1N
TkilpKTgxIkTyjgmEFG9BZGLopREDUn85CJ3HJ839gzDyUkcl5CQgAceeEB2GWpGbo+hyZ6CswsC
cKPbqqbWEi+OHz+O5ORkRSdFy8rKsHHjRsXKE8nbb7+N8PBwTW2ClJeXp6pnPy8vT3YaEbkL1fTa
YzAYDFi4cGGTPQaroqBbQYhJwKxp98FkMjX5wCQlJeH48ePKOKcCLl68qKgoXLhwQVUvHd4cP34c
AwcOFO2GzVy5ckVV9+fKlSt2f1fOdQwePBiAvoRhz549ANCkMFh8I+paEB7834RSU6p56tQpzl6p
ix07dihWljP1EiTef/99FBcXi3bDZnJyckS7UA97/bEnrcXgwYN1N/m8Z8+eJlNimK0pZxEEwLoo
FBUV4euvvxYeiqf20D97ycrKEn6tIo5jx44pUr8s2L9/v/D6qnvs37/fruuwN9w0ISHB6YSh0fCR
yWTC66+/ri9BMAG33hHfSBAA6w9LZmamxYrTM+np6YpsUn/x4kWnrN/33nsPMTExot1okuzsbFXe
n+zsbAQFBcn6jiNrEBISElBZWYkdO3aosj7sYc+ePfD29sbMmTMb/a2RKGzfvr02jEkPmExAn9ti
MXf6lEZ/MxgMVm9yWlqabh4COSQnJyMqKoprGcXFxfj000+5lqFmsrOzERgYKNoNq5SWlqry+Rfh
14gRIwBAV8LwxRdf4KabbsKYMWPqfV5v+Gjv3r346KOPFHWMJyYA0XcMwoJZ0+z6vrO+tL7++mvu
ZWRmZnIvQ81oIcNubm6uaBfMImpOZsSIEbj33nuFlM2Lt99+u1F+rtqeQkFBAd58803FneLFjR5C
DOZN/4dd3798+bKQFsFdd92Fdu3aoVmzZgButCjPnz+veATUlStXuLZkf//9d8XrNy4uDuHh4fXq
9urVq3aPUzvCr7/+iltvvVXxcuWQkZGhylZxUlIS956sJYYMGYKqqird9BhMJhM2bNiAjRs31m4M
VSsK27Ztw/Xr14U5xxJJEB6ZOc3uG6f0fMKCBQsQFhYGPz+/ep9HRUXhzjvvRHZ2Nj799FPFxCE1
NZWbKOTl5WHfvn1cbJtj4sSJiI6ObrTHr/Ri+cc//oG//voLL730kmI+HTt2DEVFRY3ut5r46quv
RLtglvT0dNnfkSaqWTB8+HAYDAYkJibqQhjy8/Px0UcfYfr06QD+Hj5KT0/Hjz/+KNQxVkhDRo/M
tG/ISOLXX39l41ATxMfH48UXX0SvXr2sviCCgoIwffp0TJ06VRG/zp8/z822nBTIjrJy5UoMGzas
kSA0JDIyEhs2bMCCBQsU8kz8bmbWKC0tFe2CRY4fPy7cv2HDhulqKOmrr76qDfd1kT7Qg+KZTECf
/jGY+7Dty9TNhb0VFRXh2LFj3MPr4uLiMG7cOAQEBNh0vpeXF2JiYhAXF8fdt71793KzLU3g8z5W
rlyJjh072ny+l5cXoqKisHLlSkX8O3v2rCLl2HNIG+uo9ZDrHw8SEhIwceJEXWRXNRqNtQkHXSor
KxXtyvOCVQ8BuLGpiBIP9pgxY+xKkDZmzBhF/OOFEi/DWbNmoWPHjnb517FjR0ydOpW7j19++aVq
U2pL4ahqPQoKCkRXEQB99Rh++OEHmEwmuJw6dUp4V8xRTHb0EKyhxOKtJ5980u4cOM2bN8fChQsZ
e9QYR1IKWKK4uJj7vEivXr3Qr5/l7VRtITY2FpMmTWLkkWWysrK4l2EPakuE15CioiLRLtSilx5D
fn4+zp8/7+qm9eyfJgC33BGPeQ/bF2VkjsLCQq4tZQAIDg526Ptdu3bl7iMP+1IvjCd33303Ezu9
evXCxx9/zMSWJXJzc+3u0fBEbYnwGqK2+Zhhw4bB1dVV8yH9x48fd3O5dOmSaD/sRuohsBQE4H8/
CF7H7NmzHc6r7+XlhWnTpmmuiy5FdfE8WL1kg4KCMGrUKK6+qu3lJvHFF18oOhwk9/jiiy9EV1Ej
hgwZggkTJmi6x5CUlOTiotbua1OY/g47nT/DsbFfc/B+4CIjI5nY4Z3NtLy8nLnNc+fOMbdZF9bD
agMGDGBqryFqXMSWl5cn2gWbkDOEpJRYDRs2DOPGjdOsMGRlZbm4qX3s0BzSkNHchxyfQzAnDJbE
ggWjRo1C8+bNmZTRunVrrr5KER4s4R363KlTJ6Y+BwYGIj4+Hnv37mVmsy5//vkn13toD9evX1ed
T+YoLS1V5d4Uw4cPh7u7uyaHkgoLCw0ulZWVov2QhckE9O4Xw0QQzCHlj+d19OrVi5mvXl5e6N27
NzdfWac54F23kydP5vKSCA8P5+q3UllpbYX18CmvZ1TNoxwJCQma7DFUVFQYXNzd3UX7YTNSD+GR
mfwWcFVUVHCzDQC+vr5M7YWEhDC1VxfWOWZ4/4i7devGxa6jQQFNUVVVxdW+XLKzs5na4/WMqn2U
Y8SIEZg8ebJoN2Th4eEBFynfhdoxGAzo3ncAtx6CBO9JZtapI8LCwrj5ynqoh3fse/v27Zn6KyEN
0/E61JYckOU6klGjRqFt27Zc6k2tCfvqkpCQgHvuuUczPQYfHx+TW3BwsOq6rw1xdXXFY489hi5d
usBkYjvWac4e6zJ42m7VqpVm/N2+fTszWw0ZPHgwt3rw8vLCoEGDuM6H8LyHcjl69CgzW15eXmjW
rBmX6/v8888xbtw4m86VhEQEI0aMQNu2bbFx40ZV3WdzBAUF1bjwal2xwmAwYP78+Yrta8tz+Kh3
797MbXp7ezO3yQPei406dOigWftJSUncbMuF9YLF4OBgrsNvWomUGj58OB5++GHV9xjat29f7daj
R4/anBdqw2Aw4JFHHsHQoUNRU1OjSJk8U2bzEGDePQVWmTx5b4zSrl07brYBoEWLFtz8V9PqXNaL
1nx9feHl5cWt7kpLS5tMdqgWxo4dCwDYsmWLansMPXr0qHa55ZZboMbJZldXVyxZsgR33nmnaFeY
watV33DnJJawSoHCevKyIf7+/lzt83zxqClDMevgAl9fX67pwbXSU5AYO3Ys5s2bp8oeg4+PD3r1
6mV08fHxQd++fUX7Uw+DwYB58+YhNjZW8bJ5TijK3VdWDT5rwUeTycS9teju7s7Vf7XkH0tPT2d6
XZIgSHM+rA+1TdLbglqHkvr37w93d/cbm+yMHTtWsf0DmsLV1RWLFy9GXFycMB9YvgyVQu0+88x5
JHXLeRIUFMS1jouKilQxP/Tf//6XqT3pmnx9fbnUH4+kjUowduxYeHp6qmby2WAw4J577gHw934K
PXr0YJZ6wRGkSWWRgkDwgWc3v1OnTtxsOxOs5zbqijWve/TDDz9wsasEauoxREdH1wZT1G7HOXPm
TDz++OPCVMtgMGDRokVISEiweA4P3xra5JHaQSIzM5NLBJK0SQ8PWA0j8axX1kNd1srhaVt0i5F1
eou6E8y8egrAjUWRTQ3NqqF+zTF27Fi4urrirbfeEuafm5tb7VacwN89BQDo0qUL7r//fiFOubq6
YtmyZVYFQSn27NnDbdyY1x7YUmQMj4MVPOuV94pjCV7j4mp5WbHOYFv3RS2JAo+jpKREYK05zqhR
o7BgwQJhPYYZM2bUi95zqfvHSZMmKT7pbDAYsGDBAsXWIRCEvagx+RqlDuf2AAAgAElEQVRLWKeN
qBt11KJFC6a266KmkF57GTp0KGbMmKG4MAwcOBAjR46s91k9UXBxccHy5csV2/TDYDBg4cKFqugh
SPBqzZhMJuzcuVOTfjtKVlYWV/94vnAaouZ6dpSkpCSm11M3hY40lMTj0PKeMHUZPXq0osIQGRmJ
xYsXNyrPpeGJ3t7eePHFF9GnTx+uDnl5eeGZZ57BkCFDuJYjl4SEBK4/fF5JvNT+ouJZp45uWKSG
a1BDxk/WQ3wtW7asZ3/s2LFc6i4lJUVMhXFg9OjRWLFiBTw8PLiW069fPzz33HNmy2kkCgDg6emJ
VatWYejQoVwcuummm/Dcc89xFx574D1EkJOTw9U+a1iM1/PMraW2NTZahUdyuYZi3bp1a+ZlADdy
NZWVlXGxLYLbb78dq1ev5rIg02AwYMyYMVi5ciWaNWtm9hw3s5/iRgrVhQsXom/fvnj77beZPDQG
gwFDhw7Fgw8+qNrxWdYt5IacPXsWnTt3Zmqzb9+++PDDD5naZEl5eTm3OlUydxfPZ8PSD1QpCgoK
mF6bFPNeF56pQq5du6ZYj1EJoqKi8Oqrr2Lz5s04ePAgk3oLDg7GrFmzEB0dbfU8i6IgMXDgQERH
R+Pbb7/FV199hatXr8p2xs3NDXfccQfGjRvn0HwFjwfKnE2eovDee+/hrrvu4mZfjfBcuObt7c31
fjWEV1n+/v6KXkdDCgsLmZZv7r7wzNOVl5dnNSyVd2OPB/7+/li6dClGjx6Nzz77DL/88otdOeDa
tWuH0aNHY+jQoTalNGpSFIAbw0n33HMPxo4di5MnT+LQoUM4duyY1XFQT09PdO/eHf369cPAgQO5
5j9hCa8ubl1SU1MRGhrKvRy1wDPvvVLhqHqH9WStufvCc5xc7RvuOEJ4eDhWrlyJ/Px8HDp0CL//
/jvOnDkDa7tm3nzzzejbty8GDhyIiIgIWZPXNomChMFgQFRUFKKiogDcuBEZGRn1xoybNWuGtm3b
IjAwEG5ussyrAp5dXIlffvnFqURBi600c+jlOsyRkpLC9NrMNQKDg4O51V96ejoXu2oiICAAo0eP
xujRo2E0GpGVlYXMzMx6O/e1bt0a7dq1c2h43qG3dosWLRQNB1QCJX74O3bsQGxsrNO0cnfs2MHN
tpIv6YSEBG5JGkX+jkpLS/HHH38wtWlp29m+ffviyJEjTMsCbjxjWtv60hHc3NwQEhLCZatT7TXl
FUCJF83+/ftx7733ci9HDfCsTyWHJZUYWhQBjzkfSyIXGhrKXIAkCgsLdddIFYHZkFRnpm3btoqU
s2PHDk2m/VUbllqkhO3wCBm2lPGVR8tWglcaGWdDUz0FJaKPlIxmcZbeAs/61PM4v1Kw7imMHz/e
oj0PDw9u9ysjI8PikCw9J7ajKVFQAiUmmiUSExPRuXPnJuOGtQ79GNVNWloa03tUN71FQ9q2bct1
rQLhODR8ZIbx48crVtYLL7xAw0iEUFgHAlgLoLAmGI6SlJTEzbYzQaJghpCQEK55bhoeCxYsUM12
jKxhnY654aGG3cq0jDR0xPKwNvnPM837rl27FKw5/UKiYIY2bdooKgomkwl79uwRfdnc4FlvDZOu
EfKQ0luwPJqa/L/zzju5PQ9ayy2mRkgUzCAiL9PWrVvxxRdf6LbHQKgTHqvNmxJqnr8vrW+4owY0
NdFsMimT+4jnyktrvPPOO8jMzMSUKVN0MywiteB42ifsJyMjg3kd1t2G0xydO3fmdt9ycnJq9xqu
C+/nUE9QT8EC06ZNU3wIyWQy4bvvvsO7776rmx4D7/oiHIP1BkgTJkxoskw/Pz9uzwMFbTgOiYIF
IiIihJW9a9cu3QiDtaRdhHhYT87aEl3Ec8Hh6dOnudl2FjQ1fMQDS63Nm2++WWhL9LvvvoPJZMLU
qVM1PZSUm5tLw0cqRYoMY4kt6xBatmzJ7b799ttv9Ew4CPUULODt7Y2JEycK9UFPPQZCffCYlLVl
syDejRwaQnIMEgUr9OzZU8i8gp7mGGhOQb1IG+uwPFq1amVT2RMnTuT2TBQXF3OuOX2jqeEjHi8B
azbbt2+vihfPt99+C5PJhPvvv18zmxVJ8Hx533rrraq4P1rl3LlzzOvPx8fHJputW7fmdu/M7SJH
jQjboZ6CFfz8/DB8+HDRbgC4MccwdepUrruYaQ1zoYeE7Xz66afMbdraaOG56PD8+fPcbDsDJApN
MHjwYOFDSHWP6dOna+6hp6Ej9VFaWsr8fshpQPHMGvDJJ580Ko+eF9shUWiCrl271g5TqOVYsmQJ
fvvtN9FVYxO864KwDxHpLeri7u7O9bnQ6hycGiBRsAHRUUjmWLNmDXbv3i3aDUKj5OXlMbfZtWtX
m89t164d8/LrUlBQwNW+niFRsIHw8HDV9RZMJhNee+01bNy4UfWtIuolqA/WK5lNJhM8PT1l+cDz
N8VD9JwFEgUbGTNmjHARMHd888032Lp1q6qzQ/K8fsI+rl69yvxe2BqOKtGhQwduzwVtuGM/FJJq
o81OnToxL5sV33zzDb755hts2bIFbdq0Ee1OPXi/uEkY7OPjjz9mbtPWcFSJ0NBQ5j5IpKam1vOF
GhG2Qz0FG/H29saaNWuE9wysHQ899JDqegzUS1AfOTk5XO5HixYtZPkh7dfM4/joo4841Z7+IVGQ
Qa9evTB58mThL39rx4MPPkjCQFilpKSE+X0YMWKEbD+k/GK8jsLCQg61p39IFGQyevRo0S40iRqF
gVAPV69eZW7TnpX2PLOlArThjr2QKMikRYsW+L//+z/hPYKmjmnTpqlGGKinoC6kjXVYHnLCUSV4
7tdsMplw+fJlDrWnf0gU7KB///7o16+f8Bd/U8fUqVOFCwMJgvo4ceIE83thS3ZUc4wYMYLb85Gf
n8+45pwDij6y0+aMGTPw66+/MvaGPVOnTsXLL78sbNOgc+fOcbPtiDhcv35dVWGLLVu2tGmDGhbw
eG7tTXDHM8HjxYsXa30S3ZAwmUwwGAzCypeDpkRBTbRr1w7//Oc/sXLlStGuNMnixYuxfv16YcKg
xlb9tWvXMGPGDNFu1LJ582ZFRIHHnsyAbTuumSM8PJzb8/H111/jkUce4WJbz9DwkQP07t0bCxcu
FD5MZMvx6KOPChlj5X1davVLyWuRQ1FRERff7c16ynO/ZpPJxGVSXe+QKDhIbGwsRo4cKfyFYssx
ffp0xYdM1PwiFX0/WF2HHK5cucLc95EjR9rtT/PmzbnWK0UgyYdEwUF8fHxw7733inbDZt59911c
v35dtBuEIFJSUpjbdGRewN/fn6EnjaGegnycfk6BRSutTZs22LhxI+bOncvAI7589dVX6Ny5s12L
jeyFZ0vYEdtKttBtQQl/tm/fztxmRESE3b57e3tzve709HT079+fm309oqmeguguvrUjLCwMr7zy
inA/bDnWr1+PY8eOCfeDDmWPa9eucbHbrFkzh75/3333cbtmHuG39hxaQlOioHYiIiLw6quvinbD
JpYtWyZ8DQOhLLzG11u3bu3Q92+66SZGnjTml19+4WZbr5AoMCYiIkIzPYYPP/yQe31ImTPV2PoS
Xf9KtyTT09O5+O5oKK2/vz/Xus3IyGBUg84BiQIHIiMjNdFj+Oqrr3Ds2DGuZdx8881c7RO2w2uF
r73hqBI8ewrAjTBcwnZIFDghCYPoFmhTx9KlS7mHqaqxhS263llei61IK3xZHnfffbfDfvFMoW0y
UbZUuZAocCQyMhIbNmwQ/rJp6ti5cye3OlDzi1R0vbO6Dlv54osvmPvdvHlzh/3inUL7r7/+YlB7
zgOJAmciIyPx2muviXbDKh988AEuXbok2g2CI7zi9VmlThkwYAATO+b44IMPuNnWI5oRBdEtOUcO
KSpJtB/Wji+//FK4D3TwO3ilt/D09GRiJywsjOv1FxcXC61/LaEZUdA63bp1U/VQ0hdffMEtN5Ja
f2yi61zJl8bVq1e5+O1oOKpEhw4duNYvpdG2HRIFBenWrZuqh5J2794t2gWCE7zG1Vntnubp6cnE
jiUo3YXtkCgoTLdu3bB9+3bhLVNzx/vvv4/09HSm16vW1rXoumZ9PU2RlJTExWdHw1EleE82FxQU
MPHTGSBREEBgYCA+/PBD4S8hc8fPP//M/HrV+iIVXdesrqMpSkpK8NNPPzH3edSoUcx89PX15Vq/
SUlJzHzVOyQKgggMDMRnn32G0aNHi3alHps2baJWlc7gdT9Z7prGO1vqO++8w9W+nnD6LKki8ff3
x8yZM2Ey3ZjoVQvJycnMfqRKtITtRa1+sSYnJ4fLtYaFhTG1N2rUKG6/A5PJhLy8PLRq1YqLfT2h
KVHg8WCLfjH4+Phg5syZ8PPzw3vvvSfUF4m9e/eiT58+zOzxquN3330XDz/8sF3fVZtY8fQnPz+f
i20pOyorpF3YeGAy3VjZHBAQwMW+nqDhIxXg6+uL6dOnY8mSJaJdAXBj5SsNIekHHhvrAEBISAhT
e5GRkUztNSQ5OZmrfb2gqZ4CD9TUWrzrrrtgMpnw73//W7QrSE5OZhZZwrOO7bVtMplQU1MDg8HA
2CP74dmj4oGUs4gVLVq04PqsUKp423B6UVAbUoKxdevWCfWD1RASz2ERo9FYa7tuGeY+a0h5eTlS
U1MBAAaDofZwdXWtPVxcXGr/393dHW5ubnBx4dO55lVH0sY6PGCd3VTar5kHJpMJp0+f5mJbb5Ao
qJBBgwbh/Pnz+Pzzz4X58Pnnn2P27NkO58pnQVVVFSorK1FZWQmj0YiqqqpaQaiurnbYfl3hasqe
q6sr3Nzc4O7uDnd3d3h4eMDDw4ObWDhKcXExF7u33347c5u8x/u3b9+OZ599lmsZekBToqDHiWZz
eHt7Y9asWTCZTEKFISUlBd26dXPIhtyegtFoREVFRa0IVFZWWv2+I8NH9lBdXY3q6mpUVFTU+1wS
Cg8PDzRr1ky2UPDqUaWlpXGx26lTJ+Z2ee7XLNnNyMhA27ZtuZShFzQlCs6Ej48PZs+eLVQYLl26
5LAoBAYGWvyhm0wmVFZWoqKiovZQo0jbgtFohNFoRFlZWe1nbm5u8PT0hIeHBzw9PeHq6qq4X7xE
Ydu2bdi2bRtzu7yQ6qCoqIhEoQlIFFSMj48P5syZAwBChOHKlSsO2/Dw8Kj375qaGpSXl9ceLIZ/
7CEsLAwXLlyQ9Z3169dj48aNNp9vNBrr7Yvs4eEBLy+vWqFQAtqKsj6ZmZnM0n3rFRIFlSOyx7Bt
2zbMmDHDYTtVVVUoKytDeXl5k8NBekYaDissLISrqys8PT1rD17897//5WZbi1BYatOoc3aMqIev
ry/mzJmjSA6ehoe96xWkkM+KigpkZ2ejsLBQ08NDrKmursb169eRl5eHzMxMVFZWoqamhmkZV65c
EfLMqPUAgN9++41pHesREgWN4Ovri+3btytebl5enqzza2pqaidja2pquItAZmYmV/tKIAloTU0N
jEYjqqurmdRbbm4uA+/0xY8//ijaBdVDoqAh2rdvj9WrVyvausrOzm7SL0kIjEajIkJQl4ZRQHrA
ZDLV1qcjAlFQUCC8da6mQ4KGkKyjqTkF1i8bk8mk2vhySwwZMgR//vmnYmPFlqJXpB9aU0MeLDZ2
bwolRYgnlupZWnld97CFM2fO6KZuWMJzQZ8e0NYbkQAATJkyRbGyGm7R2XB4qCkoKyUbJHGQ6t6W
l9rWrVv5O6ZBaGtO6zi9KIju0tpzBAYGYvny5YqUtXPnztoXkojhIaIxJpOp0bxNw6OkpET4c6q2
Q+LEiRMC7576cXpR0CoDBw7k/iOqrKzEtWvXbO4ViODatWuiXRCGJNbmeg5Sumw6GouCnLUmzgiJ
gkbx9/fHihUruNiuqKhAfn4+8vPzUV5ezqUMVtBQwA0kcZDEmzaqtw6vnFB6QFMTzTzJzs7mtutT
x44dMWTIEOZ2Y2Ji8K9//YuZvcrKSly/fh1VVVX1Pnd0x6rBgwdTKKBCmEw3hpaSkpJQXV2tuUAK
pcjLy1MkCEKLkCj8TVVVFbZs2cLF9kMPPcRFFPz9/bFgwQJs2LDBITvl5eUoKyuD0Wg0+/fi4mKH
RCEiIoJEQWHS0tKQm5sLT09PeHt7C8m7pCYaDq9lZ2ejQ4cOYpxROZoShYY3lqVN3mPTPHwHgK5d
u9r93YqKCpSWlloUA4mGY7Jqgtf+w0rDuo6lcXMpxxSJQ31yc3N18dzwQFOiwBNpoY/WCAsLk+13
RUWF1Z6BlsjKyhLtguowtwpdEodmzZo5pTg0/I1cvHhRkCfqhwYc68Ar6uHtt9/m5nNAQADuuece
m/yoqKhAQUEBiouLFRWEnj17KlYWYX3byYbPgOiIIBHRRwBFIFmDREEHNLVtptFoRFFREYqLi+1K
VZ2UlGSva9yxN2GfnrElH1RFRQUKCwtRWlqqyR4yC+Tm9XIWSBT+RslWCmsCAgLMlimJQWFhYaOI
Ir3w4YcfinZBdaSkpNh0nslkQllZGQoKClBWVia8Ja/074/CUs1Dcwp10GqL6aabbqrnu/RjV0uy
ON577xL1+f3332WdbzKZUFpaivLycnh5eSm2AZCSmPttJyUlUQSSGTQlCjxe2koJAc9yJNsm0415
g/LycublOWKvRYsWDD1pTGZmJoKDg7mWAfC/h6zs2xv+W1NTg+vXr6OiogJeXl5wc9PU60E2KSkp
mm0I8kTfd90GGrawlSiHNf7+/rViwCMdRVhYGHObLFFLj0gN2Dp0ZA2j0Yji4mK4u7vDy8tLFwvg
zP3+UlNTBXiifrR/twn4+PigtLRUtfmJeHfRCwsLudrXEizroqqqCsXFxVx6nmrgo48+Eu2CKnH6
noKEEhPCrNGizzyg/Ef/o2Gqc0cxmUy1e2t7enrC3d2dqX3RZGVlKTL0qCWop/A3gYGBXKMfWL64
TCZTvRTWWoiiuPfee7nZZjFkohd4LcqqqalBaWkpSkpKarOyau0wB/UyG0Oi8Deenp5c7ZeUlDCx
Y24/Ay3EW/v7+3OzTWPD/+ONN97gar+6uholJSW6GVKiFfGN0ZQoiG5pOHI4GgdeN2++ra0gNdU7
zy76Rx99JKylyQoW/hUVFXH1sS6VlZUoKSlBZWWl8N+WI/fvxIkTmn92WENzCn/D++ZlZ2fblbzO
Fr94d4FZbKnZunVrBp5YxtH03nqAZ4/x22+/tfg3g8HANUJp3LhxDtuw9Bs6e/asw7b1BonC34SG
hop2oRG2RhPxnmhlkXee9wK2nJwcpxeF5ORkbrZtiSAzGAwwGAzMy54xYwY2b97M3C4A7N27l4td
LaOp4SPe8Ow+njp1SpYfag0vtRfeC9jUnJ9JKXJzc7nYnTt3rk3nSc8t6x63r68v1+EbClSoD4lC
HXiKwltvvWVT+fb8qHg+1La+EJqC91oFuakd9MiZM2e42O3cubOs81mLQ/v27bmO61MEUn2cXhSU
mGSSjqysLIt/c+RHtHbtWsa1wodBgwZxs/3RRx9pIjSXJ7wWY9k79MfqdxMUFMRVFDIyMuytGl2i
KVHg/dKeMWMGV/+vXr1qVRDsOXhPlLH6QZpMJoSHh3P19dKlS9yfEV446pct6bLtxZE1PDU1NQ49
3yaTifteyhcuXNDsc8MDTYmCEvB8MC5cuGC2LEc4ceKEQ99vCpZRQ7w32zl69ChX+2qGZzgqiwl8
R551Fg0Ta2zatMkuv/QKiUIdOnbsyFUUnn32WeTn5zNtPaxevZqJHUu0bduWmS3eEUjr1q1z2iEk
nj0Fli11e5/7CRMmcBUGZ31uzEGiUAfeIY3V1dU4duwYM3vnzp1jZssSfn5+zGzddNNNzGxZgtdk
q9o5efIkF7tz5sxhbtOeRlHLli2Z+1EXLWQFUAoShTpIm9WwPmpqalBVVQWj0Yj58+cz8/fnn39m
ZssSLFciK5F47N133+Vehhrh1UCQG3kkBzni0L17d649hStXrrC4JF1AolCH0NBQ5oJgNBpRVVVV
b93BN99847CvKSkpWLduncN2rMGjlbh06VLmNuuyd+9ep1yQxOualVgQaMtL29KWsywEAQDS0tJY
XY7mIVFoQHx8PBM7Uu/A3CK0JUuW4Pjx43bbLi4uxsiRIx1xzyZ4tOy7devG3GZD5s+f71D9ag2e
61QCAwO52W6ItZc3y2FMc1BivP+hKVHgOQksHX379nV4qMhoNKK6utrqtdx3333IzMyUbb+oqAgv
v/yyIvUdEhLCvH5DQkIU8d3e+rV05OXloaCggJu/jviWnZ3NzS9HW+j2/H7MhbCy6MVbY9OmTVyv
S0toShR4wPLhq66urs1kagtDhgxBYmKizZEPWVlZWLFiBT7++GNHLtlm2rdvz9ymkhuarFmzxuG8
UCkpKUhMTERMTIxi9S4XnpOkvNcIWMLc7ys2Npbri5k2a7qB04tCQ+x5adVNay2X1atX47bbbsO+
ffuQkpJi9sFMSUnB1q1bMWTIEOzbt092GfYQHx/P7QXOe15BYt++fYiJiUFiYqLsH/zx48fx7LPP
4q677uIe9usoly5d4mKXx5ySI0RERHC1r2TqcTVDWVIb4OfnZ/PLnWXXsGFU0uTJk4W2THmmpOjT
pw832+ZYvXo1Vq9ejWeeeQatW7eGv78/WrRogWbNmgG48TLIyspCSkoK0tLSVNsjsASvxVedOnXi
YtdewsLC7P692ZJgMiUlhXuOLi1AotCAoKAgxMXFNdki5z1OKPrFxHP1cceOHbnZtobaW/z2wHPI
Q22pyFu1aoWamhou6bkBypYqQcNHZrAU2aPViSN7YLmSuSHNmzdXbAhJ7/Ac8lAy8sgWJH/k/gZt
PZfCUm9AomCGPn36aD6CwBGWLl3KfYJR6SEkvcKzdcs7DFQuDXsurCN/RPfO1YKmho+UejEHBQUh
Pj5esUldtdG7d2/udS1qCEmt2Nvw4Lnbmr+/v6oaQ76+vtzLyMzMVDRCTo1QT8ECEyZMEO2CMHr1
6sW9DF9fXzz99NPcy9E7vIY8Zs+ezcWuo/D2iyKQSBQsEhUVJdoFIfBOnVGXwYMHK1aWXvnkk0+4
2FVra5lnLiaAVjYDJAoWCQgIwKRJk0S7oTj9+/dXrKyAgADqLTgAzxcYy300WOLl5cXVPq9ss1qC
RMEKw4YNE+2Cojz99NPc9zxoCPUW7Ofq1avcbKs1Xp+3X0qko1c7mhIFnrlJzB28u6pqY9CgQYrX
sb+/vy7XD9iD3LrjuUahefPmij8Lthy8o+L27dvHxW8toSlRUJqAgABs3rxZtBuKsHr1asV7CRLU
W7CPU6dOcbMt6lloCiX8Sk1N5V6GmiFRaIL+/fs7xdzC8OHDhZUdEBCA1157TVj5WoXXUIdaI48k
ePtXWFjI1b7aIVGwgalTp4p2gSuJiYmKxIBbIz4+3inElxUlJSXc1tEEBQVxscsK3v5lZGRwta92
SBRsIDQ0FGvXrhXtBheWLFmC8PBw0W4AaJwUkLAMz3TZao08kuDtH6+ss1qBRMFGYmJiRLvAnPj4
eIwfP160G7UEBATggw8+EO2GJuC5sU5YWBg32yzgvYbizTff5Gpf7ZAo2Iivr6/uXlhPPPGE8GGj
hkRFRemunnmQnp7OzbaojXVsRYmcTCUlJdzLUCuaEgXR4XA9e/bUTfjkrl27EBQUJLxOLdWzs008
y60jngvXpJxHaj2UmPPIzc1l6rOW0JQoqIHx48drPkx1165dqk1jIBEXF6cbAebBf/7zHy52Z82a
xcUua3gHJVy5coWrfTVDomAH/fr1w/vvvy/aDdlMmjRJE4IgoQcB5gHPRWtaeTZCQkK42uc5PKd2
SBTsJCoqCp9++qloN2xm7dq1WLVqlWZ+9BL9+vXDrl27KFy1Djk5Odxsqz3ySIJ3ugtnToxHouAA
4eHh2LVrl2g3rBIXF4cvv/xS6OI0RwkODsaqVat0GRY8adIkrF27VtbWlzwjj9S+RkHC39+fq31e
w3NaQFOb7KiR4OBg7Nq1C7t378ZLL70k2p16PP744xg/frzqIozsZfjw4ejXrx/27t2LZ555RrQ7
dhEXF4f4+Hh06dIFHTt2tOveONNua5Zo0aIF9zLy8/NVm+6DJyQKDAgODsa0adMwatQoVbyw1q5d
i169emluqMgWAgICMH78eAwaNEgVdd0UkyZNQnR0NMLCwtCmTRsmLxme491aeWZCQ0O5l1FcXOyU
omAwaSReqrq6GqdPnxbthk2UlJTgyJEj2LFjB/bv369ImY8//jh69+7tdJsDlZSUICkpCceOHVNF
T+3xxx9HaGgoOnTooMiLi9AGPXv2hMFgEO2GLRSRKHDmxIkTXF5YEydORPv27REREYHOnTs7ZYvG
HKmpqfjrr79w6dIlruPCs2bNQqdOnRAQEIDAwEC0atVKN8N0BHtIFDigVVGoS1ZWFnJycpCZmVkv
v0pBQUG9SCZzseI9evSAv78/2rRpo5kuvhooKSlBXl4eCgsLUVBQYDbddF3xiIuLq80FFRQUVBuN
4+XlhcDAQDRv3pwEmJANiQIH9CAKBEE4J1oSBQpJJQiCIGohUSAIgiBq0UxIqhYTSxEEQWgN6ikQ
BEEQtZAoEARBELWQKBAEQRC1kCgQBEEQtZAoEARBELVoJvoIAEUfEQRBcEZToqBWsnOv4VxyBtKy
cpGWlYPEXYfr/T3u1u7o2qEtont0Quf2wQhoIS5HTp9xj5v9/L+vr0Bo2zaqta1FqD4ILUKi4ACp
mTn4ev8RvPXp91bP2//7aez//XTteU/NnYg77+gNX29PJdwkCIKwGRIFOzl5PhVTV2yw67vPvfEp
/kq6jEVT7iZhIAhCVdBEsx04IggSibsO493P97FxiCAIghEkCjIpKS13WBAk3vr0e6Rm8tuEnSAI
Qi6aGj5SQ/RRUrr1TdO3/WsBwm4OrB0WOnk+FdNWvmbx/D9OXZFGJLgAAAzmSURBVET74NZMfbQH
nrmlKG9Vfag+CDVDPQWZHDubYvFvO19bjp5dQ+vNE/TsGopv3lxl8TvZuddYukcQBOEQJAoySc/O
Nfv5hGEDLIYZBrVuiQnDBpj92+bEPcx8IwiCcBQSBZk0XIMg0bK5j9Xv3dKtEw93CIIgmKKpOQU1
szlxD6aOibcYYtr2Jn/MmDBEYa8IgiDkQaIgkwnDBljsLfx09CyGDext9m89u4aiZ9dQu8rMzr2G
42dTcCk9u9Fw04wJQ9ApJAi9IjogqHVLu+xLlJSW46ejZ3HkzKV617h42ij0juhgt/+W6Dt+idnP
d762vN5QXGpmDu5Z8KLZc4/u+Ldsu6mZOTjwxxms3/Zl7d8WTxuF2OhujYYAT55PxbGzKTadK4eS
0nIcPZOEz77/BQf+OAPgxr2MuSVSVj3b8mzc2rOzzavoLdWdVM+pmTk4cvoSziZnIHHXYbP1L9Xv
kdOXLF5bU+VYQo3XqzdIFGRyS7dOFkVh5fr3AcCiMMilpLQcO/f8Wu+F1JC6P4wZE4bg3pED7Uqj
cTW/0OKLVyp/xoQhVntDWuCz73/Bmk2JjT5fv+1LrN/2JVbNmYBxQ29DSWk5Nrz/tdl73fBcezBn
e3PiHmxO3IMJwwZg4T/uslrPcp+NVXMmOLyKftehY7XPuCUs1a90bdIzJBe1Xq8e0ZQoqCGMLzys
rdW/r1z/Po6cuYT774pxuCX52gffWBQgc0g/vO/fXi1bGGav3mST/e6dQxAb3U2WbbkhmA3Pt/Zd
OXYb9g7MsWZTIrw9m+HoX0lN1r10rtxGwNf7j1i1nbjrMPpGdrRo155nY82mRJxNzsCCB0ba9aL8
7eQFsy/IuvX/+6mLZgWhLpsT96DjzYEW/27ufqr1evUKTTTLJLRtG/zz0QesnpO46zDGLVyLNz7a
hfzCErvKOXqm6ZeSJT7+9ie7vmcLP/15lptt3qzf9iVmTBiC9Ssewqo5Eyye98QrHyBx1+HacxdP
G2X1XLnYEnH2xCsfWHx27H02EncdxtEzSbK/BwBznn7T6t9LSsstnhMb3Q3/fPSB2t+N3DpT4/Xq
GU31FNTCHX0jrM4tSEgt91VzJiDu1u42t95LSsux+IV3zP5t09OzEdnxZvh6e+L3UxfNPrybE/dg
ZGxf2T2VzzYsqx1zH7dwrdlzEncdxsqZ42TZVQszJgzB3HuH1f67VcvmFut58bRR+Meo2Np/+3g1
s9gKzs69Jns+Z+s/H0HPrqE4n5KJ+5asN3tOxpW8Rs+MtWdj/YqHantxlp6NxS+8g/3vPsd8CDDz
ar7Fvy2fcU9t/fSK6IC75jxvs121Xq+eoZ6CHfh6e2LBAyMtrj1oyJpNiRg6/RnsOnQMJaXlTZ5v
6Qc2YdgA3Nqjc+0DfmuPzhZbvHJbSP989IFaEbGlN6RFonvUDwvu0aW9xXP79exc7999u3W0eG5F
ZZUsPxZPG1U74dq1Q1uLPZGLaY1Xz1t6NmZMGFJvWO/WHp0t2k2+fEWWvw2Jje6GGROG1IumS758
1ey5i6eNqieY1tbsmEOt16tnqKdgJ77enlg5cxz6Rna0uTv8xCsfIDa6W72Wkzks/cDu6BPR6LOb
g1qZPVfuSumIju2s/lsP3BTQot6/rfXcmnm41/t3q5bNmfnRMK2JpXkqc/fQ0rPRvXNIo88s2b2Y
lm1XJNmEYQMwe9KdZustycKL11wKlzv6RNg8HKTW69Uz1FNwkGEDe+PrTU/a3Io48McZ3DXneZw8
n2rxHEs/MC9Pj0afNXzRSdBKabawHH5o2CCQcw8tPRvmhgot2bUntUpsdDcseGCkxRfk+ZRMs587
Giat1uvVM9RTYEBQ65aYe+8wDOwbgS2f/Vgbm22NB594HV9velLWj8bcQ9+qZXN8tmGZLH8JsTTs
hWiBe4b0tyqMlp55c9eqhV3nmrpePaMpUVB7OFiPLu3x8vIHceCPM3jsxa1Nnv/i5p14efmDjT63
1spvWAc+Xs3g49XMpnObwtbz7bkPavFFbmgsj3PlnN/wPEvPhqXAAHNsTtyDOZPvtPl84MaL3N7f
nyP1qMXr1To0fMSB2Ohu2LftWTw69W6r5x3444zVYSSCIAilIVHghK+3J/4xKhbvPD/f6nnHz5Eo
EAShHjQ1fKQGLI2d+vv5mI1w6Nk1FG+snoW5z/zH7PeOnkmqFw9PEPYw/s7bmszUqyec7XqVhERB
JpbmCqaPT7AY9nZrj85mPwcsiwxByOGBu2NVsYOfUjjb9SqJpkRB7RM/1vybPj4Bb+/4wabvWTr3
WlEJQhqsS8gvLMHpi+lm7cbcEtmUy/V84JFvyJxtUb7I8YPXuebOl3N9lp4N3lt82mvf3Pf0fL16
QFOioGbe3vGD1QgHS3Hc4++0PcvmteLSRp+VlJZb7L38/on5rKeEWK7kXbOplStH1FMzcxrZzM69
hv/+8Fujc6X5LlGkZuYwsaGV69UaJAoysdbiP3k+1ewQUlpWLg4e+cvsd24ObLwi2dxqTQAoK69s
9NmVPPMLc+S8UAhlKa+onxbD0kuya4fGK3QtPRt514obfZaTX2j2WZ0+PsEWN2Vh6Xdh7uVt7jm2
hFqvV89Q9JFMrKX9fXjVRpw8n1qb36iktBwnz6di/KJ1Fr/TK7yxiFha0PbdoT8bfXbktPkcR3LT
W6uJwuLrVv+tdRqKgLkXHGD+ObD0bDz/5o5GebUupZtfDWztGbYXSwu9zGXVNfccW0Kt16tnqKcg
k4ZJ1Rry8KqNsuyFmXlgu4QGmz334JG/cPDIX+gTGQYA+PnPcxZ7LZ1CtPtD+OnPc/V6XD/9eU6g
N+x59b2vMTahH3y9PVFSWo7n39xh9jxz9zC4jb9Fu3sOn8CQAVG1GXQt2Y0y0xBxFEt5h3bs/gV9
Izvi9j7htT5a6jWbQ63Xq2dIFGQS0MIXT84eb/EBlMOWNfMstrBeXv6g2bkCW1ZKj7/zNuZbZ/LA
0pCD9Fn3ziE4fTHdovBpmde3f4s7+kRY3Z/CXIPB19vT4rPx/Js7mnwun5w93uF8ROboFBJkucxX
t9ttV63Xq2do+MgOhgyIkjVBbI7nF91v9cUdc0uk3WXMmjjUXrcU5ZbultNRv73jBzz24lZdCsKT
s8djx+5f8NiLW7Fj9y9mz3l5+YMWGwx9IsPsejbG33kbhgyIkv09Wwho4YvnF91v07lyx/jVeL16
RlOiIIWJiT58vJph/n3DsWbhfbKvIeaWSHywdhGG3h7VZDnz7xuORVPustn2w+MGY9dbT8Hfz8ei
TTl1K+dce86P7t7Jpuvb+H8zufnN61xr5yfc1hPjhva3+PcnZo3DwL4RTT5/cp6NNQvvw/z7hsPH
q5nVZ07uNdY9BvTuiofHDbbqxxOzxmFETB9Z5aj1euUcWkIzw0eurq4wGAyqqWBfb0/ceUcv3Nqz
My6lZ+NccibSs3Px2fe/1jtv3ND+aNncB907h6BLaLCsrqyvtyceuDsGCbf1xIlzqUi6fAVbPvux
3jkPjxuMjjcHIio8VJPd5AfujkGv8FAcP5eKV9/7uvbzcUP7145FW9vStKDoOvz9tLWy1dfbE4/c
PwIRYe1q54mAG/dyYN8Iq5v/1LVh67Nxa8/OitSRr7cn5ky+EwP7RjS6n4um3IV+PTujS2gw0rJy
7bKttuu1FTc3NxgMBtFu2IzBpJa3rA0cP34clZW2h7MRBKE+0rJyMeHRf5v9228fv6CwN/zx8vJC
jx49RLthK0WaGj7y9HTO/OYEQWgXrb23NDN8BAD+/v4oKioS7QZBEA3Y9PFus5+PTejXaFjT0p7W
el1w6e9vOaxWjWhKFFq2bIm0tDTVzCsQBHGDC6lZZtcfDOwb0UgULO273Leb5Wg0reLi4oIWLcxv
E6pWNDV85OHhgdatKTMiQagNS638r/YfqbfyuKS0HKs2fGj2XEsL4LRMYGAg3Nw01fbWVk8BAIKD
g5Gbm4uamhrRrhAE8TfSKvuGfPb9r/js+19rQ1UbRgzVJbxDW12NAri6uiIoyPKiPrWiqegjifz8
fFy8eFG0GwRB1OG/P/yGf721067vvv/iQovpXbSIwWBA165dNTd0BKBIk6IAAOnp6cjKyhLtBkEQ
dTh45C8sWfeuzefH3BKJhf8YqbsNc0JCQhAcrEmR064oAEBOTg5SUlJ01eUkCK1TUlqOs8kZOJec
ictX8swu6Azv0Bad2wfZtFBPS7i4uKBjx44ICAgQ7Yq9aFsUAKCkpARpaWkoKbG86pUgCII3fn5+
aN++Pby9vUW74gjaFwWJwsJC5OXl4dq1azAajaLdIQjCCXB3d0fLli3RqlUr+Pn5iXaHBfoRBQmT
yYSKigpUVlaSOBAEwQV3d3e4u7trbrWyDRQZTCZTsmgvCIIgCFVQ9P+xMUMCkmy91AAAAABJRU5E
rkJggg==
"
     x="0"
     y="0"
     width="189"
     height="191"
     id="image10" />
</svg>
      </td>
    </tr>
    <tr>
      <td colspan="2" align="center"><p>Bienvenido al Sistema de Gesti&oacute;n de Almec&eacute;n (SGA)</p>
      <p>Version (beta)</p></td>
    </tr>
    <tr>
      <td colspan="2" align="center"><span style="color:#F03; font-weight:800;">*** Los datos ingresados no son validos, por favor intente nuevamente ***</span></td>
    </tr>
    <tr>
      <td width="19%" align="right">Usuario:</td>
      <td width="81%"><input name="usuario" type="text" id="usuario" style="width:100%;"></td>
    </tr>
    <tr>
      <td align="right">Contrase&ntilde;a:</td>
      <td><input name="password" type="password" id="password" style="width:100%;"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input name="enviar" type="submit" class="button der" id="enviar" value="Ingresar"></td>
    </tr>
    <tr>
      <td colspan="2" align="center">Haga click en Ingresar para iniciar Sesi&oacute;n</td>
    </tr>
    <tr>
      <td colspan="2" align="center"><a href="mailto:DMartinezBello@slb.com?subject=Olvide contrase&ntilde;a SGA">&iquest;Has olvidado tu contrase&ntilde;a?</a></td>
    </tr>
    <tr>
      <td colspan="2" align="center">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="2" align="center">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="2" align="center"><p style="font-size:10px;">Creado por: Daniel Martinez <a href="mailto:DMartinezBello@slb.com?subject=Soporte SGA">DMartinezBello@slb.com</a> (2013)</p></td>
    </tr>
  </table>
</form>
<p>&nbsp;</p>
</body>
</html>