// JavaScript Document
function Buscador(){
var xmlhttp=false;
try {
xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
} catch (e) {
try {
xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
} catch (E) {
xmlhttp = false;
}
}
if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
xmlhttp = new XMLHttpRequest();
}
return xmlhttp;
}

function Buscar() {
var Texto = document.getElementById('sp_Productos').value;
var Resultados = document.getElementById('resultado');
ajax = Buscador();
ajax.open("GET","com_obtenerProducto.php?q="+Texto);
ajax.onreadystatechange = function() {
if (ajax.readyState == 4) {
Resultados.innerHTML = ajax.responseText;
}
}
ajax.send(null)
}

function Conductor() {
var Texto = document.getElementById('Con_Cedula').value;
var Resultados = document.getElementById('conductor');
ajax = Buscador();
ajax.open("GET","com_obtenerConductor.php?q="+Texto);
ajax.onreadystatechange = function() {
if (ajax.readyState == 4) {
Resultados.innerHTML = ajax.responseText;
}
}
ajax.send(null)
}

function Vehiculo() {
var Texto = document.getElementById('Veh_Placa').value;
var Resultados = document.getElementById('vehiculo');
ajax = Buscador();
ajax.open("GET","com_obtenerVehiculo.php?q="+Texto);
ajax.onreadystatechange = function() {
if (ajax.readyState == 4) {
Resultados.innerHTML = ajax.responseText;
}
}
ajax.send(null)
}

function BuscarLote() {
var Texto = document.getElementById('Rec_Lote').value;
var Resultados = document.getElementById('lote');
ajax = Buscador();
ajax.open("GET","com_obtener_lote.php?q="+Texto);
ajax.onreadystatechange = function() {
if (ajax.readyState == 4) {
Resultados.innerHTML = ajax.responseText;
}
}
ajax.send(null)
}

function Ingeniero() {
var Texto = document.getElementById('Pro_Usuario').value;
var Resultados = document.getElementById('ingeniero');
ajax = Buscador();
ajax.open("GET","com_obtener_ingeniero.php?q="+Texto);
ajax.onreadystatechange = function() {
if (ajax.readyState == 4) {
Resultados.innerHTML = ajax.responseText;
}
}
ajax.send(null)
}