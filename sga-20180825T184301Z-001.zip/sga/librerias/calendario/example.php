<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
<link rel="stylesheet" type="text/css" href="./jquery.datetimepicker.css"/>
</head>
<body>
  <h3>Fecha y hora</h3>
	<input type="text" value="" id="datetimepicker"/><br><br>
</body>
<script src="./jquery.js"></script>
<script src="./jquery.datetimepicker.js"></script>
<script>

$('#datetimepicker10').datetimepicker({
	step:5,
	inline:true
});
$('#datetimepicker_mask').datetimepicker({
	mask:'9999/19/39 29:59:00'
});
$('#datetimepicker').datetimepicker();
$('#datetimepicker').datetimepicker({value:'<?php echo date("Y-m-d H:i:s"); ?>',step:10});
$('#datetimepicker1').datetimepicker({
	datepicker:false,
	format:'H:i:s',
	step:5
});
</script>
</html>