<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style type="text/css">
#dialogoverlay
{
   display: none;
   opacity: .8;
   position: fixed;
   top: 0px;
   left: 0px;
   background: #FFF;
   width: 100%;
   z-index: 10;
   
   
}

#dialogbox
{
   display: none;
   position: fixed;
   background: #000;
   border-radius: 3px;
   width: 500px;
   z-index: 10;
   font-family: PTSansNarrow, Tahoma, Geneva, sans-serif;
   font-size:13px;
   border-radius: 3px;
    -webkit-border-radius: 3px;
    -moz-border-radius: 3px;
    -ms-border-radius: 3px;
    -o-border-radius: 3px;
    box-shadow: 0 0 6px rgba(0, 33, 70, 0.1), 0 7px 25px rgba(17, 38, 84, 0.4);
    -webkit-box-shadow: 0 0 6px rgba(0, 33, 70, 0.1), 0 7px 25px rgba(17, 38, 84, 0.4);
    -moz-box-shadow: 0 0 6px rgba(0, 33, 70, 0.1), 0 7px 25px rgba(17, 38, 84, 0.4);
    -ms-box-shadow: 0 0 6px rgba(0, 33, 70, 0.1), 0 7px 25px rgba(17, 38, 84, 0.4);
    -o-box-shadow: 0 0 6px rgba(0, 33, 70, 0.1), 0 7px 25px rgba(17, 38, 84, 0.4);
   
}

#dialogbox > div
{
   background: #36424b;
   margin: 1px;
}

#dialogbox > div > #dialogboxhead
{
    border-bottom: 1px solid #36424b;
    padding: 14px 41px 13px 17px;
    background-color: #414d57;
    background-image: linear-gradient(#57626c, #3c4852);
    background-image: -webkit-linear-gradient(#57626c, #3c4852);
    background-image: -moz-linear-gradient(#57626c, #3c4852);
    background-image: -o-linear-gradient(#57626c, #3c4852);
    background-image: -ms-linear-gradient(#57626c, #3c4852);
    -pie-background: linear-gradient(#57626c, #3c4852);
    box-shadow: 0 1px rgba(255, 255, 255, 0.21) inset, 0 0 10px rgba(255, 255, 255, 0.07) inset;
    -webkit-box-shadow: 0 1px rgba(255, 255, 255, 0.21) inset, 0 0 10px rgba(255, 255, 255, 0.07) inset;
    -moz-box-shadow: 0 1px rgba(255, 255, 255, 0.21) inset, 0 0 10px rgba(255, 255, 255, 0.07) inset;
    -ms-box-shadow: 0 1px rgba(255, 255, 255, 0.21) inset, 0 0 10px rgba(255, 255, 255, 0.07) inset;
    -o-box-shadow: 0 1px rgba(255, 255, 255, 0.21) inset, 0 0 10px rgba(255, 255, 255, 0.07) inset;
}

#smartAlertTitle {
    text-shadow: 0 -1px 1px rgba(2, 3, 3, 0.3);
    color: #fff;
    line-height: 13px;
}

#dialogbox > div > #dialogboxbody
{
   background: #FFF;
   padding: 20px;
   color: #000;
   text-align:center;
}

#dialogbox > div > #dialogboxfoot
{
    background: #f9fafe;
    padding: 12px 13px 13px;
    border-top: 1px solid #dfeaf4;
    border-radius: 0 0 2px 2px;
    text-align:center;
    
}
#contenido{
    color: #63737f;
    
  padding: 0em;
  margin: .5em 0 3em 2em;
  position: relative;
  line-height:23px;
  

 
   }
#icono{
 position: absolute;
  top: 58px; 
  left: 17px;
   }
.button
{
    margin-left: 11px;
    border: solid 1px #b1b8bf;
    padding: 9px 22px 7px;
    min-width: 32px;
    font-weight: bold;
    line-height: 13px;
    text-shadow: 0 1px 1px rgba(255, 255, 255, 0.5);
    color: #424e58;
    background-color: #f4f6f9;
    background-image: linear-gradient(#fff, #eceef4 99%, #eceef4);
    background-image: -webkit-linear-gradient(#fff, #eceef4 99%, #eceef4);
    background-image: -moz-linear-gradient(#fff, #eceef4 99%, #eceef4);
    background-image: -o-linear-gradient(#fff, #eceef4 99%, #eceef4);
    background-image: -ms-linear-gradient(#fff, #eceef4 99%, #eceef4);
    -pie-background: linear-gradient(#fff, #eceef4 99%, #eceef4);
    border-radius: 3px;
    -webkit-border-radius: 3px;
    -moz-border-radius: 3px;
    -ms-border-radius: 3px;
    -o-border-radius: 3px;
    box-shadow: 0 2px rgba(2, 3, 3, 0.05), 0 0 5px #fff inset;
    -webkit-box-shadow: 0 2px rgba(2, 3, 3, 0.05), 0 0 5px #fff inset;
    -moz-box-shadow: 0 2px rgba(2, 3, 3, 0.05), 0 0 5px #fff inset;
    -ms-box-shadow: 0 2px rgba(2, 3, 3, 0.05), 0 0 5px #fff inset;
    -o-box-shadow: 0 2px rgba(2, 3, 3, 0.05), 0 0 5px #fff inset;
    cursor:pointer;
}

.button:hover
{
 border: solid 1px #a8b3c4;
    background-color: #dde3e9;
    background-image: linear-gradient(#ebeff5, #d2d9e0);
    background-image: -webkit-linear-gradient(#ebeff5, #d2d9e0);
    background-image: -moz-linear-gradient(#ebeff5, #d2d9e0);
    background-image: -o-linear-gradient(#ebeff5, #d2d9e0);
    background-image: -ms-linear-gradient(#ebeff5, #d2d9e0);
    -pie-background: linear-gradient(#ebeff5, #d2d9e0);
    box-shadow: 0 2px rgba(2, 3, 3, 0.05), 0 2px rgba(255, 255, 255, 0.25) inset, 0 0 5px rgba(255, 255, 255, 0.5) inset;
    -webkit-box-shadow: 0 2px rgba(2, 3, 3, 0.05), 0 2px rgba(255, 255, 255, 0.25) inset, 0 0 5px rgba(255, 255, 255, 0.5) inset;
    -moz-box-shadow: 0 2px rgba(2, 3, 3, 0.05), 0 2px rgba(255, 255, 255, 0.25) inset, 0 0 5px rgba(255, 255, 255, 0.5) inset;
    -ms-box-shadow: 0 2px rgba(2, 3, 3, 0.05), 0 2px rgba(255, 255, 255, 0.25) inset, 0 0 5px rgba(255, 255, 255, 0.5) inset;
    -o-box-shadow: 0 2px rgba(2, 3, 3, 0.05), 0 2px rgba(255, 255, 255, 0.25) inset, 0 0 5px rgba(255, 255, 255, 0.5) inset;
}
</style>
  <script>
function CustomAlert(){
	this.render = function(dialog){
		var winW = window.innerWidth;
	    var winH = window.innerHeight;
		var dialogoverlay = document.getElementById('dialogoverlay');
	    var dialogbox = document.getElementById('dialogbox');
		dialogoverlay.style.display = "block";
	    dialogoverlay.style.height = winH+"px";
		dialogbox.style.left = (winW/2) - (550 * .5)+"px";
	    dialogbox.style.top = "100px";
	    dialogbox.style.display = "block";
		document.getElementById('dialogboxhead').innerHTML = "<span id='smartAlertTitle'>Mensaje</span>";
	    document.getElementById('dialogboxbody').innerHTML = dialog;
		document.getElementById('dialogboxfoot').innerHTML = '<button class="button" onclick="Alert.ok()">Aceptar</button>';
	}
	this.ok = function(){
		document.getElementById('dialogbox').style.display = "none";
		document.getElementById('dialogoverlay').style.display = "none";
	}
}
var Alert = new CustomAlert();
</script>
<!-- JQUERY -->

<script src="../librerias/alert/js/jquery.min.js"></script>
<script src="../librerias/alert/js/jquery-ui.min.js"></script>

<!-- ALERT -->

<link href="../librerias/alert/css/alert.css" rel="stylesheet" />
<link href="../librerias/alert/themes/default/theme.css" rel="stylesheet" />
<script src="../librerias/alert/js/alert.js"></script>
</head>
<body>
  <div id="dialogoverlay"></div>
  <div id="dialogbox">
    <div>
      <div id="dialogboxhead"></div>
      <div id="dialogboxbody"></div>
      <div id="dialogboxfoot"></div>
    </div>
  </div>
  <script type="text/javascript">
/*Alert.render('<span id="icono"><img src="../img/info.png" width="35" height="35"></span> <span id="contenido"> El proceso de registro se llevo a cabo con exito.  El proceso de registro se llevo a cabo con exito.  El proceso de registro se llevo a cabo con exito.  El proceso de registro se llevo a cabo con exito.  El proceso de registro se llevo a cabo con exito. </span>')
*/
$.alert.open({
	 title: 'Informacion',
    content: 'El proceso de registro se completo satisfactoriamente. \n &iquest;Desea agregar un nuevo registro?',
	 type: 'confirm',
    width: 440,
    align: 'center',
	 
	 callback: function(button) {
        if (button == 'yes')
           location.href='add_conductor.php';
        else if (button == 'no')
            location.href='list_conductores.php';
        else
            $.alert.open('Alerta cancelada.');
    }
	 
});
</script>

</body>
</html>