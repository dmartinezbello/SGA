<?php require_once('../Connections/conex.php'); ?>
<?php include('mensajes.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_codigoDuplicado = "-1";
if (isset($_POST['Alm_Codigo'])) {
  $colname_codigoDuplicado = $_POST['Alm_Codigo'];
}
mysql_select_db($database_conex, $conex);
$query_codigoDuplicado = sprintf("SELECT Alm_Codigo FROM almacen WHERE Alm_Codigo = %s", GetSQLValueString($colname_codigoDuplicado, "text"));
$codigoDuplicado = mysql_query($query_codigoDuplicado, $conex) or die(mysql_error());
$row_codigoDuplicado = mysql_fetch_assoc($codigoDuplicado);
$totalRows_codigoDuplicado = mysql_num_rows($codigoDuplicado);

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
	// Validar campos vacios y requeridos
	$error = 0;
	if (array_key_exists ('enviar', $_POST) && $_POST['Alm_Codigo']<>"" && $_POST['Alm_Nombre']<>"" && $_POST['Alm_Direccion']<>"") {
		// Validar que no hayan campos duplicados
		$existe = 0;
		if ($totalRows_codigoDuplicado == 0){	
			if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
			  $insertSQL = sprintf("INSERT INTO almacen (Alm_Codigo, Alm_Nombre, Alm_Direccion) VALUES (%s, %s, %s)",
								   GetSQLValueString(strtoupper($_POST['Alm_Codigo']), "text"),
								   GetSQLValueString($_POST['Alm_Nombre'], "text"),
								   GetSQLValueString($_POST['Alm_Direccion'], "text"));
			
			  mysql_select_db($database_conex, $conex);
			  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
			  
			  //Borrar el array de datos, Enviar mensaje de registro exitoso y redireccion a la lista de registros
				 $_POST = array();
				 echo "<script language='JavaScript'> alert('*** El proceso de registro se realizo con exito');</script>";
				 echo "<script language='Javascript'>location.href='list_almacenes.php';</script>";
	  
	  }else {if (array_key_exists ('enviar', $_POST)){$existe=1;}}
  }else {if (array_key_exists ('enviar', $_POST)){$error=1;}}}
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>registrar almacen</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="40" align="center" valign="bottom"><h3>Registro de Almac&eacute;n</h3></td>
  </tr>
</table>
<form method="post" name="form1" action="<?php echo $editFormAction; ?>">
  <table width="95%" border="0" align="center" cellpadding="5" cellspacing="2">
    <tr valign="baseline">
      <td colspan="2" align="left" nowrap><?php if ($_POST && $error ==1) { echo $incompleto."<BR>";}?>
      <?php if ($_POST && $totalRows_codigoDuplicado > 0) { echo $duplicado;}?></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" align="left" nowrap class="Tcabeza"><h2>Descripci&oacute;n del qu&iacute;mico</h2></td>
    </tr>
    <tr valign="baseline">
      <td width="20%" align="right" nowrap><label>Codig&oacute;:<?php if ($_POST && $_POST['Alm_Codigo'] == "") { echo $icono;}?>
        <?php if ($_POST && $totalRows_codigoDuplicado > 0) { echo $iconoAzul;}?>
      </label>
        <input name="Alm_Codigo" type="text" class="textInput mayusculas" value="<?php if (isset($_POST['Alm_Codigo'])) {echo htmlentities($_POST['Alm_Codigo']);} ?>" size="32">
      </td>
      <td width="80%"><label>Nombre:
        <?php if ($_POST && $_POST['Alm_Nombre'] == "") { echo $icono;}?>
      </label>
      <input name="Alm_Nombre" type="text" class="textInput" value="<?php if (isset($_POST['Alm_Nombre'])) {echo htmlentities($_POST['Alm_Nombre']);} ?>" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" align="right" valign="top" nowrap><label>Direcci&oacute;n:
        <?php if ($_POST && $_POST['Alm_Direccion'] == "") { echo $icono;}?>
      </label>
      <textarea name="Alm_Direccion" cols="50" rows="3"><?php if (isset($_POST['Alm_Direccion'])) {echo htmlentities($_POST['Alm_Direccion']);} ?></textarea></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" align="right" nowrap class="Tcabeza">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td width="20%" align="right" nowrap>&nbsp;</td>
      <td width="80%"><input name="enviar" type="submit" class="button der" id="enviar" value="Registrar">
        <input name="Restablecer" type="reset" class="button der" value="Restablecer">
        <input type="button" class="button der" onClick="location.href='principal.php'" value="Cancelar" /></td>
    </tr>
  </table>
  <input name="MM_insert" type="hidden" id="MM_insert" value="form1">
</form>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($codigoDuplicado);
?>
