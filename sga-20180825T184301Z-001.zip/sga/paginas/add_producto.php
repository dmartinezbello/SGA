<?php require_once('../Connections/conex.php'); ?>
<?php include('mensajes.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_codigoDuplicado = "-1";
if (isset($_POST['Pro_Codigo'])) {
  $colname_codigoDuplicado = $_POST['Pro_Codigo'];
}
mysql_select_db($database_conex, $conex);
$query_codigoDuplicado = sprintf("SELECT Pro_Codigo FROM productos WHERE Pro_Codigo = %s", GetSQLValueString($colname_codigoDuplicado, "text"));
$codigoDuplicado = mysql_query($query_codigoDuplicado, $conex) or die(mysql_error());
$row_codigoDuplicado = mysql_fetch_assoc($codigoDuplicado);
$totalRows_codigoDuplicado = mysql_num_rows($codigoDuplicado);$colname_codigoDuplicado = "-1";
if (isset($_POST['Pro_Codigo'])) {
  $colname_codigoDuplicado = $_POST['Pro_Codigo'];
}
mysql_select_db($database_conex, $conex);
$query_codigoDuplicado = sprintf("SELECT Pro_Codigo FROM productos WHERE Pro_Codigo = %s", GetSQLValueString($colname_codigoDuplicado, "text"));
$codigoDuplicado = mysql_query($query_codigoDuplicado, $conex) or die(mysql_error());
$row_codigoDuplicado = mysql_fetch_assoc($codigoDuplicado);
$totalRows_codigoDuplicado = mysql_num_rows($codigoDuplicado);

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
	$error = 0;
	if (array_key_exists ('enviar', $_POST) && !empty($_POST['Pro_Codigo']) && !empty($_POST['Pro_Nombre']) && !empty($_POST['Pro_Empaque']) && !empty($_POST['Pro_Peso']) && !empty($_POST['Pro_Unidad']) && $_POST['Pro_Salud']<> ""&& $_POST['Pro_Inflamabilidad']<> ""&& $_POST['Pro_Proteccion']<> "" && $_POST['Pro_Reactividad'] <> "") {
		$existe = 0;
		if ($totalRows_codigoDuplicado == 0){
				if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
				  $insertSQL = sprintf("INSERT INTO productos (Pro_Codigo, Pro_Nombre, Pro_Empaque, Pro_Peso, Pro_Unidad, Pro_Salud, Pro_Inflamabilidad, Pro_Reactividad, Pro_Proteccion, Pro_Msds, Pro_Tecnica) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
									   GetSQLValueString(strtoupper($_POST['Pro_Codigo']), "text"),
									   GetSQLValueString(strtoupper ($_POST['Pro_Nombre']), "text"),
									   GetSQLValueString($_POST['Pro_Empaque'], "text"),
									   GetSQLValueString($_POST['Pro_Peso'], "int"),
									   GetSQLValueString($_POST['Pro_Unidad'], "text"),
									   GetSQLValueString($_POST['Pro_Salud'], "text"),
									   GetSQLValueString($_POST['Pro_Inflamabilidad'], "text"),
									   GetSQLValueString($_POST['Pro_Reactividad'], "text"),
									   GetSQLValueString($_POST['Pro_Proteccion'], "text"),
									   GetSQLValueString($_POST['Pro_Msds'], "text"),
									   GetSQLValueString($_POST['Pro_Tecnica'], "text"));
				
				  mysql_select_db($database_conex, $conex);
				  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
				  
				 //Borrar el array de datos, Enviar mensaje de registro exitoso y redireccion a la lista de registros
				 $_POST = array();
				 echo "<script language='JavaScript'> alert('*** El proceso de registro se realizo con exito');</script>";
				 echo "<script language='Javascript'>location.href='list_productos.php';</script>";
				}
		}else {if (array_key_exists ('enviar', $_POST)){$existe=1;}}
	}else {if (array_key_exists ('enviar', $_POST)){$error=1;}}
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Registro de producto</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="40" align="center" valign="bottom"><h3>Registro de Producto Qu&iacute;mico</h3></td>
  </tr>
</table>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="5">&nbsp;</td>
  </tr>
  <tr>
    <td height="15">
    <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
    <table width="95%" align="center">
          <tr valign="baseline">
            <td colspan="3" nowrap>
            <?php if ($_POST && $error ==1) { echo $incompleto."<BR>";}?>
            <?php if ($_POST && $totalRows_codigoDuplicado > 0) { echo $duplicado;}?>
            </td>
          </tr>
          <tr valign="baseline">
            <td colspan="3" nowrap class="Tcabeza"><h2>Descripci&oacute;n del qu&iacute;mico</h2></td>
          </tr>
          <tr valign="baseline">
            <td width="48%" align="right" nowrap><label>C&oacute;digo:<?php if ($_POST && $_POST['Pro_Codigo'] == "") { echo $icono;}?><?php if ($_POST && $totalRows_codigoDuplicado > 0) { echo $iconoAzul;}?></label>
              
<input name="Pro_Codigo" type="text" class="textInput" value="<?php if (isset($_POST['Pro_Codigo'])) {echo htmlentities($_POST['Pro_Codigo']);} ?>" size="8" maxlength="8"></td>
            <td width="4%">&nbsp;</td>
            <td width="48%"><label>Nombre:
              <?php if ($_POST && $_POST['Pro_Nombre'] == "") { echo $icono;}?>
            </label>
              <input name="Pro_Nombre" type="text" class="textInput" value="<?php if (isset($_POST['Pro_Nombre'])) {echo htmlentities($_POST['Pro_Nombre']);} ?>" size="32"></td>
          </tr>
          <tr valign="baseline">
            <td width="48%" align="right" nowrap><label>Empaque:
              <?php if ($_POST && $_POST['Pro_Empaque'] == "Seleccione una opci�n") { echo $icono;}?>
            </label>
              <select name="Pro_Empaque" class="textInput">
                <option selected="selected">Seleccione una opci&oacute;n</option>
                <option value="Barril">Barril</option>
                <option value="Botella">Botella</option>
                <option value="Cunete">Cunete</option>
                <option value="Saco">Saco</option>
                <option value="Tambor">Tambor</option>
                <option value="Tanque">Tanque</option>
                <option value="Unidad">Unidad</option>
              </select></td>
            <td width="4%">&nbsp;</td>
            <td width="48%"><label>Unidad:
              <?php if ($_POST && $_POST['Pro_Unidad'] == "Seleccione una opci�n") { echo $icono;}?>
            </label>
              <select name="Pro_Unidad" class="textInput">
                <option selected="selected">Seleccione una opci&oacute;n</option>
                <option value="Kilogramo">Kilogramo</option>
                <option value="Libra">Libra</option>
                <option value="Litro">Litro</option>
                <option value="Mililitro">Mililitro</option>
                <option value="Tonelada">Tonelada</option>
                <option value="Unidad">Unidad</option>
              </select></td>
          </tr>
          <tr valign="baseline">
            <td width="48%" align="right" nowrap><label>Peso:
              <?php if ($_POST && $_POST['Pro_Peso'] == "") { echo $icono;}?>
            </label>
              <input name="Pro_Peso" type="text" class="textInput" value="<?php if (isset($_POST['Pro_Peso'])) {echo htmlentities($_POST['Pro_Peso']);} ?>" size="8" maxlength="8"></td>
            <td width="4%">&nbsp;</td>
            <td width="48%">&nbsp;</td>
          </tr>
          <tr valign="baseline" class="Tcabeza">
            <td height="40" colspan="3" align="right" nowrap>&nbsp;</td>
          </tr>
          <tr valign="baseline">
            <td height="20" colspan="3" align="right" nowrap>&nbsp;</td>
          </tr>
          <tr valign="baseline">
            <td colspan="3" nowrap class="Tcabeza"><h2>Clasificaci&oacute;n de peligro</h2></td>
          </tr>
          <tr valign="baseline">
            <td colspan="3" align="right" nowrap><table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="48%"><table width="100%">
                      <tr>
                        <td height="35" colspan="2" bgcolor="#0066FF" class="bordeNegroSolido" style="color:#FFF; text-align:center; font-weight:bold;"><ruby>M&iacute;nimo
                            <rt>0</rt>
                          </ruby>
                          <ruby>Ligero
                            <rt>1</rt>
                          </ruby>
                          <ruby>Moderado
                            <rt>2</rt>
                          </ruby>
                          <ruby>Grave
                            <rt>3</rt>
                          </ruby>
                          <ruby>Extremo
                            <rt>4</rt>
                          </ruby></td>
                      </tr>
                      <tr>
                        <td><label>&nbsp;Salud:
                          <?php if ($_POST && $_POST['Pro_Salud'] == "") { echo $icono;}?>
                        </label></td>
                        <td width="30" align="right"><input name="Pro_Salud" type="text" value="<?php if (isset($_POST['Pro_Salud'])) {echo htmlentities($_POST['Pro_Salud']);} ?>" size="1" maxlength="1" style="text-align:center;border: 1px solid #ccc;"></td>
                      </tr>
                    </table></td>
                  <td width="4%">&nbsp;</td>
                  <td width="48%"><table width="100%">
                    <tr>
                      <td height="35" colspan="2" bgcolor="#FF0033" class="bordeNegroSolido" style="color:#FFF; text-align:center; font-weight:bold;"><ruby>M&iacute;nimo
                        <rt>0</rt>
                        </ruby>
                        <ruby>Ligero
                          <rt>1</rt>
                          </ruby>
                        <ruby>Moderado
                          <rt>2</rt>
                          </ruby>
                        <ruby>Grave
                          <rt>3</rt>
                          </ruby>
                        <ruby>Extremo
                          <rt>4</rt>
                        </ruby></td>
                      </tr>
                    <tr>
                      <td><label>Inflamabilidad:
                        <?php if ($_POST && $_POST['Pro_Inflamabilidad'] == "") { echo $icono;}?>
                      </label></td>
                      <td width="30" align="right"><input name="Pro_Inflamabilidad" type="text" value="<?php if (isset($_POST['Pro_Inflamabilidad'])) {echo htmlentities($_POST['Pro_Inflamabilidad']);} ?>" size="1" maxlength="1" style="text-align:center;border: 1px solid #ccc;"></td>
                      </tr>
                  </table></td>
                </tr>
                <tr>
                  <td width="48%" height="40"><table width="100%">
                    <tr>
                      <td height="35" colspan="2" bgcolor="#FFCC00" class="bordeNegroSolido" style="color:#000; text-align:center; font-weight:bold;"><ruby>M&iacute;nimo
                        <rt>0</rt>
                        </ruby>
                        <ruby>Ligero
                          <rt>1</rt>
                          </ruby>
                        <ruby>Moderado
                          <rt>2</rt>
                          </ruby>
                        <ruby>Grave
                          <rt>3</rt>
                          </ruby>
                        <ruby>Extremo
                          <rt>4</rt>
                        </ruby></td>
                      </tr>
                    <tr>
                      <td><label>Reactividad:
                        <?php if ($_POST && $_POST['Pro_Reactividad'] == "") { echo $icono;}?>
                      </label></td>
                      <td width="30" align="right"><input name="Pro_Reactividad" type="text" value="<?php if (isset($_POST['Pro_Reactividad'])) {echo htmlentities($_POST['Pro_Reactividad']);} ?>" size="1" maxlength="1" style="text-align:center;border: 1px solid #ccc;"></td>
                      </tr>
                  </table></td>
                  <td width="4%">&nbsp;</td>
                  <td width="48%"><table width="100%">
                    <tr>
                      <td height="35" colspan="2" bgcolor="#FFFFFF" class="bordeNegroSolido" style="text-align:center; font-weight:bold;"><ruby></ruby>
                        <ruby>Gu&iacute;a de identificaci&oacute;n de EPP
                          <rt style="font-size:10px;">
                            <a href="../recursos/GuiaEPPII.pdf" target="_new">Consultar_Aqu&iacute;</a>
                            </rt>
                        </ruby></td>
                      </tr>
                    <tr>
                      <td><label>Equipo de protecci&oacute;n:
                        <?php if ($_POST && $_POST['Pro_Proteccion'] == "") { echo $icono;}?>
                      </label></td>
                      <td width="30" align="right"><input name="Pro_Proteccion" type="text" value="<?php if (isset($_POST['Pro_Proteccion'])) {echo htmlentities($_POST['Pro_Proteccion']);} ?>" size="1" maxlength="1" style="text-align:center;border: 1px solid #ccc;"></td>
                      </tr>
                  </table></td>
                </tr>
                <tr valign="baseline" class="Tcabeza">
                  <td height="40" colspan="3" align="right" nowrap>&nbsp;</td>
                </tr>
                <tr>
                  <td height="20" colspan="3">&nbsp;</td>
                </tr>
              </table></td>
          </tr>
          <tr valign="baseline">
            <td colspan="3" valign="top" nowrap class="Tcabeza"><h2>Otra informaci&oacute;n</h2></td>
          </tr>
          <tr valign="baseline">
            <td colspan="3" align="right" valign="top" nowrap><label>Hoja de seguridad:</label>
            <textarea name="Pro_Msds" cols="50" rows="3"><?php if (isset($_POST['Pro_Msds'])) {echo htmlentities($_POST['Pro_Msds']);} ?></textarea>
            </td>
          </tr>
          <tr valign="baseline">
            <td colspan="3" align="right" valign="top" nowrap><label>Boletin t&eacute;cnico:</label>
            <textarea name="Pro_Tecnica" cols="50" rows="3"><?php if (isset($_POST['Pro_Tecnica'])) {echo htmlentities($_POST['Pro_Tecnica']);} ?></textarea></td>
          </tr>
          <tr valign="baseline" class="Tcabeza">
            <td height="40" colspan="3" align="right" nowrap>&nbsp;</td>
          </tr>
          <tr valign="baseline">
            <td height="20" colspan="3" align="right" valign="top" nowrap>&nbsp;</td>
          </tr>
          <tr valign="baseline">
            <td colspan="3" align="right" valign="top" nowrap><input name="enviar" type="submit" class="button der" id="enviar" value="Registrar">
              <input name="Restablecer" type="reset" class="button der" value="Restablecer">
              <input type="button" class="button der" onClick="history.back()" value="Volver" >
              <input type="button" class="button der" onClick="location.href='sga.php'" value="Cancelar" /></td>
          </tr>
          <tr valign="baseline">
            <td colspan="3" align="right" valign="top" nowrap>&nbsp;</td>
          </tr>
          
        </table>
        <input type="hidden" name="MM_insert" value="form1">
    </form></td>
  </tr>
  <tr>
    <td height="5">&nbsp;</td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($codigoDuplicado);
?>
