<?php require_once('../Connections/conex.php'); ?>
<?php include('mensajes.php'); ?>
<?php $url =$_GET['conductor']; ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_obtenerDuplicado = "-1";
if (isset($_POST['Pro_Rif'])) {
  $colname_obtenerDuplicado = $_POST['Pro_Rif'];
}
mysql_select_db($database_conex, $conex);
$query_obtenerDuplicado = sprintf("SELECT * FROM proveedor WHERE Pro_Rif = %s", GetSQLValueString($colname_obtenerDuplicado, "text"));
$obtenerDuplicado = mysql_query($query_obtenerDuplicado, $conex) or die(mysql_error());
$row_obtenerDuplicado = mysql_fetch_assoc($obtenerDuplicado);
$totalRows_obtenerDuplicado = mysql_num_rows($obtenerDuplicado);

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
// Validar campos vacios y requeridos
	$error = 0;
	if (array_key_exists ('enviar', $_POST) && $_POST['Pro_Nombre']<>"" && $_POST['Pro_Rif']<>"" ){
	// Validar que no hayan campos duplicados
		$existe = 0;
		if ($totalRows_obtenerDuplicado == 0){	
	
		if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
		  $insertSQL = sprintf("INSERT INTO proveedor (Pro_Nombre, Pro_Rif, Pro_Contacto, Pro_Telefono) VALUES (%s, %s, %s, %s)",
									  GetSQLValueString($_POST['Pro_Nombre'], "text"),
									  GetSQLValueString($_POST['Pro_Rif'], "text"),
									  GetSQLValueString($_POST['Pro_Contacto'], "text"),
									  GetSQLValueString($_POST['Pro_Telefono'], "text"));
		
		  mysql_select_db($database_conex, $conex);
		  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
		  
		  //Borrar el array de datos, Enviar mensaje de registro exitoso y redireccion a la lista de registros
				 $_POST = array();
				 echo "<script language='JavaScript'> alert('*** El proceso de registro se realizo con exito');</script>";
 				 if ($url == ""){ echo "<script language='Javascript'>location.href='list_proveedores.php';</script>";}
 				 if ($url == "1"){ echo "<script language='Javascript'>location.href='add_conductor.php';</script>";}
				 if ($url == "2"){ echo "<script language='Javascript'>location.href='add_solicitud.php';</script>";}
				 
	}
	}else {if (array_key_exists ('enviar', $_POST)){$existe=1;}}
	}else {if (array_key_exists ('enviar', $_POST)){$error=1;}}
	
	
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>registrar proveedor</title>
<link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
<link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="40" align="center" valign="bottom"><h3>Registro de Proveedor</h3></td>
  </tr>
</table>
<form method="post" name="form1" action="<?php echo $editFormAction; ?>">
  <table width="95%" border="0" align="center" cellpadding="5" cellspacing="2">
  <tr valign="baseline">
      <td colspan="2" align="left" nowrap><?php if ($_POST && $error ==1) { echo $incompleto."<BR>";}?>
      <?php if ($_POST && $totalRows_obtenerDuplicado > 0) { echo $duplicado;}?></td>
    </tr>
    <tr valign="baseline">
      <td align="right" nowrap>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" align="left" nowrap class="Tcabeza"><h2>Descripci&oacute;n del proveedor</h2></td>
    </tr>
    <tr valign="baseline">
      <td width="50%" align="left" nowrap><label>Registro &Uacute;nico de Informaci&oacute;n Fiscal (RIF):
          <?php if ($_POST && $_POST['Pro_Rif'] == "") { echo $icono;}?>
          <?php if ($_POST && $totalRows_obtenerDuplicado > 0) { echo $iconoAzul;}?>
      </label>
        <span id="sprytextfield2">
        <input name="Pro_Rif" type="text" class="textInput" value="<?php if (isset($_POST['Pro_Rif'])) {echo htmlentities($_POST['Pro_Rif']);} ?>" size="32" >
<span class="textfieldInvalidFormatMsg">Formato no v�lido.</span></span></td>
      <td width="50%">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td align="right" nowrap><label>Raz&oacute;n social:
          <?php if ($_POST && $_POST['Pro_Nombre'] == "") { echo $icono;}?>
      </label>        <input name="Pro_Nombre" type="text" class="textInput" value="<?php if (isset($_POST['Pro_Nombre'])) {echo htmlentities($_POST['Pro_Nombre']);} ?>" size="32"></td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td width="50%" align="right" nowrap><label>Persona de contacto:</label>
      <input name="Pro_Contacto" type="text" class="textInput" value="" size="32"></td>
      <td width="50%"><label>Tel&eacute;fono:</label>
        <span id="sprytextfield1"><span id="sprytextfield3">
        <input name="Pro_Telefono" type="text" class="textInput" value="" size="32">
<span class="textfieldInvalidFormatMsg">Formato no v�lido.</span></span><span class="textfieldInvalidFormatMsg">Formato invalido</span></span></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" align="right" nowrap class="Tcabeza">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" align="right" nowrap><input name="enviar" type="submit" class="button der" id="enviar" value="Registrar">
        <input name="Restablecer" type="reset" class="button der" value="Restablecer">
        <input type="button" class="button der" onClick="location.href='principal.php'" value="Cancelar" /></td>
    </tr>
  </table>
  <input type="hidden" name="MM_insert" value="form1">
</form>
<p>&nbsp;</p>
<script type="text/javascript">
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "custom", {pattern:"A-00000000-0", useCharacterMasking:true, isRequired:false});
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "custom", {useCharacterMasking:true, isRequired:false, pattern:"0000-000 0000"});
</script>
</body>
</html>
<?php
mysql_free_result($obtenerDuplicado);
?>
