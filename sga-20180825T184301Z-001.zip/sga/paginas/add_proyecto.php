<?php require_once('../Connections/conex.php'); ?>
<?php include('mensajes.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_duplicado = "-1";
if (isset($_POST['Pro_Logit'])) {
  $colname_duplicado = $_POST['Pro_Logit'];
}
mysql_select_db($database_conex, $conex);
$query_duplicado = sprintf("SELECT Pro_Logit FROM proyecto WHERE Pro_Logit = %s", GetSQLValueString($colname_duplicado, "text"));
$duplicado = mysql_query($query_duplicado, $conex) or die(mysql_error());
$row_duplicado = mysql_fetch_assoc($duplicado);
$totalRows_duplicado = mysql_num_rows($duplicado);

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1") && $_POST['Pro_Logit']<>"" && $_POST['Pro_Pozo']<>"" && $_POST['Pro_Taladro']<>"" && $_POST['Pro_Cliente']<>"" && $_POST['Pro_Usuario']<>"" && $_POST['Pro_Direccion']<>"" && $_POST['obligatorio']=="1" && $totalRows_duplicado == 0) {
  $insertSQL = sprintf("INSERT INTO proyecto (Pro_Logit, Pro_Pozo, Pro_Taladro, Pro_Cliente, Pro_Usuario, Pro_Direccion) VALUES (%s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['Pro_Logit'], "text"),
                       GetSQLValueString(strtoupper($_POST['Pro_Pozo']), "text"),
                       GetSQLValueString(strtoupper($_POST['Pro_Taladro']), "text"),
                       GetSQLValueString($_POST['Pro_Cliente'], "text"),
                       GetSQLValueString($_POST['Pro_Usuario'], "text"),
                       GetSQLValueString($_POST['Pro_Direccion'], "text"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
  //Borrar el array de datos, Enviar mensaje de registro exitoso y redireccion a la lista de registros
				 $_POST = array();
				 echo "<script language='JavaScript'> alert('*** El proceso de registro se realizo con exito');</script>";
				 echo "<script language='Javascript'>location.href='list_proyectos.php';</script>";
}else {$error = 1;}
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>agragar proyecto</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="../js/ajax.js"></script>
</head>

<body>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="40" align="center" valign="bottom"><h3>Registro de Proyecto</h3></td>
    </tr>
  </table>
  <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
    <table width="95%" border="0" align="center" cellpadding="5" cellspacing="2">
      <tr valign="baseline">
        <td colspan="3" nowrap>
		  <?php if ($_POST && $error == 1 && $totalRows_duplicado <= 0) { echo $incompleto."<BR>";}?>
        <?php if ($_POST && $totalRows_duplicado > 0) { echo "<span class='obligatorio'>No se completo el proceso de registro porque ya existe uno identico. Por favor, vuelva a intentar introduciendo datos diferentes donde se refleja el icono: <span class='icon-obligaAzul'>&nbsp;&nbsp;&nbsp;&nbsp;</span></span>";}?>
        </td>
      </tr>
      <tr valign="baseline" class="Tcabeza">
        <td colspan="3" nowrap><h2>Datos del Proyecto</h2></td>
      </tr>
      <tr valign="baseline">
        <td width="25%" align="right" nowrap><label>Log-It:
          <?php if ($_POST && $_POST['Pro_Logit'] == "") { echo $icono;}?>
        </label>
        <input name="Pro_Logit" type="text" class="textInput" value="<?php if (isset($_POST['Pro_Logit'])) {echo htmlentities($_POST['Pro_Logit']);} ?>" size="32"></td>
        <td width="25%" align="right" nowrap>&nbsp;</td>
        <td width="50%">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td width="25%" align="right" nowrap><label>Pozo:
          <?php if ($_POST && $_POST['Pro_Pozo'] == "") { echo $icono;}?>
        </label>
        <input name="Pro_Pozo" type="text" class="textInput mayusculas" value="<?php if (isset($_POST['Pro_Pozo'])) {echo htmlentities($_POST['Pro_Pozo']);} ?>" size="32"></td>
        <td width="25%" align="right" nowrap><label>Taladro:
          <?php if ($_POST && $_POST['Pro_Taladro'] == "") { echo $icono;}?>
        </label>
        <input name="Pro_Taladro" type="text" class="textInput mayusculas" value="<?php if (isset($_POST['Pro_Taladro'])) {echo htmlentities($_POST['Pro_Taladro']);} ?>" size="32"></td>
        <td width="50%">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td width="50%" colspan="2" align="right" nowrap><label>Cliente:
          <?php if ($_POST && $_POST['Pro_Cliente'] == "") { echo $icono;}?>
        </label>
        <input name="Pro_Cliente" type="text" class="textInput" value="<?php if (isset($_POST['Pro_Cliente'])) {echo htmlentities($_POST['Pro_Cliente']);} ?>" size="32"></td>
        <td width="50%">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td width="50%" colspan="2" align="right" nowrap><label>Ingeniero de proyecto:
          <?php if ($_POST && $_POST['Pro_Usuario'] == "") { echo $icono;}?>
        </label>
        <input name="Pro_Usuario" id="Pro_Usuario" type="text" class="textInput" value="<?php if (isset($_POST['Pro_Usuario'])) {echo htmlentities($_POST['Pro_Usuario']);} ?>" size="32" onBlur="Ingeniero();" ></td>
        <td width="50%"><div id="ingeniero">&nbsp;</div></td>
      </tr>
      <tr valign="baseline">
        <td colspan="3" align="right" nowrap><label>Direcci&oacute;n: 
          <?php if ($_POST && $_POST['Pro_Direccion'] == "") { echo $icono;}?>
        </label>
        <textarea name="Pro_Direccion" cols="32" rows="3"><?php if (isset($_POST['Pro_Direccion'])) {echo htmlentities($_POST['Pro_Direccion']);} ?></textarea></td>
      </tr>
      <tr valign="baseline">
        <td colspan="3" align="right" nowrap class="Tcabeza">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td colspan="3" align="right" nowrap><input name="enviar" type="submit" class="button der" id="enviar" value="Registrar">
          <input name="Restablecer" type="reset" class="button der" value="Restablecer">
          <input type="button" class="button der" onClick="history.back()" value="Volver" >
          <input type="button" class="button der" onClick="location.href='cuerpo.php'" value="Cancelar" /></td>
      </tr>
    </table>
    <input type="hidden" name="MM_insert" value="form1">
  </form>
  <p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($duplicado);
?>
