<?php //initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
  
  echo "<script> if (parent.frames.length > 0) { parent.location.href = '../index2.php'}</script>";
	
}
?>
<?php require_once('../Connections/conex.php'); ?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "../index2.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php include('mensajes.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
//Consultas a la base de datos
mysql_select_db($database_conex, $conex);
$query_almacen = "SELECT Alm_Codigo, Alm_Nombre FROM almacen ORDER BY Alm_Nombre ASC";
$almacen = mysql_query($query_almacen, $conex) or die(mysql_error());
$row_almacen = mysql_fetch_assoc($almacen);
$totalRows_almacen = mysql_num_rows($almacen);

mysql_select_db($database_conex, $conex);
$query_recepcion = "SELECT entrada.Ent_Numero FROM entrada WHERE entrada.Ent_Numero LIKE '%".$_POST['Alm_Codigo']."%'";
$recepcion = mysql_query($query_recepcion, $conex) or die(mysql_error());
$row_recepcion = mysql_fetch_assoc($recepcion);
$totalRows_recepcion = mysql_num_rows($recepcion);

$colname_conductor = "-1";
if (isset($_POST['Con_Cedula'])) {
  $colname_conductor = $_POST['Con_Cedula'];
}
mysql_select_db($database_conex, $conex);
$query_conductor = sprintf("SELECT Con_Cedula FROM conductor WHERE Con_Cedula = %s", GetSQLValueString($colname_conductor, "text"));
$conductor = mysql_query($query_conductor, $conex) or die(mysql_error());
$row_conductor = mysql_fetch_assoc($conductor);
$totalRows_conductor = mysql_num_rows($conductor);

$colname_vehiculo = "-1";
if (isset($_POST['Veh_Placa'])) {
  $colname_vehiculo = $_POST['Veh_Placa'];
}
mysql_select_db($database_conex, $conex);
$query_vehiculo = sprintf("SELECT Veh_Placa FROM vehiculos WHERE Veh_Placa = %s", GetSQLValueString($colname_vehiculo, "text"));
$vehiculo = mysql_query($query_vehiculo, $conex) or die(mysql_error());
$row_vehiculo = mysql_fetch_assoc($vehiculo);
$totalRows_vehiculo = mysql_num_rows($vehiculo);

// Declaracion de variables
$numero= $totalRows_recepcion + 1;
$codigo=$_POST['Alm_Codigo'].'-'.str_pad($numero, 8, 0, STR_PAD);

// Validar campos vacios y requeridos
	$error = 0;
	if (array_key_exists ('enviar', $_POST) && $_POST['Con_Cedula']<>"" && $_POST['Veh_Placa']<>"" ){
if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1" && $totalRows_vehiculo > 0 && $totalRows_conductor > 0)) {
  $insertSQL = sprintf("INSERT INTO entrada (Ent_Numero, Alm_Codigo, Ent_Fecha, Con_Cedula, Veh_Placa, Ent_Observacion, Ent_Usuario) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($codigo, "text"),
                       GetSQLValueString($_POST['Alm_Codigo'], "text"),
                       GetSQLValueString($_POST['Ent_Fecha'], "date"),
                       GetSQLValueString($_POST['Con_Cedula'], "text"),
                       GetSQLValueString(strtoupper($_POST['Veh_Placa']), "text"),
                       GetSQLValueString($_POST['Ent_Observacion'], "text"),
                       GetSQLValueString($_POST['Ent_Usuario'], "text"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
  
    //Borrar el array de datos, Enviar mensaje de registro exitoso y redireccion a la lista de registros
				 echo "<script language='JavaScript'> alert('*** El proceso de registro se realizo con exito');</script>";
 				 if ($url == ""){ echo "<script language='Javascript'>location.href='add_recepcion_detalle.php?&recepcion=".$codigo."&almacen=".$_POST['Alm_Codigo']."';</script>";}
				 $_POST = array();

}
}else {if (array_key_exists ('enviar', $_POST)){$error=1;}}
?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>RPQ</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="../librerias/calendario/jquery.datetimepicker.css"/>
<link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="../js/ajax.js"></script>
<script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
</head>

<body>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="40" align="center" valign="bottom"><h3>Registro de Solicitudes de Productos Qu&iacute;micos</h3></td>
    </tr>
  </table>
  <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
    <table width="95%" border="0" align="center" cellpadding="5" cellspacing="2">
      <tr valign="baseline">
        <td align="right" nowrap>&nbsp;</td>
        <td colspan="2" align="left" nowrap>
		<?php if ($_POST && $error == 1) { echo $incompleto."<BR>";}?>
        </td>
        <td>&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td colspan="4" nowrap class="Tcabeza"><h2>Datos de la recepci&oacute;n de producto</h2></td>
      </tr>
      <tr valign="baseline">
        <td align="right" nowrap>&nbsp;</td>
        <td align="right" nowrap>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td width="25%" align="right" nowrap>&nbsp;</td>
        <td width="30%" align="right" nowrap><label>Fecha:</label>
        <input name="Ent_Fecha" id="datetimepicker" type="text" class="textInput" value="<?php if (isset($_POST['Ent_Fecha'])) {echo htmlentities($_POST['Ent_Fecha']);} ?>" size="32"></td>
        <td width="30%"><label>Almac&eacute;n:</label>
          <select name="Alm_Codigo" class="select">
            <?php
do {  
?>
            <option value="<?php echo $row_almacen['Alm_Codigo']?>"><?php echo $row_almacen['Alm_Codigo'].' - '.$row_almacen['Alm_Nombre']?></option>
            <?php
} while ($row_almacen = mysql_fetch_assoc($almacen));
  $rows = mysql_num_rows($almacen);
  if($rows > 0) {
      mysql_data_seek($almacen, 0);
	  $row_almacen = mysql_fetch_assoc($almacen);
  }
?>
          </select></td>
        <td width="20%">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td width="25%" align="right" nowrap>&nbsp;</td>
        <td width="30%" align="right" nowrap><label>Conductor:
            <?php if ($_POST && $_POST['Con_Cedula'] == "") { echo $icono;}?>
            <?php if ($_POST && $totalRows_conductor == 0) { echo '<span style="color:red;">No existe</span>';}?>
        </label>
          <span id="sprytextfield1">
          <input name="Con_Cedula" id="Con_Cedula" type="text" class="textInput" value="<?php if (isset($_POST['Con_Cedula'])) {echo htmlentities($_POST['Con_Cedula']);} ?>" size="32" onBlur="Conductor();" onKeyUp="Conductor();">
<span class="textfieldInvalidFormatMsg">Formato invalido</span></span></td>
        <td width="30%" valign="bottom"><div id="conductor">&nbsp;</div></td>
        <td width="20%">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td width="25%" align="right" nowrap>&nbsp;</td>
        <td width="30%" align="right" nowrap><label>Placa veh&iacute;culo:
            <?php if ($_POST && $_POST['Veh_Placa'] == "") { echo $icono;}?>
            <?php if ($_POST && $totalRows_vehiculo == 0) { echo '<span style="color:red;">No existe</span>';}?>
        </label>
        <input name="Veh_Placa" id="Veh_Placa" type="text" class="textInput mayusculas" value="<?php if (isset($_POST['Veh_Placa'])) {echo htmlentities($_POST['Veh_Placa']);} ?>" size="32" onBlur="Vehiculo();" onKeyUp="Vehiculo();"></td>
        <td width="30%" valign="bottom"><div id="vehiculo">&nbsp;</div></td>
        <td width="20%">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td width="25%" align="right" nowrap>&nbsp;</td>
        <td colspan="2" align="right" nowrap><label>Observaci&oacute;n:</label>
        <textarea name="Ent_Observacion" cols="32" rows="5" class="anchoFull"><?php if (isset($_POST['Ent_Observacion'])) {echo htmlentities($_POST['Ent_Observacion']);}?></textarea></td>
        <td width="20%">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td width="25%" align="right" nowrap>&nbsp;</td>
        <td width="30%" align="right" nowrap>&nbsp;</td>
        <td width="30%">&nbsp;</td>
        <td width="20%">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td colspan="4" align="right" nowrap class="Tcabeza">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td colspan="4" align="right" nowrap><input name="enviar" type="submit" class="button der" id="enviar" value="Registrar">
          <input name="Restablecer" type="reset" class="button der" value="Restablecer">
          <input type="button" class="button der" onClick="history.back()" value="Volver" >
          <input type="button" class="button der" onClick="location.href='cuerpo.php'" value="Cancelar" /></td>
      </tr>
    </table>
    <input type="hidden" name="MM_insert" value="form1">
    <input type="hidden" name="Ent_Usuario" value="<?php echo $_SESSION['MM_Username']; ?>" size="32">
  </form>
  <p>&nbsp;</p>
<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "custom", {pattern:"00.000.000", useCharacterMasking:true, isRequired:false});
  </script>
</body>
<script src="../librerias/calendario/jquery.js"></script>
<script src="../librerias/calendario/jquery.datetimepicker.js"></script>
<script>

$('#datetimepicker10').datetimepicker({
	step:5,
	inline:true
});
$('#datetimepicker_mask').datetimepicker({
	mask:'9999/19/39 29:59:00'
});
$('#datetimepicker').datetimepicker();
$('#datetimepicker').datetimepicker({value:'<?php echo date("Y-m-d H:i:s"); ?>',step:10});
$('#datetimepicker1').datetimepicker({
	datepicker:false,
	format:'H:i:s',
	step:5
});
</script>
</html>
<?php
mysql_free_result($almacen);
mysql_free_result($recepcion);

mysql_free_result($conductor);

mysql_free_result($vehiculo);
?>
