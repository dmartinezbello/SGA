<?php require_once('../Connections/conex.php'); ?>
<?php include('mensajes.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
// Consulta
mysql_select_db($database_conex, $conex);
$query_agregados = "SELECT recepcion.Pro_Codigo, CONCAT( productos.Pro_codigo, ' - ',Pro_Nombre , ', ' , Pro_Empaque , ' de ' , Pro_Peso , ' ' , Pro_Unidad ) AS Descripcion, Sol_Odc, Rec_Solicitud, SUM(Rec_Cantidad) AS Total FROM recepcion, productos, solicitud WHERE Rec_Numero ='".$_GET['recepcion']."' AND Rec_Solicitud = Sol_Serial AND productos.Pro_Codigo = recepcion.Pro_Codigo GROUP BY recepcion.Pro_Codigo, Sol_Odc, Rec_Solicitud ORDER BY recepcion.Pro_Codigo, Sol_Odc, Rec_Solicitud ASC";
$agregados = mysql_query($query_agregados, $conex) or die(mysql_error());
$row_agregados = mysql_fetch_assoc($agregados);
$totalRows_agregados = mysql_num_rows($agregados);

// Registrar o agregar nuevo articulo a la recepcion
if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form2") && $_POST['Rec_Lote']<> "" && $_POST['Rec_Paleta'] <> "" && $_POST['Rec_Entrega'] <> "" && $_POST['Rec_Cantidad'] <= $_POST['recibir']) {
  $insertSQL = sprintf("INSERT INTO recepcion (Rec_Serial, Rec_Solicitud, Rec_Numero, Pro_Codigo, Rec_Lote, Rec_Paleta, Rec_Cxu, Rec_Cantidad, Rec_Certificado, Rec_Prueba, Rec_Embalaje, Rec_Entrega) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['Rec_Serial'], "int"),
                       GetSQLValueString($_POST['Rec_Solicitud'], "text"),
                       GetSQLValueString($_POST['Rec_Numero'], "text"),
                       GetSQLValueString($_POST['Pro_Codigo'], "text"),
                       GetSQLValueString(strtoupper($_POST['Rec_Lote']), "text"),
                       GetSQLValueString($_POST['Rec_Paleta'], "int"),
                       GetSQLValueString($_POST['Rec_Cxu'], "int"),
                       GetSQLValueString($_POST['Rec_Cantidad'], "int"),
                       GetSQLValueString($_POST['Rec_Certificado'], "text"),
                       GetSQLValueString($_POST['Rec_Prueba'], "text"),
                       GetSQLValueString($_POST['Rec_Embalaje'], "text"),
                       GetSQLValueString(strtoupper($_POST['Rec_Entrega']), "text"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
  
  // Consulta para seleccionar el producto en el almacen donde se recibe
  mysql_select_db($database_conex, $conex);
$query_inventario = "SELECT Alm_Codigo, Pro_Codigo, Inv_Stock FROM inventario WHERE Alm_Codigo = '".$_GET['almacen']."' AND Pro_Codigo = '".$_POST['Pro_Codigo']."'";
$inventario = mysql_query($query_inventario, $conex) or die(mysql_error());
$row_inventario = mysql_fetch_assoc($inventario);
$totalRows_inventario = mysql_num_rows($inventario);
	$stock = $row_inventario['Inv_Stock'] + $_POST['Rec_Cantidad'];
	
	//Actualizar la cantidad si el producto ya esxiste en el almacen
	if ($totalRows_inventario > 0){
	 $updateSQL = "UPDATE inventario SET Inv_Stock = $stock WHERE Alm_Codigo = '".$_GET['almacen']."' AND Pro_Codigo = '".$_POST['Pro_Codigo']."'";
	 mysql_select_db($database_conex, $conex);
	 $update = mysql_query($updateSQL, $conex) or die(mysql_error());
	}
	else{
	//Registrar el producto y la cantidad si el producto no esxiste en el almacen
		$insertSQL2 = sprintf("INSERT INTO inventario (Inv_Serie, Alm_Codigo, Pro_Codigo, Inv_Stock) VALUES (%s, %s, %s, %s)",
                       GetSQLValueString($_POST['Inv_Serie'], "int"),
                       GetSQLValueString($_GET['almacen'], "text"),
                       GetSQLValueString($_POST['Pro_Codigo'], "text"),
                       GetSQLValueString($stock, "int"));

  mysql_select_db($database_conex, $conex);
  $Result2 = mysql_query($insertSQL2, $conex) or die(mysql_error());
		}
//Redireccionar la pagina para que se actualicen los nuevos datos
echo "<script language='Javascript'>location.href='add_recepcion_detalle.php?&recepcion=".$_GET['recepcion']."&almacen=".$_GET['almacen']."&odc=".$_POST['odc']."&solicitud=".$_POST['Rec_Solicitud']."';</script>";
}

if ($_POST['Rec_Lote'] == "" || $_POST['Rec_Paleta'] == "" || $_POST['Rec_Entrega'] == ""){ $error = 1; }

if ($_POST['Rec_Cantidad'] <= $_POST['recibir']){$val = 1;}

if (($_GET['solicitud'] <> "" || $_GET['odc'] <> "") && $_POST['buscar'] == "") {
	$_POST['buscar'] == 'Buscar';
mysql_select_db($database_conex, $conex);
$query_solicitud = sprintf("SELECT Sol_Serial, Sol_Odc, Sol_Status, Pro_Nombre FROM solicitud, proveedor WHERE Pro_Codigo = Sol_Proveedor AND  Sol_Serial = '".$_GET['solicitud']."' AND Sol_Odc = '".$_GET['odc']."'");
if ($_GET['odc']<>"" && $_GET['solicitud']==""){$query_solicitud = sprintf("SELECT Sol_Serial, Sol_Odc, Sol_Status, Pro_Nombre FROM solicitud, proveedor WHERE Pro_Codigo = Sol_Proveedor AND Sol_Odc = '".$_GET['odc']."'");}
if ($_GET['solicitud']<>"" && $_GET['odc']==""){$query_solicitud = sprintf("SELECT Sol_Serial, Sol_Odc, Sol_Status, Pro_Nombre FROM solicitud, proveedor WHERE Pro_Codigo = Sol_Proveedor AND  Sol_Serial = '".$_GET['solicitud']."'");}
if ($_GET['solicitud']<>"" && $_GET['odc']<>""){$query_solicitud = sprintf("SELECT Sol_Serial, Sol_Odc, Sol_Status, Pro_Nombre FROM solicitud, proveedor WHERE Pro_Codigo = Sol_Proveedor AND  Sol_Serial = '".$_GET['solicitud']."' AND Sol_Odc = '".$_GET['odc']."'");}
$solicitud = mysql_query($query_solicitud, $conex) or die(mysql_error());
$row_solicitud = mysql_fetch_assoc($solicitud);
$totalRows_solicitud = mysql_num_rows($solicitud);
} else {

$query_solicitud = sprintf("SELECT Sol_Serial, Sol_Odc, Sol_Status, Pro_Nombre FROM solicitud, proveedor WHERE Pro_Codigo = Sol_Proveedor AND  Sol_Serial = '".$_POST['solicitud']."' AND Sol_Odc = '".$_POST['odc']."'");
if ($_POST['odc']<>"" && $_POST['solicitud']==""){$query_solicitud = sprintf("SELECT Sol_Serial, Sol_Odc, Sol_Status, Pro_Nombre FROM solicitud, proveedor WHERE Pro_Codigo = Sol_Proveedor AND Sol_Odc = '".$_POST['odc']."'");}
if ($_POST['solicitud']<>"" && $_POST['odc']==""){$query_solicitud = sprintf("SELECT Sol_Serial, Sol_Odc, Sol_Status, Pro_Nombre FROM solicitud, proveedor WHERE Pro_Codigo = Sol_Proveedor AND  Sol_Serial = '".$_POST['solicitud']."'");}
if ($_POST['solicitud']<>"" && $_POST['odc']<>""){$query_solicitud = sprintf("SELECT Sol_Serial, Sol_Odc, Sol_Status, Pro_Nombre FROM solicitud, proveedor WHERE Pro_Codigo = Sol_Proveedor AND  Sol_Serial = '".$_POST['solicitud']."' AND Sol_Odc = '".$_POST['odc']."'");}
$solicitud = mysql_query($query_solicitud, $conex) or die(mysql_error());
$row_solicitud = mysql_fetch_assoc($solicitud);
$totalRows_solicitud = mysql_num_rows($solicitud);	
	}
?>


<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>detalle de recepcion</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="../js/ajax.js"></script>
<script type="text/javascript">
function Vmodal(valor,sol,pro,nombre,diff,desc){
	var str=encodeURIComponent(desc);
	document.getElementById("bgVentanaModal").style.visibility=valor;
	document.getElementById("Rec_Solicitud").value=sol;
	document.getElementById("Pro_Codigo").value=pro;
	document.getElementById("recibir").value=diff;
	document.getElementById("nombre").value= nombre.replace(/\+/g,' ');
	document.getElementById('detalle_producto').innerHTML=pro +' - '+ nombre.replace(/\+/g,' ');
	} 
</script>

<script type="text/javascript">
var total=0;
function sumar() {
var n1 = parseInt(document.getElementById('Rec_Paleta').value);
var n2 = parseInt(document.getElementById('Rec_Cxu').value);
var total=n1*n2;

 //Compruebo si es un valor num�rico 
      if (!isNaN(total)) {
			document.getElementById('Rec_Cantidad').value=total;
	  } else{
		   document.getElementById('Rec_Cantidad').value=0;
	  }
}
</script>



<style type="text/css">
#bgVentanaModal
{
   background-image: url(../Img/maskBG.png);
   position: fixed;
   z-index: 1;
   height: 100%;
   width: 100%;
   left: 0px;
   top: 0px;
   visibility: hidden;
   overflow:scroll;
   overflow-style:auto;
}

#Ventanamodal
{
   background-color: #FFF;
   border: 6px solid #CCC;
   position: absolute;
   height: 607px;
   width: 550px;
   left: 50%;
   top: 50%;
   clip: rect(-300px, auto, auto, -300px);
   margin-top: -300px;
   margin-right: 0px;
   margin-bottom: 0px;
   margin-left: -300px;
}
</style>

</head>

<body>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="40" align="center" valign="bottom"><h3> Detalle de Recepci&oacute;n de Productos</h3></td>
    </tr>
  </table>
  <table width="95%" border="0" align="center" cellpadding="5" cellspacing="2">
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td class="Tcabeza">&nbsp;</td>
    </tr>
  </table>
  <form name="form1" method="post" action="">
    <table width="95%" border="0" align="center" cellpadding="5" cellspacing="2">
    <tr>
      <td width="25%">&nbsp;</td>
      <td width="25%">&nbsp;</td>
      <td width="25%">&nbsp;</td>
      <td width="25%">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="4" class="Tcabeza"><h2>Datos de la solicitud de producto</h2></td>
      </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td colspan="2">
        <label for="odc">Orden de compra</label>
        <input value="<?php if (isset($_POST['odc'])) {echo htmlentities($_POST['odc']);} ?>" name="odc" type="text" class="textInput" id="odc">      </td>
      <td colspan="2">
        <label for="solicitud">Referencia Solicitud/BOL:</label>
        <input value="<?php if (isset($_POST['solicitud'])) {echo htmlentities($_POST['solicitud']);} ?>" name="solicitud" type="text" class="textInput" id="solicitud">
      </td>
      </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td colspan="4" class="Tcabeza">&nbsp;</td>
      </tr>
    <tr>
      <td colspan="5"><input name="buscar" type="submit" class="button der" id="buscar" value="Buscar"></td>
      </tr>
  </table>
</form>
  <?php if ($totalRows_solicitud == 0 && array_key_exists ('buscar', $_POST) ) { // Show if recordset empty ?>
  <table width="95%" border="0" align="center" cellpadding="5" cellspacing="2">
    <tr>
      <td align="center"><h3>No hay resultados</h3></td>
    </tr>
  </table>
  <?php } // Show if recordset empty ?>
  <?php if ($totalRows_solicitud > 0 ) { // Show if recordset not empty ?>
  <table width="95%" border="0" align="center" cellpadding="0" cellspacing="0" style="clear:left;">
    <?php do { ?>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td bgcolor="#0099FF">
          <h3 style="color:#fff; font-weight:normal; padding: 5px;">Solicitud <span style="color:#FF0; font-size:16px;"><?php echo $row_solicitud['Sol_Serial']; ?> </span>asociada a la orden de compra <span style="color: #FF0; font-size:16px;"><?php echo $row_solicitud['Sol_Odc']; ?></span> del proveedor <?php echo $row_solicitud['Pro_Nombre']; ?> con estatus <span style="color: #FF0; font-size:16px;">
            <?php 
		  if ($row_solicitud['Sol_Status']=='E') echo "Esperando carga de costos de adquisicion"; 
		  if ($row_solicitud['Sol_Status']=='C') echo "Costos de adquisicion cargados"; 
		  if ($row_solicitud['Sol_Status']=='N') echo "No aplican costos de adquisicion"; 
		  ?>
            </span>
          </h3></td>
      </tr>
      <tr>
        <td><?php
			 	mysql_select_db($database_conex, $conex);
$query_detalle_solicitud = "SELECT sp_Productos, Pro_Nombre, Pro_Empaque, Pro_Peso, Pro_Unidad, Sp_Cantidad, Sp_Serial FROM solpro, productos WHERE Pro_Codigo=sp_Productos AND Sp_Solicitud = '".$row_solicitud['Sol_Serial']."'";
$detalle_solicitud = mysql_query($query_detalle_solicitud, $conex) or die(mysql_error());
$row_detalle_solicitud = mysql_fetch_assoc($detalle_solicitud);
$totalRows_detalle_solicitud = mysql_num_rows($detalle_solicitud);
			?>
          <table width="100%" border="0" cellpadding="1" cellspacing="1">
            <tr>
              <td width="65%" class="Tcabeza"><p>Producto</p></td>
              <td width="10%" class="Tcabeza"><p class="textCenter">Solitidado</p></td>
              <td width="10%" class="Tcabeza"><p class="textCenter">Por recibir</p></td>
              <td width="10%" class="Tcabeza"><p class="textCenter">Recibido</p></td>
              <td width="5%" class="Tcabeza"><p class="textCenter">Recibir</p></td>
            </tr>
            <?php do { ?>
              <tr>
                <td width="40%" class="lineaInfPunta"><p><?php echo $row_detalle_solicitud['sp_Productos']; ?> - <?php echo $row_detalle_solicitud['Pro_Nombre']; ?>, <?php echo $row_detalle_solicitud['Pro_Empaque']; ?> de <?php echo $row_detalle_solicitud['Pro_Peso']; ?> <?php echo $row_detalle_solicitud['Pro_Unidad']; ?></p></td>
                <td width="10%" class="lineaInfPunta"><p class="textCenter"><?php echo $row_detalle_solicitud['Sp_Cantidad']; ?></p></td>
                <td width="10%" class="lineaInfPunta textCenter">
                <?php  
					// Variable de control de recibido
					$con_Recibido = 0;
					mysql_select_db($database_conex, $conex);
					$query_recibido = "SELECT Rec_Cantidad FROM recepcion WHERE Rec_Solicitud = '".$row_solicitud['Sol_Serial']."' AND Pro_Codigo = '".$row_detalle_solicitud['sp_Productos']."'";
					$recibido = mysql_query($query_recibido, $conex) or die(mysql_error());
					$row_recibido = mysql_fetch_assoc($recibido);
					$totalRows_recibido = mysql_num_rows($recibido);

						do {
							$con_Recibido= $con_Recibido + $row_recibido['Rec_Cantidad'];
							}  while ($row_recibido = mysql_fetch_assoc($recibido)); 	 
					
					$por_recibir = $row_detalle_solicitud['Sp_Cantidad']-$con_Recibido;
					echo '<p class="textCenter">'.$por_recibir.'</p>';
?></td>
                <td width="10%" class="lineaInfPunta textCenter">
               <?php  
					// Variable de control de recibido
					$con_Recibido = 0;
					mysql_select_db($database_conex, $conex);
					$query_recibido = "SELECT Rec_Cantidad FROM recepcion WHERE Rec_Solicitud = '".$row_solicitud['Sol_Serial']."' AND Pro_Codigo = '".$row_detalle_solicitud['sp_Productos']."'";
					$recibido = mysql_query($query_recibido, $conex) or die(mysql_error());
					$row_recibido = mysql_fetch_assoc($recibido);
					$totalRows_recibido = mysql_num_rows($recibido);

						do {
							$con_Recibido= $con_Recibido + $row_recibido['Rec_Cantidad'];
							}  while ($row_recibido = mysql_fetch_assoc($recibido)); 	 
					
					echo '<p class="textCenter">'.$con_Recibido.'</p>';
					
?>
                </td>
                <td width="5%" class="lineaInfPunta textCenter">
                <a href=javascript:Vmodal('visible',"<?php echo $row_solicitud['Sol_Serial'] ?>",'<?php echo $row_detalle_solicitud['sp_Productos'];?>','<?php echo urlencode($row_detalle_solicitud['Pro_Nombre']); ?>','<?php echo $por_recibir; ?>');><span class="icon-nuevo"> &nbsp;</span></a>
                </td>
              </tr>
              <?php } while ($row_detalle_solicitud = mysql_fetch_assoc($detalle_solicitud)); ?>
          </table>
          <table width="100%" border="0" cellspacing="2" cellpadding="5">
            <tr>
              <td bgcolor="#333333"></td>
            </tr>
          </table>
          <p>&nbsp;</p></td>
      </tr>
      <?php } while ($row_solicitud = mysql_fetch_assoc($solicitud)); ?>
  </table>
  <?php } // Show if recordset not empty ?>
  <?php if ($totalRows_agregados > 0) { // Show if recordset not empty ?>
  <table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td align="right" valign="middle"><p class="der"><a href="pdf_recepcion.php?recepcion=<?php echo $_GET['recepcion']; ?>" target="_blank">Imprimir</a></p></td>
    </tr>
    <tr>
      <td valign="middle" class="Tcabeza" style="background-color:#F60; border:0px;">
        <h1 class="izq" style="padding-left:10px;">Recepci&oacute;n de Producto</h1>
        <h2 class="clearIt der" style="color:black; padding-right:10px;"><?php echo $_GET['recepcion']; ?></h2>
        </td>
    </tr>
    <tr>
      <td>
        <table width="100%" border="0" align="center" cellpadding="3" cellspacing="0">
          <tr>
            <td width="5%" class="Tcabeza"><p class="textCenter">L&iacute;nea</p></td>
            <td width="30%" class="Tcabeza"><p>Lote</p></td>
            <td width="5%" class="Tcabeza"><p class="textCenter">Bulto(s)</p></td>
            <td width="5%" class="Tcabeza"><p class="textCenter">Unidades</p></td>
            <td width="5%" class="Tcabeza"><p class="textCenter">Recibido</p></td>
            <td width="10%" class="Tcabeza"><p class="textCenter">Muestra</p></td>
            <td width="10%" class="Tcabeza"><p class="textCenter">Embalaje</p></td>
            <td width="10%" class="Tcabeza"><p class="textCenter">Documento de entrega</p></td>
            <td width="10%" class="Tcabeza"><p class="textCenter">Total</p></td>
            <td width="5%" class="Tcabeza"><p class="textCenter">Etiqueta</p></td>
            <td width="5%" class="Tcabeza"><p class="textCenter">Eliminar</p></td>
          </tr>
          <?php do { $numero ++; ?>
            <tr>
              <td width="5%" class="lineaInfPunta"><?php 
					mysql_select_db($database_conex, $conex);
$query_linea = "
SELECT Rec_Serial, Rec_Lote, Rec_Paleta, Rec_Cxu, Rec_Cantidad, Rec_Prueba, Rec_Embalaje, Rec_Entrega
FROM recepcion
WHERE Pro_Codigo =  '".$row_agregados['Pro_Codigo']."'
AND Rec_Solicitud = '".$row_agregados['Rec_Solicitud']."'
";
$linea = mysql_query($query_linea, $conex) or die(mysql_error());
$row_linea = mysql_fetch_assoc($linea);
$totalRows_linea = mysql_num_rows($linea);
				  ?>
              <p class="textCenter"><strong><?php echo $numero; ?></strong></p></td>
              <td colspan="3" class="lineaInfPunta"><p><strong><?php echo $row_agregados['Descripcion']; ?></strong></p></td>
              <td colspan="2" class="lineaInfPunta"><p><strong>Orden de Compra :</strong> <?php echo $row_agregados['Sol_Odc']; ?></p></td>
              <td colspan="2" class="lineaInfPunta"><p><strong>Solicitud/BOL :</strong> <?php echo $row_agregados['Rec_Solicitud']; ?></p></td>
              <td width="10%" class="lineaInfPunta"><p class="colorTextRojo textCenter" style="font-size:16px;"><?php echo $row_agregados['Total']; ?></p></td>
              <td width="5%" class="lineaInfPunta">&nbsp;</td>
              <td width="5%" class="lineaInfPunta">&nbsp;</td>
            </tr>
            
              <?php do { ?>
             <tr>
             <td>&nbsp;</td>
              <td width="30%">
				    <p><?php echo $row_linea['Rec_Lote']; ?></p>
              </td>
              <td width="5%">
				    <p class="textCenter"><?php echo $row_linea['Rec_Paleta']; ?></p>
              </td>
              <td width="5%">
				    <p class="textCenter"><?php echo $row_linea['Rec_Cxu']; ?></p>
              </td>
              <td width="5%">
				    <p class="textCenter"><?php echo $row_linea['Rec_Cantidad']; ?></p>
              </td>
              <td width="10%">
				    <p class="textCenter">
                <?php $NC=$row_linea['Rec_Prueba']; echo  $_GET['almacen']."-". str_pad($NC, 5, 0, STR_PAD).'-'.date('y'); ?>
                </p>
              </td>
              <td width="10%">
				    <p class="textCenter">
					 <?php if ($row_linea['Rec_Embalaje'] == 'o') echo 'Optimo'; ?>
                <?php if ($row_linea['Rec_Embalaje'] == 'b') echo 'Bueno'; ?>
                <?php if ($row_linea['Rec_Embalaje'] == 'r') echo 'Regular'; ?>
                <?php if ($row_linea['Rec_Embalaje'] == 'd') echo 'Defectuoso'; ?>
                </p>
              </td>
              <td width="10%">
				    <p class="textCenter"><?php echo $row_linea['Rec_Entrega']; ?></p>
              </td>
              <td width="10%">&nbsp;</td>
            <td width="5%" align="center" valign="bottom">
            <a href="report_etiqueta.php?codigo=<?php echo $row_agregados['Pro_Codigo']; ?>&lote=<?php echo $row_linea['Rec_Lote']; ?>&uxp=<?php echo $row_linea['Rec_Cxu']; ?>" target="_new"><img src="../Img/rombo-nfpa.gif" width="13" height="13" alt="Etiqueta"></a>
            </td>
            <td width="5%" align="center" valign="middle"><a href="del_recepcion_item.php?&producto=<?php echo $row_agregados['Pro_Codigo'];?>&almacen=<?php echo $_GET['almacen']; ?>&recepcion=<?php echo $_GET['recepcion']; ?>&cantidad=<?php echo $row_linea['Rec_Cantidad']; ?>&linea=<?php echo $row_linea['Rec_Serial']; ?>"><span class="icon-del">&nbsp;</span></a></td>
             </tr>
              <?php } while ($row_linea = mysql_fetch_assoc($linea)); ?>
            
            <tr>
              </tr>
            <?php } while ($row_agregados = mysql_fetch_assoc($agregados)); ?>
        </table></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td bgcolor="#333333">&nbsp;</td>
    </tr>
  </table>
  <?php } // Show if recordset not empty ?>
<p>&nbsp;</p>
<!--  
<table width="95%" border="0" align="center" cellpadding="5" cellspacing="2">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td class="Tcabeza">&nbsp;</td>
  </tr>
</table>
-->

<!-- -->
<div id="bgVentanaModal">
<div id="Ventanamodal">





<form method="post" name="form2" action="<?php echo $editFormAction; ?>">
    <table width="100%" border="0" cellspacing="0" cellpadding="5">
      <tr>
        <td class="Tcabeza" style="min-height:25%;">
         <h2>Datos de recepci&oacute;n <span style="font-size:14px; padding-top:0px;" class="der"><input type="reset" value="X" onClick="javascript:Vmodal('hidden');" style="font-family: Arial, Helvetica, sans-serif;	font-size: 12px; color: #333; width:30px; height:20px; font-weight:bold; cursor:pointer;"/> </span></h2>
        </td>
      </tr>
      <tr>
        <td><table width="90%" border="0" align="center" cellpadding="5" cellspacing="2">
          <tr valign="baseline">
            <td colspan="2" align="left" class="lineaInfPunta" nowrap><h3>Producto: <div id="detalle_producto" style="font-size:14px; color:#090;"></div></h3></td>
          </tr>
          <tr valign="baseline">
            <td nowrap align="left"><label>Lote:
              <?php if ($_POST && $_POST['Rec_Lote'] == "") { echo $icono;}?>
            </label>
              <input name="Rec_Lote" id="Rec_Lote" type="text" class="textInput mayusculas" value="<?php if (isset($_POST['Rec_Lote'])) {echo htmlentities($_POST['Rec_Lote']);} ?>" size="32" onBlur="BuscarLote();" onKeyUp="BuscarLote();"></td>
            <td>&nbsp;</td>
          </tr>
          <tr valign="baseline">
            <td nowrap align="right"><label>Paleta(s):
              <?php if ($_POST && $_POST['Rec_Paleta'] == "") { echo $icono;}?>
            </label>
              <input name="Rec_Paleta" id="Rec_Paleta" type="text" class="textInput textCenter" value="<?php if (isset($_POST['Rec_Paleta'])) {echo htmlentities($_POST['Rec_Paleta']);} ?>" size="32" onChange="sumar();"  onKeyUp="sumar();" autocomplete="off" ></td>
            <td><label>Cantidad por unidad:
              <?php if ($_POST && $_POST['Rec_Cxu'] == "") { echo $icono;}?>
            </label>
              <input name="Rec_Cxu" id="Rec_Cxu" type="text" class="textInput textCenter" value="<?php if (isset($_POST['Rec_Cxu'])) {echo htmlentities($_POST['Rec_Cxu']);} ?>" size="32" onChange="sumar();"  onKeyUp="sumar();" autocomplete="off" ></td>
          </tr>
          <tr valign="baseline">
            <td align="right" valign="baseline" nowrap>
            <label class="der">Cantidad a recibir:</label>
            </td>
            <td><input name="Rec_Cantidad" type="text" class="textInput colorTextRojo textCenter" style="font-size:18px;" id="Rec_Cantidad" value="<?php if (isset($_POST['Rec_Cantidad'])) {echo htmlentities($_POST['Rec_Cantidad']);} ?>" size="32" readonly></td>
          </tr>
          <tr valign="baseline">
            <td width="50%" align="right" nowrap></td>
            <td width="50%">&nbsp;</td>
          </tr>
          <tr valign="baseline">
            <td nowrap align="right">&nbsp;</td>
            <td><label class="textCenter">Numero de prueba:</label>
            <div id="lote">
              <input name="Rec_Prueba" type="text" class="textInput colorTextRojo textCenter" value="<?php if (isset($_POST['Rec_Prueba'])) {echo htmlentities($_POST['Rec_Prueba']);} ?>" size="32" readonly></div></td>
          </tr>
          <tr valign="baseline">
            <td nowrap align="right">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr valign="baseline">
            <td nowrap align="right"><label>Estado del embalaje:</label>
              <select name="Rec_Embalaje" class="select">
                <option value="o">Optimo</option>
                <option value="b">Bueno</option>
                <option value="r">Regular</option>
                <option value="d">Defectuoso</option>
              </select></td>
            <td><label>Documento de entrega:
              <?php if ($_POST && $_POST['Rec_Entrega'] == "") { echo $icono;}?>
            </label>
              <input name="Rec_Entrega" type="text" class="textInput" value="<?php echo $_POST['Rec_Entrega'] ?>" size="32"></td>
          </tr>
          <tr valign="baseline">
            <td nowrap align="right">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr valign="baseline">
            <td colspan="2" align="right" nowrap><input type="hidden" name="MM_insert" value="form2">
              <input name="Rec_Numero" type="hidden" class="textInput" value="<?php echo $_GET['recepcion']; ?>" size="32">
              <input name="Rec_Solicitud" id="Rec_Solicitud" type="hidden" class="textInput" value="" size="32">
              <input name="Pro_Codigo" id="Pro_Codigo" type="hidden" class="textInput" value="" size="32">
              <input name="recibir" id="recibir" type="hidden" class="textInput" value="" size="32">
              <input name="nombre" id="nombre" type="hidden" class="textInput" value="<?php if ($_POST['nombre']==$_POST['nombre']) {echo htmlentities($_POST['nombre']);} ?>" size="32">
              <input name="Rec_Certificado" type="hidden" class="textInput" value="0" size="32" readonly>
              <input name="enviar" type="submit" class="button der" id="enviar" value="Registrar">
              <input name="Restablecer" type="reset" class="button der" value="Restablecer"></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td valign="top" class="Tcabeza" style="height:62px;">
		  <?php if ($error == 1 && array_key_exists ('enviar', $_POST)) echo $incompleto; ?>
        <?php if ($_POST['Rec_Cantidad'] > $_POST['recibir']) {echo '<p class="colorTextRojo" style="font-weight:bold;"> *** La cantidad que intenta recibir es mayor a lo pendiente por recibir</p>'; $val=1; }?>
        </td>
      </tr>
    </table>
</form>
</div>
</div>
<?php  if (array_key_exists ('enviar', $_POST) && ($error == 1 || $val == 1)) {echo "<script language='JavaScript'> Vmodal('visible','".$_POST['Rec_Solicitud']."','".$_POST['Pro_Codigo']."','".$_POST['nombre']."','".$_POST['recibir']."' ); </script>"; $_POST['nombre']="";} ?>
<pre>
<?php if ($_POST) {print_r($_POST);} ?>
</pre>
</body>
</html>