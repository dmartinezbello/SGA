<?php //initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
  
  echo "<script> if (parent.frames.length > 0) { parent.location.href = '../index2.php'}</script>";
	
}
?>
<?php require_once('../Connections/conex.php'); ?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "../index2.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php include('mensajes.php'); ?>
<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
mysql_select_db($database_conex, $conex);
$query_recobro = "SELECT Rec_Serial FROM recobro  WHERE Rec_Serial LIKE '%".$_POST['Rec_Almacen']."%'";
$recobro = mysql_query($query_recobro, $conex) or die(mysql_error());
$row_recobro = mysql_fetch_assoc($recobro);
$totalRows_recobro = mysql_num_rows($recobro);

$colname_conductor = "-1";
if (isset($_POST['Rec_Conductor'])) {
  $colname_conductor = $_POST['Rec_Conductor'];
}
mysql_select_db($database_conex, $conex);
$query_conductor = sprintf("SELECT Con_Cedula FROM conductor WHERE Con_Cedula = %s", GetSQLValueString($colname_conductor, "text"));
$conductor = mysql_query($query_conductor, $conex) or die(mysql_error());
$row_conductor = mysql_fetch_assoc($conductor);
$totalRows_conductor = mysql_num_rows($conductor);


$colname_vehiculo = "-1";
if (isset($_POST['Rec_Vehiculo'])) {
  $colname_vehiculo = $_POST['Rec_Vehiculo'];
}
mysql_select_db($database_conex, $conex);
$query_vehiculo = sprintf("SELECT Veh_Placa FROM vehiculos WHERE Veh_Placa = %s", GetSQLValueString($colname_vehiculo, "text"));
$vehiculo = mysql_query($query_vehiculo, $conex) or die(mysql_error());
$row_vehiculo = mysql_fetch_assoc($vehiculo);
$totalRows_vehiculo = mysql_num_rows($vehiculo);

// Declaracion de variables
$numero= $totalRows_recobro + 1;
$codigo=$_POST['Rec_Almacen'].'-'.str_pad($numero, 8, 0, STR_PAD);
echo $codigo;
$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1") && $_POST['Rec_Conductor']<>"" && $_POST['Rec_Vehiculo']<>"" && $totalRows_vehiculo > 0 && $totalRows_conductor > 0) {
  $insertSQL = sprintf("INSERT INTO recobro (Rec_Serial, Rec_Estatus, Rec_Fecha, Rec_Recepcion, Rec_Almacen, Rec_Conductor, Rec_Vehiculo, Rec_Observaciones, Rec_Usuario) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($codigo, "text"),
                       GetSQLValueString($_POST['Rec_Estatus'], "text"),
                       GetSQLValueString($_POST['Rec_Fecha'], "date"),
                       GetSQLValueString($_POST['Rec_Recepcion'], "date"),
                       GetSQLValueString($_POST['Rec_Almacen'], "text"),
                       GetSQLValueString($_POST['Rec_Conductor'], "text"),
                       GetSQLValueString(strtoupper($_POST['Rec_Vehiculo']), "text"),
                       GetSQLValueString($_POST['Rec_Observaciones'], "text"),
                       GetSQLValueString($_POST['Rec_Usuario'], "text"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
  
  //Borrar el array de datos, Enviar mensaje de registro exitoso y redireccion a la lista de registros
				 echo "<script language='JavaScript'> alert('*** El proceso de registro se realizo con exito');</script>";
 				 if ($url == ""){ echo "<script language='Javascript'>location.href='add_recobro_detalle.php?&recobro=".$codigo."&almacen=".$_POST['Rec_Almacen']."';</script>";}
				 $_POST = array();
  
}else {$error=1;}

mysql_select_db($database_conex, $conex);
$query_almacen = "SELECT Alm_Codigo, Alm_Nombre FROM almacen ORDER BY Alm_Nombre ASC";
$almacen = mysql_query($query_almacen, $conex) or die(mysql_error());
$row_almacen = mysql_fetch_assoc($almacen);
$totalRows_almacen = mysql_num_rows($almacen);






?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>recobros</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="../librerias/calendario/jquery.datetimepicker.css"/>
<link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="../js/ajax.js"></script>
<script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
</head>

<body>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="40" align="center" valign="bottom"><h3>Solicitud de Recobro de Productos</h3></td>
    </tr>
  </table>
  <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
    <table width="95%" border="0" align="center" cellpadding="5" cellspacing="2">
      <tr valign="baseline">
        <td align="right" nowrap>&nbsp;</td>
        <td colspan="2" nowrap><?php if ($_POST && $error == 1) { echo $incompleto."<BR>";}?></td>
        <td align="right" nowrap>&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td colspan="4" nowrap class="Tcabeza"><h2>Datos del recobro de productos</h2></td>
      </tr>
      <tr valign="baseline">
        <td width="20%" align="right" nowrap>&nbsp;</td>
        <td width="30%" align="right" nowrap>&nbsp;</td>
        <td width="30%"><label>Estatus:</label>
          <select name="Rec_Estatus" class="select" id="Rec_Estatus">
            <option value="t">En transito</option>
            <option value="e">Ejecutado</option>
            <option value="c">Cancelado</option>
        </select></td>
        <td width="20%">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td align="right" nowrap>&nbsp;</td>
        <td align="right" nowrap>
        <label>Fecha de Solicitud:</label>
        <input name="Rec_Fecha" type="text" class="textInput" id="Rec_Fecha" value="" size="32" readonly>
        </td>
        <td><label>Fecha de recepci&oacute;n en almac&eacute;n:</label>
        <input name="Rec_Recepcion" type="text" class="textInput" id="Rec_Recepcion" value="" size="32" readonly></td>
        <td>&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td align="right" nowrap>&nbsp;</td>
        <td align="right" nowrap><label>Almac&eacute;n que recibe:</label>
          <select name="Rec_Almacen" class="select" id="Rec_Almacen">
            <?php
do {  
?>
            <option value="<?php echo $row_almacen['Alm_Codigo']?>"><?php echo $row_almacen['Alm_Nombre']?></option>
            <?php
} while ($row_almacen = mysql_fetch_assoc($almacen));
  $rows = mysql_num_rows($almacen);
  if($rows > 0) {
      mysql_data_seek($almacen, 0);
	  $row_almacen = mysql_fetch_assoc($almacen);
  }
?>
        </select></td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td align="right" nowrap>&nbsp;</td>
        <td align="right" nowrap><label>Licencia del conductor:
            <?php if ($_POST && $_POST['Rec_Conductor'] == "") { echo $icono;}?>
            <?php if ($_POST && $totalRows_conductor == 0) { echo '<span style="color:red;">No existe</span>';}?>
        </label>
          <span id="sprytextfield1">
          <input name="Rec_Conductor" id="Con_Cedula" type="text" class="textInput" value="<?php if (isset($_POST['Rec_Conductor'])) {echo htmlentities($_POST['Rec_Conductor']);} ?>" size="32" onBlur="Conductor();">
<span class="textfieldInvalidFormatMsg">Formato no válido.</span></span></td>
        <td valign="bottom"><div id="conductor">&nbsp;</div></td>
        <td>&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td align="right" nowrap>&nbsp;</td>
        <td align="right" nowrap><label>Placa del veh&iacute;culo:
          <?php if ($_POST && $_POST['Rec_Vehiculo'] == "") { echo $icono;}?>
          <?php if ($_POST && $totalRows_vehiculo == 0) { echo '<span style="color:red;">No existe</span>';}?>
        </label>
        <input name="Rec_Vehiculo" id="Veh_Placa" type="text" class="textInput mayusculas" value="<?php if (isset($_POST['Rec_Vehiculo'])) {echo htmlentities($_POST['Rec_Vehiculo']);} ?>" size="32" onBlur="Vehiculo();"></td>
        <td valign="bottom"><div id="vehiculo">&nbsp;</div></td>
        <td>&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td align="right" nowrap>&nbsp;</td>
        <td colspan="2" align="right" nowrap><label>Observaciones: </label>
        <textarea name="Rec_Observaciones" cols="32" rows="3"><?php if (isset($_POST['Rec_Observaciones'])) {echo htmlentities($_POST['Rec_Observaciones']);} ?></textarea></td>
        <td>&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td align="right" nowrap>&nbsp;</td>
        <td align="right" nowrap>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td colspan="4" align="right" nowrap class="Tcabeza">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td colspan="4" align="right" nowrap><input name="enviar" type="submit" class="button der" id="enviar" value="Registrar">
          <input name="Restablecer" type="reset" class="button der" value="Restablecer">
          <input type="button" class="button der" onClick="history.back()" value="Volver" >
          <input type="button" class="button der" onClick="location.href='cuerpo.php'" value="Cancelar" /></td>
      </tr>
    </table>
    <input type="hidden" name="MM_insert" value="form1">
    <input type="hidden" name="Rec_Usuario" value="<?php echo $_SESSION['MM_Username']; ?>" size="32">
    <input name="Rec_Serial" type="hidden" class="textInput" value="" size="32">
  </form>
  <p>&nbsp;</p>
  <script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "custom", {pattern:"00.000.000", useCharacterMasking:true, isRequired:false});
  </script>
</body>
<script src="../librerias/calendario/jquery.js"></script>
<script src="../librerias/calendario/jquery.datetimepicker.js"></script>
<script>

$('#datetimepicker_mask').datetimepicker({
	mask:'9999/19/39 29:59:00'
});
$('#Rec_Fecha').datetimepicker({value:'<?php echo date("Y-m-d H:i:s"); ?>',step:10});
$('#Rec_Recepcion').datetimepicker({value:'<?php echo date("Y-m-d H:i:s"); ?>',step:10});

</script>
</html>
<?php
mysql_free_result($almacen);

mysql_free_result($recobro);

mysql_free_result($vehiculo);

mysql_free_result($conductor);
?>
