<?php require_once('../Connections/conex.php'); ?>
<?php include('mensajes.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_duplicado = "-1";
if (isset($_POST['Sol_Serial'])) {
  $colname_duplicado = $_POST['Sol_Serial'];
}
mysql_select_db($database_conex, $conex);
$query_duplicado = sprintf("SELECT Sol_Serial FROM solicitud WHERE Sol_Serial = %s", GetSQLValueString($colname_duplicado, "text"));
$duplicado = mysql_query($query_duplicado, $conex) or die(mysql_error());
$row_duplicado = mysql_fetch_assoc($duplicado);
$totalRows_duplicado = mysql_num_rows($duplicado);

mysql_select_db($database_conex, $conex);
$query_proveedores = "SELECT Pro_Codigo, Pro_Nombre FROM proveedor ORDER BY Pro_Nombre ASC";
$proveedores = mysql_query($query_proveedores, $conex) or die(mysql_error());
$row_proveedores = mysql_fetch_assoc($proveedores);
$totalRows_proveedores = mysql_num_rows($proveedores);
?>
<?php include('mensajes.php'); ?>
<?php
$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

// Validar campos vacios y requeridos
	$error = 0;
	if (array_key_exists ('enviar', $_POST) && $_POST['Sol_Serial']<>"" && $_POST['Sol_Odc']<>"" ){
// Validar que no hayan campos duplicados
	$existe = 0;
	if ($totalRows_duplicado == 0){

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO solicitud (Sol_Serial, Sol_Odc, Sol_Status, Sol_Proveedor) VALUES (%s, %s, %s, %s)",
                       GetSQLValueString(strtoupper($_POST['Sol_Serial']), "text"),
                       GetSQLValueString($_POST['Sol_Odc'], "text"),
                       GetSQLValueString($_POST['Sol_Status'], "text"),
							  GetSQLValueString($_POST['Sol_Proveedor'], "text"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
  
  //Borrar el array de datos, Enviar mensaje de registro exitoso y redireccion a la lista de registros
				 echo "<script language='JavaScript'> alert('*** El proceso de registro se realizo con exito');</script>";
 				 if ($url == ""){ echo "<script language='Javascript'>location.href='add_solicitudDetalle.php?solicitud=".$_POST['Sol_Serial']."';</script>";}
				 $_POST = array();

	}}else {if (array_key_exists ('enviar', $_POST)){$existe=1;}}
	}else {if (array_key_exists ('enviar', $_POST)){$error=1;}}
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Solicitud de productos</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="40" align="center" valign="bottom"><h3>Registro de Solicitudes de Productos Qu&iacute;micos</h3></td>
    </tr>
  </table>
  <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
    <table width="95%" border="0" align="center" cellpadding="5" cellspacing="2">
      <tr valign="baseline">
        <td colspan="2" nowrap><?php if ($_POST && $error ==1) { echo $incompleto."<BR>";}?></td>
      </tr>
      <tr valign="baseline">
        <td colspan="2" align="left" nowrap class="Tcabeza"><h2>Datos de la solicitud</h2></td>
      </tr>
      <tr valign="baseline">
        <td width="50%" align="right" nowrap><label>Referencia de solicitud de productos:
          <?php if ($_POST && $_POST['Sol_Serial'] == "") { echo $icono;}?>
          <?php if ($_POST && $totalRows_duplicado > 0) { echo $iconoAzul;}?>
        </label>
          <span class="comentario clearIt">N&uacute;mero de SME / Bill of Lading (BOL)</span>
          <input name="Sol_Serial" type="text" class="textInput mayusculas" value="<?php if (isset($_POST['Sol_Serial'])) {echo htmlentities($_POST['Sol_Serial']);} ?>" size="32"></td>
        <td width="50%"><label>Estatus de carga de costos de adquisici&oacute;n:</label>
          <span class="comentario clearIt">Para las compras locales no no aplica la carga de costos de adquisici&oacute;n</span>
          <select name="Sol_Status" class="select">
            <option value="E" selected>Esperando carga de costos de adquisicion</option>
        		<option value="C"> Costos de adquisicion cargados</option>
        		<option value="N">No aplican costos de adquisicion</option>
        </select></td>
      </tr>
      <tr valign="baseline">
        <td width="50%" align="right" nowrap><label>Orden de compra:
          <?php if ($_POST && $_POST['Sol_Odc'] == "") { echo $icono;}?>
        </label>
          <span class="comentario clearIt">En caso de no tener una orden de compra asignada, colocar cero (0)</span>
          <input name="Sol_Odc" type="text" class="textInput" value="<?php if (isset($_POST['Sol_Odc'])) {echo htmlentities($_POST['Sol_Odc']);} ?>" size="32"></td>
        <td width="50%"><label>Proveedor:</label>
          <span class="comentario clearIt">&nbsp;</span>
          <select name="Sol_Proveedor" class="select" id="Sol_Proveedor">
            <?php
do {  
?>
            <option value="<?php echo $row_proveedores['Pro_Codigo']?>"<?php if (!(strcmp($row_proveedores['Pro_Codigo'], $row_proveedores['Pro_Nombre']))) {echo "selected=\"selected\"";} ?>><?php echo $row_proveedores['Pro_Nombre']?></option>
            <?php
} while ($row_proveedores = mysql_fetch_assoc($proveedores));
  $rows = mysql_num_rows($proveedores);
  if($rows > 0) {
      mysql_data_seek($proveedores, 0);
	  $row_proveedores = mysql_fetch_assoc($proveedores);
  }
?>
          </select>
        </td>
      </tr>
      <tr valign="baseline">
        <td colspan="2"  align="center" valign="middle" bgcolor=<?php if ($_POST && $totalRows_duplicado > 0) { echo '"#FFFF00"';}?>>
        <?php if ($_POST && $totalRows_duplicado > 0) {?>
        <p class="colorTextRojo" style="text-align:center; font-size:16px;"><strong>&iexcl;Ya existen un registro identico! , puede <a href="add_solicitudDetalle.php?solicitud=<?php echo $row_duplicado['Sol_Serial']; ?>">Editarlo</a>,
          <a href="del_solicitud.php?solicitud=<?php echo $row_duplicado['Sol_Serial']; ?>" >Eliminarlo</a> o intentar nuevamente cambiando el valor del campo con el simbolo <img src="../img/icon-obligaAzul.png" width="12" height="12"></strong> </p> 
        <?php }?>
      </tr>
      <tr valign="baseline">
        <td colspan="2" align="right" nowrap class="Tcabeza">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td colspan="2" align="right" nowrap><input name="enviar" type="submit" class="button der" id="enviar" value="Registrar">
          <input name="Restablecer" type="reset" class="button der" value="Restablecer">
          <input type="button" class="button der" onClick="location.href='principal.php'" value="Cancelar" /></td>
      </tr>
    </table>
    <input type="hidden" name="MM_insert" value="form1">
  </form>
  <p>&nbsp;</p>
</body>
</html>