<?php require_once('../Connections/conex.php'); ?>
<?php include('mensajes.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_detalles = "-1";
if (isset($_GET['solicitud'])) {
  $colname_detalles = $_GET['solicitud'];
}
mysql_select_db($database_conex, $conex);
$query_detalles = sprintf("SELECT solpro.Sp_Serial, solpro.Sp_Solicitud, solpro.sp_Productos, solpro.Sp_Cantidad, productos.Pro_Nombre, productos.Pro_Empaque, productos.Pro_Peso, productos.Pro_Unidad, solicitud.Sol_Odc FROM solpro, productos, solicitud WHERE Sp_Solicitud = %s AND productos.Pro_Codigo=solpro.sp_Productos AND solpro.Sp_Solicitud = solicitud.Sol_Serial ORDER BY  productos.Pro_Nombre", GetSQLValueString($colname_detalles, "text"));
$detalles = mysql_query($query_detalles, $conex) or die(mysql_error());
$row_detalles = mysql_fetch_assoc($detalles);
$totalRows_detalles = mysql_num_rows($detalles);

$colname_duplicado = "-1";
if (isset($_GET['solicitud'])) {
  $colname_duplicado = $_GET['solicitud'];
}
mysql_select_db($database_conex, $conex);
$query_duplicado = sprintf("SELECT sp_Productos FROM solpro WHERE Sp_Solicitud = %s AND sp_Productos='".$_POST['sp_Productos']."'", GetSQLValueString($colname_duplicado, "text"));
$duplicado = mysql_query($query_duplicado, $conex) or die(mysql_error());
$row_duplicado = mysql_fetch_assoc($duplicado);
$totalRows_duplicado = mysql_num_rows($duplicado);
$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

// Validar campos vacios y requeridos
	$error = 0;
	$longitud = 0;
	if (array_key_exists ('enviar', $_POST) && $_POST['sp_Productos']<>"" && $_POST['Sp_Cantidad']<>"" ){
// Validar que no hayan campos duplicados
	$existe = 0;
	if ($totalRows_duplicado == 0){
// Validar que el codigo del producto tenga 8 caracteres
	
	if (strlen($_POST['sp_Productos']) == 8){	
if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO solpro (Sp_Serial, Sp_Solicitud, sp_Productos, Sp_Cantidad) VALUES (%s, %s, %s, %s)",
                       GetSQLValueString($_POST['Sp_Serial'], "int"),
                       GetSQLValueString(strtoupper($_POST['Sp_Solicitud']), "text"),
                       GetSQLValueString(strtoupper($_POST['sp_Productos']), "text"),
                       GetSQLValueString($_POST['Sp_Cantidad'], "int"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
  
  header ('Location: add_solicitudDetalle.php?solicitud='.$_POST['Sp_Solicitud']);
				exit;
	}
	}else {if (array_key_exists ('enviar', $_POST)){$longitud=1;}}
	}else {if (array_key_exists ('enviar', $_POST)){$existe=1;}}
	}else {if (array_key_exists ('enviar', $_POST)){$error=1;}}
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Detalle de solicitud</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="../js/ajax.js"></script>
</head>

<body>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="40" align="center" valign="bottom"><h3>Detalles de Solicitud de Productos Qu&iacute;micos</h3></td>
    </tr>
  </table>
  <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
    <table width="95%" border="0" align="center" cellpadding="5" cellspacing="2">
      <tr valign="baseline">
        <td colspan="4" align="left" nowrap><?php if ($_POST && $error ==1) { echo $incompleto."<BR>";}?>
        <?php 
			$duplicado = "<span class='obligatorio'>No se completo el proceso de registro porque ya existe uno identico. Por favor, vuelva a intentar introduciendo datos diferentes donde se refleja el icono: <span class='icon-obligaAzul'>&nbsp;&nbsp;&nbsp;&nbsp;</span></span>";
			if ($_POST && $totalRows_duplicado > 0) { echo $duplicado;}?>
			<?php if ($_POST && $longitud == 1) {echo "<span class='obligatorio'>No se completo el proceso de registro porque el codigo ingresado no tiene ocho (8) caracteres. Por favor, vuelva a intentar introduciendo datos diferentes donde se refleja el icono: <span class='icon-obligaAzul'>&nbsp;&nbsp;&nbsp;&nbsp;</span></span>";}?>
</td>
      </tr>
      <tr valign="baseline">
        <td colspan="4" align="left" nowrap class="Tcabeza"><h2>Agregar nuevo &iacute;tem</h2></td>
      </tr>
      <tr valign="baseline">
        <td width="25%" align="right" nowrap><label>Producto:
          <?php if ($_POST && $_POST['sp_Productos'] == "") { echo $icono;}?>
          <?php if ($_POST && $totalRows_duplicado > 0) { echo $iconoAzul;}?>
          <?php if ($_POST && $longitud == 1) { echo $iconoAzul;}?>
        </label>
          <span class="comentario clearIt">Introducir  c&oacute;digo de producto</span>
        <input name="sp_Productos" id="sp_Productos" type="text" class="textInput mayusculas" value="<?php if (isset($_POST['sp_Productos'])) {echo htmlentities($_POST['sp_Productos']);} ?>" size="32" onBlur="Buscar();" onKeyPress="Buscar();"></td>
        <td width="25%" rowspan="2" valign="bottom">&nbsp;</td>
        <td width="50%" rowspan="2" valign="bottom"><div id="resultado">&nbsp;</div></td>
      </tr>
      <tr valign="baseline">
        <td width="25%" align="right" nowrap><label>Cantidad:
          <?php if ($_POST && $_POST['Sp_Cantidad'] == "") { echo $icono;}?>
          </label>
          <span class="comentario clearIt">Cantidad solicitada</span>
          <input name="Sp_Cantidad" type="text" class="textInput" value="<?php if (isset($_POST['Sp_Cantidad'])) {echo htmlentities($_POST['Sp_Cantidad']);} ?>" size="32"></td>
      </tr>
      <tr valign="baseline">
        <td colspan="4" align="right" nowrap class="Tcabeza">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td colspan="4" align="right" nowrap>
			<input name="enviar" type="submit" class="button der" id="enviar" value="Registrar">
			<input name="Restablecer" type="reset" class="button der" value="Restablecer">
         <input type="button" class="button der" onClick="history.back()" value="Volver" >
			<input type="button" class="button der" onClick="location.href='cuerpo.php'" value="Cancelar" />
         </td>
      </tr>
    </table>
    <input type="hidden" name="Sp_Serial" value="">
    <input name="Sp_Solicitud" type="hidden" value="<?php echo $_GET['solicitud'];?>">
    <input type="hidden" name="MM_insert" value="form1">
  </form>
  <?php if ($totalRows_detalles > 0) { // Show if recordset not empty ?>
  <table width="95%" border="0" align="center" cellpadding="5" cellspacing="1">
    <tr>
      <td colspan="11">Imprimir</td>
      </tr>
    <tr>
      <td colspan="11" bgcolor="#0099FF"><h2 style="color:#fff; font-weight:normal;">Productos incluidos en la solicitud <span style="color: #FF0; font-size:16px;"> <?php echo $row_detalles['Sp_Solicitud']; ?> </span>asociada a la orden de compra <span style="color:#FF0;font-size:16px;"><?php echo $row_detalles['Sol_Odc']; ?></span></h2></td>
      </tr>
    <tr class="Tcabeza">
      <td width="5%"><p style="text-align:center">L&iacute;nea</p></td>
      <td width="10%"><p>C&oacute;digo</p></td>
      <td width="60%"><p>Descripci&oacute;n</p></td>
      <td width="15%"><p style="text-align:center;">Cantidad solicitada</p></td>
      <td width="5%">&nbsp;</td>
      <td width="5%"><p style="text-align:center;">Eliminar</p></td>
      </tr>
    <?php do { $numero++;?>
    <tr>
      <td width="5%" align="center" valign="middle" class="lineaInfPunta"><?php echo $numero; ?></td>
      <td class="lineaInfPunta"><p><?php echo $row_detalles['sp_Productos']; ?></p></td>
      <td class="lineaInfPunta"><p><?php echo $row_detalles['Pro_Nombre']; ?>, <?php echo $row_detalles['Pro_Empaque']; ?> de <?php echo $row_detalles['Pro_Peso']; ?> <?php echo $row_detalles['Pro_Unidad']; ?></p></td>
      <th align="center" class="lineaInfPunta"><p style="text-align:center; font-size:18px;"><?php echo $row_detalles['Sp_Cantidad']; ?> <span style="font-size:14px;"><?php echo $row_detalles['Pro_Empaque']; ?><?php if ($row_detalles['Sp_Cantidad']>1){echo 's';} ?></span></p>
        </th>
      <td class="lineaInfPunta">&nbsp;</td>
      <td width="5%" align="center" valign="middle" class="lineaInfPunta"><a href="del_solicitudProductoDetalle.php?serial=<?php echo $row_detalles['Sp_Serial']; ?>&solicitud=<?php echo $row_detalles['Sp_Solicitud']; ?>"><span class="icon-del">&nbsp;</span></a></td>
      </tr>
    <?php } while ($row_detalles = mysql_fetch_assoc($detalles)); ?>
  </table>
  
<table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td bgcolor="#333333">&nbsp;</td>
    </tr>
  </table>
<br>
<?php } // Show if recordset not empty ?>
</body>
</html>
<?php
mysql_free_result($detalles);
?>
