<?php require_once('../Connections/conex.php'); ?>
<?php include('mensajes.php'); ?>
<?php $url =$_GET['url']; ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1") && $_POST["Veh_Placa"] <> "" && $_POST["Veh_Marca"] <> "" && $_POST["Veh_Tipo"] <> "" && $_POST["Veh_Soporte"] <> "" && $_POST["Veh_Peso"] <> "") {
  $insertSQL = sprintf("INSERT INTO vehiculos (Veh_Placa, Veh_Marca, Veh_Tipo, Veh_Soporte, Veh_Peso) VALUES (%s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['Veh_Placa'], "text"),
                       GetSQLValueString($_POST['Veh_Marca'], "text"),
                       GetSQLValueString($_POST['Veh_Tipo'], "text"),
                       GetSQLValueString($_POST['Veh_Soporte'], "int"),
                       GetSQLValueString($_POST['Veh_Peso'], "int"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
  
  //Borrar el array de datos, Enviar mensaje de registro exitoso y redireccion a la lista de registros
				 $_POST = array();
				 echo "<script language='JavaScript'> alert('*** El proceso de registro se realizo con exito');</script>";
 				 if ($url == ""){ echo "<script language='Javascript'>location.href='list_proveedores.php';</script>";}
 				 if ($url == "add_recepcion"){ echo "<script language='Javascript'>location.href='add_recepcion.php';</script>";}
  
}else {$error = 1;}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Registrar Vehiculos</title>
<link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="40" align="center" valign="bottom"><h3>Registro de Vehículos</h3></td>
  </tr>
</table>
<form method="post" name="form1" action="<?php echo $editFormAction; ?>">
  <table width="95%" border="0" align="center" cellpadding="5" cellspacing="2">
    <tr valign="baseline">
      <td colspan="4" align="right" nowrap>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">&nbsp;</td>
      <td colspan="2" nowrap><?php if ($_POST && $error == 1) { echo $incompleto."<BR>";}?></td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td colspan="4" align="left" nowrap class="Tcabeza"><h2>Descripci&oacute;n del veh&iacute;culo</h2></td>
    </tr>
    <tr valign="baseline">
      <td width="25%" align="right" nowrap>&nbsp;</td>
      <td width="25%" align="right" nowrap><label>Placa:
          <?php if ($_POST && $_POST['Veh_Placa'] == "") { echo $icono;}?>
      </label>
      <input name="Veh_Placa" type="text" class="textInput" value="<?php if (isset($_POST['Veh_Placa'])) {echo htmlentities($_POST['Veh_Placa']);} ?>" size="32"></td>
      <td width="25%">&nbsp;</td>
      <td width="25%">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">&nbsp;</td>
      <td nowrap align="right"><label>Marca:
        <?php if ($_POST && $_POST['Veh_Marca'] == "") { echo $icono;}?>
      </label>
      <input name="Veh_Marca" type="text" class="textInput" value="<?php if (isset($_POST['Veh_Marca'])) {echo htmlentities($_POST['Veh_Marca']);} ?>" size="32"></td>
      <td><label>Tipo:
        <?php if ($_POST && $_POST['Veh_Tipo'] == "") { echo $icono;}?>
      </label>
      <input name="Veh_Tipo" type="text" class="textInput" value="<?php if (isset($_POST['Veh_Tipo'])) {echo htmlentities($_POST['Veh_Tipo']);} ?>" size="32"></td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">&nbsp;</td>
      <td nowrap align="right"><label>Soporte:
        <?php if ($_POST && $_POST['Veh_Soporte'] == "") { echo $icono;}?>
      </label>
      <input name="Veh_Soporte" type="text" class="textInput" value="<?php if (isset($_POST['Veh_Soporte'])) {echo htmlentities($_POST['Veh_Soporte']);} ?>" size="32"></td>
      <td><label>Peso que soporta:
        <?php if ($_POST && $_POST['Veh_Peso'] == "") { echo $icono;}?>
      </label>
      <input name="Veh_Peso" type="text" class="textInput" value="<?php if (isset($_POST['Veh_Peso'])) {echo htmlentities($_POST['Veh_Peso']);} ?>" size="32"></td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td colspan="4" align="right" nowrap class="Tcabeza">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td colspan="4" align="right" nowrap><input name="enviar" type="submit" class="button der" id="enviar" value="Registrar">
        <input name="Restablecer" type="reset" class="button der" value="Restablecer">
        <input type="button" class="button der" onClick="history.back()" value="Volver" >
        <input type="button" class="button der" onClick="location.href='cuerpo.php'" value="Cancelar" /></td>
    </tr>
  </table>
  <input type="hidden" name="MM_insert" value="form1">
</form>
<p>&nbsp;</p>
</body>
</html>