<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Cabecera</title>
<style type="text/css">
body {
	background-color: #003366;
}
</style>
<link href="../css/sga.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>
<!--    <span class="titulo">SGA</span></p>
    <span class="subtitulo">Sistema para la Gesti&oacute;n de Almacenes</span>
    <span class="subtitulo2"">Schlumberger de Venezuela, S.A.</span>
    
 -->
     <img src="../img/sga.png" width="313" height="60" alt="sga" style=" padding-top:15px; padding-left:5px;"></td>
    <td colspan="2" align="right"><img src="../img/logo_slb_header_blanco.gif" width="178" height="67" alt="slb"></td>
  </tr>
  <tr>
    <td width="30%" bgcolor="#CCCCCC">&nbsp;</td>
    <td width="40%" bgcolor="#CCCCCC">&nbsp;</td>
    <td width="30%" bgcolor="#CCCCCC">&nbsp;</td>
  </tr>
</table>
</body>
</html>
