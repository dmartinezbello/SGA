<?php require_once('../Connections/conex.php'); ?>
<?php
function Extraer($q) {
	$query = mysql_query("SELECT Pro_Nombre, Pro_Rif, Con_Cedula, Con_Nombre, Con_Apellido FROM conductor, proveedor WHERE Con_Cedula LIKE '%$q%' AND proveedor.Pro_Codigo = conductor.Pro_Codigo ORDER BY Con_Nombre");
		if (mysql_num_rows($query) == 0){
			print '<p class="colorTextRojo"><strong>No hay resultados para el c&oacute;digo ingresado</strong></p>';
			print '<p><a href="add_conductor.php">Registrar un nuevo conductor</a></p>';
			}
			else {print '<p class="colorTextRojo"><strong>Descripci&oacute;n del &iacute;tem seg&uacute;n n&uacute;mero de identificaci&oacute;n ingresado:</strong></p>';
				while ($row =mysql_fetch_assoc($query)){
					
					print '<p style="color:#000000">N&Uacute;MERO DE IDENTIFICACI&Oacute;N: '.$row['Con_Cedula'].'</p>';
					print '<p style="color:#000099">Conductor: '.$row['Con_Nombre'].' '.$row['Con_Apellido'].'</p>';
					print '<p style="color:#666666">Proveedor de transporte: '.$row['Pro_Nombre'].'</p>';
					print '<p style="color:#666666">RIF: '.$row['Pro_Rif'].'</p>';
					print '<br>';
					}
				}
	
	}
?>
