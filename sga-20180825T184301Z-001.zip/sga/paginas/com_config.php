<?php require_once('../Connections/conex.php'); ?>
<?php
function Extraer($q) {
	$query = mysql_query("SELECT * FROM productos WHERE Pro_Codigo LIKE '%$q%' ORDER BY Pro_Nombre");
		if (mysql_num_rows($query) == 0){
			print '<p class="colorTextRojo"><strong>No hay resultados para el c&oacute;digo ingresado</strong></p>';
			print '<p><a href="add_producto.php">Registrar un nuevo producto</a></p>';
			}
			else {print '<p class="colorTextRojo"><strong>Descripcion del &iacute;tem seg&uacute;n el codigo ingresado:</strong></p>';
				while ($row =mysql_fetch_assoc($query)){
					
					print '<p style="color:#000000">C&Oacute;DIGO:'.$row['Pro_Codigo'].'</p>';
					print '<p style="color:#000099">NOMBRE: '.$row['Pro_Nombre'].'</p>';
					print '<p style="color:#666666">Empaque: '.$row['Pro_Empaque'].'</p>';
					print '<p style="color:#666666">Peso: '.$row['Pro_Peso'].'</p>';
					print '<p style="color:#666666">Unidad de medida: '.$row['Pro_Unidad'].'</p>';
					print '<br>';
					}
				}
	
	}
?>
