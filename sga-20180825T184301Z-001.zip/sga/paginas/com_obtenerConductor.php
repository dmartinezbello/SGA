<?php 
include('com_conductor.php');
$q = $_GET['q'];
Extraer($q);
?>