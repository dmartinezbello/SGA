<?php 
include('com_config.php');
$q = $_GET['q'];
Extraer($q);
?>