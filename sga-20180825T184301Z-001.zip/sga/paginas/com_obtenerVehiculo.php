<?php 
include('com_vehiculo.php');
$q = $_GET['q'];
Extraer($q);
?>