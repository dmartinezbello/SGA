<?php 
include('con_ingeniero.php');
$q = $_GET['q'];
Extraer($q);
?>