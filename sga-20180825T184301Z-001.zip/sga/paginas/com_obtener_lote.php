<?php 
include('con_lote.php');
$q = $_GET['q'];
Extraer($q);
?>