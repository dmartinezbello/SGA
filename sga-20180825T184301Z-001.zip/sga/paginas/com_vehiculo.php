<?php require_once('../Connections/conex.php'); ?>
<?php
function Extraer($q) {
	$query = mysql_query("SELECT * FROM  vehiculos WHERE  Veh_Placa LIKE'$q' ORDER BY  Veh_Tipo ASC");
		if (mysql_num_rows($query) == 0){
			print '<p class="colorTextRojo"><strong>No hay resultados para el c&oacute;digo ingresado</strong></p>';
			print '<p><a href="add_vehiculo.php">Registrar un nuevo vehiculo</a></p>';
			}
			else {print '<p class="colorTextRojo"><strong>Descripci&oacute;n del &iacute;tem seg&uacute;n n&uacute;mero de identificaci&oacute;n ingresado:</strong></p>';
				while ($row =mysql_fetch_assoc($query)){
					print '<p style="color:#000000">PLACAS: '.$row['Veh_Placa'].'</p>';
					print '<p style="color:#666666">Marca: '.$row['Veh_Marca'].'</p>';
					print '<p style="color:#666666">Tipo de Vehiculo: '.$row['Veh_Tipo'].'</p>';
					print '<p style="color:#666666">Estibas que soporta: '.$row['Veh_Soporte'].'</p>';
					print '<p style="color:#666666">Peso que soporta: '.$row['Veh_Peso'].'</p>';
					print '<br>';
					}
				}
	
	}
?>
