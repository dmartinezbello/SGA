<?php require_once('../Connections/conex.php'); ?>
<?php
mysql_select_db($database_conex, $conex);
function Extraer($q) {
	$query = mysql_query("SELECT * FROM  `usuario` WHERE  Usuario LIKE '$q' ORDER BY Nombres") or die ($Sql .mysql_error()."" );
		if (mysql_num_rows($query) == 0) {
			print '<p class="colorTextRojo"><strong>No hay resultados para el nombre de usuario ingresado</strong></p>';
			print '<input name="obligatorio" type="hidden" value="0">';
			//print '<p><a href="add_producto.php">Registrar un nuevo producto</a></p>';
			}
			else {print '<p class="colorTextRojo"><strong>Descripci&oacute;n del &iacute;tem seg&uacute;n el  nombre de usuario ingresado:</strong></p>';
				while ($row =mysql_fetch_assoc($query)){
					
					print '<table width="90%" border="0" cellspacing="0" cellpadding="0">';
					print '<tr>';
					print '<td>';
					print '<p style="color:#000000"><strong>Nombre:</strong>  '.$row['Nombres'].' '.$row['Apellidos'].'</p>';
					print '<p style="color:#666666">E-mail: '.$row['Usuario'].'@slb.com</p>';
					print '<p style="color:#666666">N&uacute;mero de empleado (GIN): '.$row['Gin'].'</p>';
					print '<p style="color:#666666">Tel&eacute;fono: '.$row['Telefono'].'</p>';
					print '</td>';
					print '<td><img src="'.$row['Imagen'].'" width="92" height="92"></td>';
					print '  </tr>';
					print '</table>';
					print '<input name="obligatorio" type="hidden" value="1">';
					}
				}
	}
?>