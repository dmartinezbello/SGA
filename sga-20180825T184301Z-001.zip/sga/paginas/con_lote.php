


<?php
function Extraer($q) {
 require_once('../Connections/conex.php'); 

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}	
mysql_select_db($database_conex, $conex);
$query_prueba = "SELECT Rec_Lote, Rec_Prueba FROM recepcion WHERE  Rec_Lote =  '$q'";
$prueba = mysql_query($query_prueba, $conex) or die(mysql_error());
$row_prueba = mysql_fetch_assoc($prueba);
$totalRows_prueba = mysql_num_rows($prueba);	

	if ($totalRows_prueba > 0) { 
	$new_prueba = $row_prueba['Rec_Prueba'];
	echo '<input name="Rec_Prueba" type="text" class="textInput textCenter" readonly="readonly" style="font-size:18px;" value="'.$new_prueba.'" size="32">';
	print '<p style="color:#009900; font-weight: bold;">El lote ingresado ya tiene una prueba asignada</p>';
	}
	
	if ($totalRows_prueba == 0) {
		$query_lote_prueba = "SELECT DISTINCT Rec_Prueba FROM recepcion ORDER BY  Rec_Prueba ASC ";
		$lote_prueba = mysql_query($query_lote_prueba, $conex) or die(mysql_error());
		$row_lote_prueba = mysql_fetch_assoc($lote_prueba);
		$totalRows_lote_prueba = mysql_num_rows($lote_prueba);	
		
		$new_prueba = $totalRows_lote_prueba + 1;
		echo '<input name="Rec_Prueba" type="text" class="textInput textCenter" style="font-size:18px;" readonly="readonly" value="'.$new_prueba.'" size="32">';
		print '<p style="color:#FF0000; font-weight: bold;">Nueva prueba asignada</p>';
		}

mysql_free_result($prueba);}
?>

