<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Cuerpo</title>
</head>

<body>
 <p>
   <a href="add_producto.php">Registrar producto </a>
 </p>
 <p><a href="add_almacen.php">Registrar Almacen</a></p>
 <p><a href="add_proveedor.php">Registrar Proveedor</a></p>
 <p><a href="add_conductor.php">Registrar Conductor</a></p>
 <p><a href="add_solicitud.php">Registrar Solicitud de Productos</a></p>
 <p>
   <a href="list_productos.php">Listar productos</a>
 </p>
 <p><a href="list_almacenes.php">Listar Almacenes</a></p>
 <p><a href="list_proveedores.php">Listar proveedores</a></p>
 <p><a href="list_conductores.php">Listar conductores</a></p>
 <p>&nbsp;</p>
</body>
</html>