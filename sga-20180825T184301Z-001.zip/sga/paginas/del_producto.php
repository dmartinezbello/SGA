<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

if ((isset($_POST['codigo'])) && ($_POST['codigo'] != "")) {
  $deleteSQL = sprintf("DELETE FROM productos WHERE Pro_Codigo=%s",
                       GetSQLValueString($_POST['codigo'], "text"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($deleteSQL, $conex) or die(mysql_error());

  //Borrar el array de datos, Enviar mensaje de registro exitoso y redireccion a la lista de registros
			 $_POST = array();
 			 echo "<script language='JavaScript'> alert('*** Se ha eliminado el registro con exito');</script>";
			 echo "<script language='Javascript'>location.href='list_productos.php';</script>";
}

$colname_obtenerProducto = "-1";
if (isset($_GET['codigo'])) {
  $colname_obtenerProducto = $_GET['codigo'];
}
mysql_select_db($database_conex, $conex);
$query_obtenerProducto = sprintf("SELECT Pro_Codigo, Pro_Nombre, Pro_Empaque, Pro_Peso, Pro_Unidad FROM productos WHERE Pro_Codigo = %s", GetSQLValueString($colname_obtenerProducto, "text"));
$obtenerProducto = mysql_query($query_obtenerProducto, $conex) or die(mysql_error());
$row_obtenerProducto = mysql_fetch_assoc($obtenerProducto);
$totalRows_obtenerProducto = mysql_num_rows($obtenerProducto);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css" />
</head>

<body>
<form id="form1" name="form1" method="post" action="">
<table width="40%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="140" align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
  </tr>
  <tr>
    <td valign="bottom" class="bordeInferiorSolido"><h2>Eliminar Producto
      
    </h2></td>
    <td class="bordeInferiorSolido"><img src="../Img/advertencia.png" alt="Advertencia" width="48" height="48" class="der" /></td>
  </tr>
  <tr>
    <td colspan="2" valign="bottom" class="Tcabeza">&nbsp;</td>
    </tr>
  <tr>
    <td class="bordeInferiorSolido">
        <p>&nbsp;</p>
        <p class="obligatorio">Esta apunto de eliminar el registro de forma definitiva.</p>
        <p class="obligatorio"> ¿Está seguro que desea continuar?</p>
        <p>&nbsp;</p>
        <p><strong>Código:</strong> <?php echo $row_obtenerProducto['Pro_Codigo']; ?></p>
        <p><strong>Descripción: </strong><?php echo $row_obtenerProducto['Pro_Nombre']; ?>, <?php echo $row_obtenerProducto['Pro_Empaque']; ?> de <?php echo $row_obtenerProducto['Pro_Peso']; ?> <?php echo $row_obtenerProducto['Pro_Unidad']; ?></p>
        <p>
          <input name="codigo" type="hidden" id="codigo" value="<?php echo $row_obtenerProducto['Pro_Codigo']; ?>" />
      </p>
      <p>&nbsp;</p></td>
    <td class="bordeInferiorSolido">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" class="Tcabeza">&nbsp;</td>
    </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
</table>
<table width="40%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><input name="atras" type="button" class="button" id="atras" value="Cancelar" onclick="javascript:history.back()" /></td>
    <td><input name="eliminar" type="submit" class="button der" id="eliminar" value="Aceptar" /></td>
  </tr>
</table>
</form>
</body>
</html>
<?php
mysql_free_result($obtenerProducto);
?>
