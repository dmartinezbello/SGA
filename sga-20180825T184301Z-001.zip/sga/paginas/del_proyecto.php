<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

if ((isset($_POST['codigo'])) && ($_POST['codigo'] != "")) {
  $deleteSQL = sprintf("DELETE FROM proyecto WHERE Pro_Logit=%s",
                       GetSQLValueString($_POST['codigo'], "text"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($deleteSQL, $conex) or die(mysql_error());
  //Borrar el array de datos, Enviar mensaje de registro exitoso y redireccion a la lista de registros
		$_POST = array();
 		echo "<script language='JavaScript'> alert('*** Se ha eliminado el registro con exito');</script>";
		echo "<script language='Javascript'>location.href='list_proyectos.php';</script>";
}

$colname_proyecto = "-1";
if (isset($_GET['codigo'])) {
  $colname_proyecto = $_GET['codigo'];
}
mysql_select_db($database_conex, $conex);
$query_proyecto = sprintf("SELECT Pro_Logit, Pro_Pozo, Pro_Taladro, Pro_Cliente, Pro_Direccion, Pro_Estatus FROM proyecto WHERE Pro_Logit = %s", GetSQLValueString($colname_proyecto, "text"));
$proyecto = mysql_query($query_proyecto, $conex) or die(mysql_error());
$row_proyecto = mysql_fetch_assoc($proyecto);
$totalRows_proyecto = mysql_num_rows($proyecto);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Eliminar proyecto</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
  <form id="form1" name="form1" method="post" action="">
    <table width="40%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td height="140" align="right">&nbsp;</td>
        <td align="right">&nbsp;</td>
      </tr>
      <tr>
        <td valign="bottom" class="bordeInferiorSolido"><h2>Eliminar Proyecto </h2></td>
        <td class="bordeInferiorSolido"><img src="../Img/advertencia.png" alt="Advertencia" width="48" height="48" class="der" /></td>
      </tr>
      <tr>
        <td colspan="2" valign="bottom" class="Tcabeza">&nbsp;</td>
      </tr>
      <tr>
        <td class="bordeInferiorSolido"><p>&nbsp;</p>
          <p class="obligatorio">Esta a un paso de eliminar el registro de forma definitiva.</p>
          <p class="obligatorio"> &iquest;Est&aacute; seguro que desea continuar?</p>
          <p>&nbsp;</p>
          <p><strong>Lot-It:</strong> <?php echo $row_proyecto['Pro_Logit']; ?></p>
          <p><strong>Taladro:</strong> <?php echo $row_proyecto['Pro_Taladro']; ?></p>
          <p><strong>Pozo: </strong><?php echo $row_proyecto['Pro_Pozo']; ?></p>
          <p>Cliente: <?php echo $row_proyecto['Pro_Cliente']; ?></p>
          <p>Estatus: <?php if ($row_proyecto['Pro_Estatus'] == '') {echo 'Activo'; } else {echo 'Terminado';}?></p>
          <p>Direcci&oacute;n: <?php echo $row_proyecto['Pro_Direccion']; ?></p>
          <p>
            <input name="codigo" type="hidden" id="codigo" value="<?php echo $row_proyecto['Pro_Logit']; ?>" />
          </p>
          <p>&nbsp;</p></td>
        <td class="bordeInferiorSolido">&nbsp;</td>
      </tr>
      <tr>
        <td colspan="2" class="Tcabeza">&nbsp;</td>
      </tr>
      <tr>
        <td colspan="2">&nbsp;</td>
      </tr>
    </table>
    <table width="40%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><input name="atras" type="button" class="button" id="atras" value="Cancelar" onClick="javascript:history.back()" /></td>
        <td><input name="eliminar" type="submit" class="button der" id="eliminar" value="Aceptar" /></td>
      </tr>
    </table>
  </form>
</body>
</html>
<?php
mysql_free_result($proyecto);
?>
