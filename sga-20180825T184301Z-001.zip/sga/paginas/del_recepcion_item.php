<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

if ((isset($_GET['linea'])) && ($_GET['linea'] != "")) {
  $deleteSQL = sprintf("DELETE FROM recepcion WHERE Rec_Serial=%s",
                       GetSQLValueString($_GET['linea'], "int"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($deleteSQL, $conex) or die(mysql_error());
  
  // Consulta para seleccionar el producto en el almacen donde se recibe
  mysql_select_db($database_conex, $conex);
	$query_inventario = "SELECT Alm_Codigo, Pro_Codigo, Inv_Stock FROM inventario WHERE Alm_Codigo = '".$_GET['almacen']."' AND Pro_Codigo = '".$_GET['producto']."'";
	$inventario = mysql_query($query_inventario, $conex) or die(mysql_error());
	$row_inventario = mysql_fetch_assoc($inventario);
	$totalRows_inventario = mysql_num_rows($inventario);
	$stock = $row_inventario['Inv_Stock'] - $_GET['cantidad'];
	
	//Actualizar la cantidad del producto en el almacen
	if ($totalRows_inventario > 0){
	 $updateSQL = "UPDATE inventario SET Inv_Stock = $stock WHERE Alm_Codigo = '".$_GET['almacen']."' AND Pro_Codigo = '".$_GET['producto']."'";
	 mysql_select_db($database_conex, $conex);
	 $update = mysql_query($updateSQL, $conex) or die(mysql_error());
	}


  $deleteGoTo = "add_recepcion_detalle.php?recepcion=" . $row_recepcion['Rec_Numero'] . "";
  if (isset($_SERVER['QUERY_STRING'])) {
    $deleteGoTo .= (strpos($deleteGoTo, '?')) ? "&" : "?";
    $deleteGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $deleteGoTo));
}

$colname_recepcion = "-1";
if (isset($_GET['linea'])) {
  $colname_recepcion = $_GET['linea'];
}
mysql_select_db($database_conex, $conex);
$query_recepcion = sprintf("SELECT Rec_Serial FROM recepcion WHERE Rec_Serial = %s", GetSQLValueString($colname_recepcion, "int"));
$recepcion = mysql_query($query_recepcion, $conex) or die(mysql_error());
$row_recepcion = mysql_fetch_assoc($recepcion);
$totalRows_recepcion = "-1";
if (isset($_GET['linea'])) {
  $totalRows_recepcion = $_GET['linea'];
}
mysql_select_db($database_conex, $conex);
$query_recepcion = sprintf("SELECT Rec_Serial, Rec_Numero FROM recepcion WHERE Rec_Serial = %s", GetSQLValueString($colname_recepcion, "int"));
$recepcion = mysql_query($query_recepcion, $conex) or die(mysql_error());
$row_recepcion = mysql_fetch_assoc($recepcion);
$totalRows_recepcion = mysql_num_rows($recepcion);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Untitled Document</title>
</head>

<body>
</body>
</html>
<?php
mysql_free_result($recepcion);
?>
