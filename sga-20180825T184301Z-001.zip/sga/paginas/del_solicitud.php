<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

if ((isset($_POST['solicitud'])) && ($_POST['solicitud'] != "")) {
  $deleteSQL = sprintf("DELETE FROM solicitud WHERE Sol_Serial=%s",
                       GetSQLValueString($_POST['solicitud'], "text"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($deleteSQL, $conex) or die(mysql_error());

  		//Borrar el array de datos, Enviar mensaje de registro exitoso y redireccion a la lista de registros
		$_POST = array();
 		echo "<script language='JavaScript'> alert('*** Se ha eliminado el registro con exito');</script>";
		echo "<script language='Javascript'>location.href='add_solicitud.php';</script>";
}

$colname_obtenerSolicitud = "-1";
if (isset($_GET['solicitud'])) {
  $colname_obtenerSolicitud = $_GET['solicitud'];
}
mysql_select_db($database_conex, $conex);
$query_obtenerSolicitud = sprintf("SELECT * FROM solicitud WHERE Sol_Serial = %s", GetSQLValueString($colname_obtenerSolicitud, "text"));
$obtenerSolicitud = mysql_query($query_obtenerSolicitud, $conex) or die(mysql_error());
$row_obtenerSolicitud = mysql_fetch_assoc($obtenerSolicitud);
$totalRows_obtenerSolicitud = mysql_num_rows($obtenerSolicitud);

$colname_obtenerDetalles = "-1";
if (isset($_GET['solicitud'])) {
  $colname_obtenerDetalles = $_GET['solicitud'];
}
mysql_select_db($database_conex, $conex);
$query_obtenerDetalles = sprintf("SELECT solpro.Sp_Serial, solpro.Sp_Solicitud, solpro.sp_Productos, solpro.Sp_Cantidad, productos.Pro_Codigo, productos.Pro_Nombre, productos.Pro_Empaque, productos.Pro_Peso, productos.Pro_Unidad, solicitud.Sol_Odc FROM solpro, productos, solicitud WHERE Sp_Solicitud = %s AND productos.Pro_Codigo=solpro.sp_Productos AND solpro.Sp_Solicitud = solicitud.Sol_Serial", GetSQLValueString($colname_obtenerDetalles, "text"));
$obtenerDetalles = mysql_query($query_obtenerDetalles, $conex) or die(mysql_error());
$row_obtenerDetalles = mysql_fetch_assoc($obtenerDetalles);
$totalRows_obtenerDetalles = mysql_num_rows($obtenerDetalles);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css" />
</head>

<body>
<form id="form1" name="form1" method="post" action="">
<table width="50%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="140" align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
  </tr>
  <tr>
    <td valign="bottom" class="bordeInferiorSolido"><h2>Eliminar solicitud de productos</h2></td>
    <td class="bordeInferiorSolido"><img src="../Img/advertencia.png" alt="Advertencia" width="48" height="48" class="der" /></td>
  </tr>
  <tr>
    <td colspan="2" class="Tcabeza">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" class="bordeInferiorSolido">
        <p class="obligatorio">Esta apunto de eliminar el registro de forma definitiva.</p>
        <p class="obligatorio"> ¿Está seguro que desea continuar?</p>
        <p class="obligatorio">&nbsp;</p>
        <table width="100%" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="20%" bgcolor="#FFFF00"><p><strong>Referencia de la solicitud:</strong></p></td>
            <td width="20%" valign="top" bgcolor="#FFFF00"><p><?php echo strtoupper($row_obtenerSolicitud['Sol_Serial']); ?></p></td>
            <td width="60%" valign="top" bgcolor="#FFFF00">&nbsp;</td>
          </tr>
          <tr>
            <td width="20%" bgcolor="#FFFF00"><p><strong>Orden de Compra:</strong></p></td>
            <td width="20%" bgcolor="#FFFF00"><p><?php echo $row_obtenerSolicitud['Sol_Odc']; ?></p></td>
            <td width="60%" bgcolor="#FFFF00">&nbsp;</td>
          </tr>
        </table>
        <?php if ($totalRows_obtenerDetalles > 0) { // Show if recordset not empty ?>
    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr class="Tcabeza">
        <td width="5%" height="30" align="left" bgcolor="#0099FF" class="tablaEncabezado"><p class="colorTextBlanco">L&iacute;inea</p></td>
        <td width="35%" align="left" bgcolor="#0099FF" class="tablaEncabezado"><p class="colorTextBlanco">Descripci&oacute;n</p></td>
        <td width="10%" bgcolor="#0099FF" class="tablaEncabezado"><p class="colorTextBlanco">Cantidad</p></td>
        </tr>
      <?php do { $numero++; ?>
        <tr>
          <td height="25" align="center" valign="middle" class="lineaInfPunta">
            <p style="text-align:center;"><?php echo $numero; ?></p></td>
          <td height="25" class="lineaInfPunta"><p><?php echo $row_obtenerDetalles['Pro_Codigo']; ?> - <?php echo $row_obtenerDetalles['Pro_Nombre']; ?>, <?php echo $row_obtenerDetalles['Pro_Empaque']; ?> de <?php echo $row_obtenerDetalles['Pro_Peso']; ?> <?php echo $row_obtenerDetalles['Pro_Unidad']; ?></p></td>
          <th class="lineaInfPunta"><p><?php echo $row_obtenerDetalles['Sp_Cantidad']; ?> <?php echo $row_obtenerDetalles['Pro_Empaque']; ?><span style="font-size:14px;"><?php if ($row_obtenerDetalles['Sp_Cantidad']>1){echo 's';} ?>
          </span></p></th>
          </tr>
        <?php } while ($row_obtenerDetalles = mysql_fetch_assoc($obtenerDetalles)); ?>
  </table>
  <?php } // Show if recordset not empty ?></td>
    </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" bgcolor="#333333">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2"><span class="bordeInferiorSolido">
      <input name="solicitud" type="hidden" id="solicitud" value="<?php echo $row_obtenerSolicitud['Sol_Serial']; ?>" />
    </span></td>
  </tr>
  <tr>
    <td colspan="2">
      <input name="enviar" type="submit" class="button der" id="enviar" value="Eliminar" />
      <input type="button" class="button der" onclick="history.back()" value="Volver" />
      <input type="button" class="button der" onclick="location.href='sga.php'" value="Cancelar" />
      </td>
  </tr>
</table>
<p>&nbsp;</p>
</form>
</body>
</html>
<?php
mysql_free_result($obtenerSolicitud);

mysql_free_result($obtenerDetalles);
?>
