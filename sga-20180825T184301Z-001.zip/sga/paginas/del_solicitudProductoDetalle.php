<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

if ((isset($_GET['serial'])) && ($_GET['serial'] != "")) {
  $deleteSQL = sprintf("DELETE FROM solpro WHERE Sp_Serial=%s",
                       GetSQLValueString($_GET['serial'], "int"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($deleteSQL, $conex) or die(mysql_error());

  $deleteGoTo = "add_solicitudDetalle.php?solicitud=" . $row_obtenerProducto['Sp_Solicitud'] . "";
  if (isset($_SERVER['QUERY_STRING'])) {
    $deleteGoTo .= (strpos($deleteGoTo, '?')) ? "&" : "?";
    $deleteGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $deleteGoTo));
}

$colname_obtenerProducto = "-1";
if (isset($_GET['serial'])) {
  $colname_obtenerProducto = $_GET['serial'];
}
mysql_select_db($database_SGA, $SGA);
$query_obtenerProducto = sprintf("SELECT * FROM solpro WHERE Sp_Serial = %s", GetSQLValueString($colname_obtenerProducto, "int"));
$obtenerProducto = mysql_query($query_obtenerProducto, $SGA) or die(mysql_error());
$row_obtenerProducto = mysql_fetch_assoc($obtenerProducto);
$totalRows_obtenerProducto = mysql_num_rows($obtenerProducto);
?>
<?php
mysql_free_result($obtenerProducto);
?>
