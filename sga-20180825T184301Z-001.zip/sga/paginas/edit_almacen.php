<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

	$error = 0;
	if (array_key_exists ('enviar', $_POST) && $_POST['Alm_Codigo']<>"" && $_POST['Alm_Nombre']<>"" && $_POST['Alm_Direccion']<>"") {
		if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
		  $updateSQL = sprintf("UPDATE almacen SET Alm_Nombre=%s, Alm_Direccion=%s WHERE Alm_Codigo=%s",
							   GetSQLValueString($_POST['Alm_Nombre'], "text"),
							   GetSQLValueString($_POST['Alm_Direccion'], "text"),
							   GetSQLValueString($_POST['Alm_Codigo'], "text"));
		
		  mysql_select_db($database_conex, $conex);
		  $Result1 = mysql_query($updateSQL, $conex) or die(mysql_error());
		  
		  //Borrar el array de datos, Enviar mensaje de edicion exitosa y redireccion a la lista de registros
	$_POST = array();
	echo "<script language='JavaScript'> alert('*** El proceso de edicion se realizo con exito');</script>";
	echo "<script language='Javascript'>location.href='list_almacenes.php';</script>";
		}
	}else {if (array_key_exists ('enviar', $_POST)){$error=1;}}

$colname_obtenerAlmacen = "-1";
if (isset($_GET['codigo'])) {
  $colname_obtenerAlmacen = $_GET['codigo'];
}
mysql_select_db($database_conex, $conex);
$query_obtenerAlmacen = sprintf("SELECT * FROM almacen WHERE Alm_Codigo = %s", GetSQLValueString($colname_obtenerAlmacen, "text"));
$obtenerAlmacen = mysql_query($query_obtenerAlmacen, $conex) or die(mysql_error());
$row_obtenerAlmacen = mysql_fetch_assoc($obtenerAlmacen);
$totalRows_obtenerAlmacen = mysql_num_rows($obtenerAlmacen);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>editar almacen</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="40" align="center" valign="bottom"><h3>Editar de Almac&eacute;n</h3></td>
  </tr>
</table>
<form method="post" name="form1" action="<?php echo $editFormAction; ?>">
  <table width="95%" border="0" align="center" cellpadding="5" cellspacing="2">
    <tr valign="baseline">
      <td colspan="2" align="left" nowrap><?php if ($_POST && $error ==1) { echo $incompleto."<BR>";}?>
        <?php if ($_POST && $totalRows_codigoDuplicado > 0) { echo $duplicado;}?></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" align="left" nowrap class="Tcabeza"><h2>Descripci&oacute;n del qu&iacute;mico</h2></td>
    </tr>
    <tr valign="baseline">
      <td width="20%" align="right" nowrap><label>Codig&oacute;:
        <?php if ($_POST && $_POST['Alm_Codigo'] == "") { echo $icono;}?>
        <?php if ($_POST && $totalRows_codigoDuplicado > 0) { echo $iconoAzul;}?>
      </label>
        <input name="Alm_Codigo2" type="text" disabled class="textInput" value="<?php echo $row_obtenerAlmacen['Alm_Codigo']; ?>" size="32"></td>
      <td width="80%"><label>Nombre:
        <?php if ($_POST && $_POST['Alm_Nombre'] == "") { echo $icono;}?>
      </label>
        <input name="Alm_Nombre" type="text" class="textInput" value="<?php echo $row_obtenerAlmacen['Alm_Nombre']; ?>" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" align="right" valign="top" nowrap><label>Direcci&oacute;n:
        <?php if ($_POST && $_POST['Alm_Direccion'] == "") { echo $icono;}?>
      </label>
        <textarea name="Alm_Direccion" cols="50" rows="3"><?php echo $row_obtenerAlmacen['Alm_Direccion']; ?></textarea></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" align="right" nowrap class="Tcabeza">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td width="20%" align="right" nowrap>&nbsp;</td>
      <td width="80%"><input name="enviar" type="submit" class="button der" id="enviar" value="Editar">
        <input name="Restablecer" type="reset" class="button der" value="Restablecer">
        <input type="button" class="button der" onClick="location.href='principal.php'" value="Cancelar" /></td>
    </tr>
  </table>
  <input type="hidden" name="MM_update" value="form1">
  <input type="hidden" name="Alm_Codigo" value="<?php echo $row_obtenerAlmacen['Alm_Codigo']; ?>">
</form>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($obtenerAlmacen);
?>
