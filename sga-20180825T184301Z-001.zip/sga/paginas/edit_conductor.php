<?php require_once('../Connections/conex.php'); ?>
<?php include('mensajes.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
// Validar campos vacios y requeridos
$error = 0;
if (array_key_exists ('enviar', $_POST) && $_POST['Con_Cedula']<>"" && $_POST['Con_Nombre']<>"" && $_POST['Con_Apellido']<>"") {
if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE conductor SET Con_Nombre=%s, Con_Apellido=%s, Pro_Codigo=%s WHERE Con_Cedula=%s",
                       GetSQLValueString($_POST['Con_Nombre'], "text"),
                       GetSQLValueString($_POST['Con_Apellido'], "text"),
                       GetSQLValueString($_POST['Pro_Codigo'], "int"),
                       GetSQLValueString($_POST['Con_Cedula'], "text"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($updateSQL, $conex) or die(mysql_error());
  
  //Borrar el array de datos, Enviar mensaje de registro exitoso y redireccion a la lista de registros
				 $_POST = array();
				 echo "<script language='JavaScript'> alert('*** El proceso de registro se realizo con exito');</script>";
				 if ($url == ""){ echo "<script language='Javascript'>location.href='list_conductores.php';</script>";}
}
}else {if (array_key_exists ('enviar', $_POST)){$error=1;}}

$colname_conductor = "-1";
if (isset($_GET['codigo'])) {
  $colname_conductor = $_GET['codigo'];
}
mysql_select_db($database_conex, $conex);
$query_conductor = sprintf("SELECT * FROM conductor WHERE Con_Cedula = %s", GetSQLValueString($colname_conductor, "text"));
$conductor = mysql_query($query_conductor, $conex) or die(mysql_error());
$row_conductor = mysql_fetch_assoc($conductor);
$totalRows_conductor = mysql_num_rows($conductor);

mysql_select_db($database_conex, $conex);
$query_proveedor = "SELECT Pro_Codigo, Pro_Nombre FROM proveedor ORDER BY Pro_Nombre ASC";
$proveedor = mysql_query($query_proveedor, $conex) or die(mysql_error());
$row_proveedor = mysql_fetch_assoc($proveedor);
$totalRows_proveedor = mysql_num_rows($proveedor);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>editar conductor</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="40" align="center" valign="bottom"><h3>Editar de Conductor</h3></td>
  </tr>
</table>
<form method="post" name="form1" action="<?php echo $editFormAction; ?>">
  <table width="95%" border="0" align="center" cellpadding="5" cellspacing="2">
    <tr valign="baseline">
      <td colspan="2" align="left" nowrap><?php if ($_POST && $error == 1) { echo $incompleto."<BR>";}?></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" nowrap class="Tcabeza"><h2>Datos del conductor</h2></td>
    </tr>
    <tr valign="baseline">
      <td width="50%" align="right" nowrap><label>C&eacute;dula:
      </label>
        <span id="sprytextfield1">
          <input name="Con_Cedula2" type="text" class="textInput" value="<?php echo $row_conductor['Con_Cedula']; ?>" size="32">
          <span class="textfieldInvalidFormatMsg">Formato no v&aacute;lido.</span></span></td>
      <td width="50%">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td width="50%" align="right" nowrap><label>Nombre(s):
        <?php if ($_POST && $_POST['Con_Nombre'] == "") { echo $icono;}?>
      </label>
        <input name="Con_Nombre" type="text" class="textInput" value="<?php echo $row_conductor['Con_Nombre']; ?>" size="32"></td>
      <td width="50%"><label>Apellido(s):
        <?php if ($_POST && $_POST['Con_Apellido'] == "") { echo $icono;}?>
      </label>
        <input name="Con_Apellido" type="text" class="textInput" value="<?php echo $row_conductor['Con_Apellido']; ?>" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td width="50%" align="right" nowrap><label>Proveedor: <span class="der linkAdd"><a href="add_proveedor.php?conductor=1">Agregar</a></span></label>
        <select name="Pro_Codigo" class="textInput select">
          <?php
do {  
?>
          <option value="<?php echo $row_proveedor['Pro_Codigo']?>"<?php if (!(strcmp($row_proveedor['Pro_Codigo'], $row_conductor['Pro_Codigo']))) {echo "selected=\"selected\"";} ?>><?php echo $row_proveedor['Pro_Nombre']?></option>
          <?php
} while ($row_proveedor = mysql_fetch_assoc($proveedor));
  $rows = mysql_num_rows($proveedor);
  if($rows > 0) {
      mysql_data_seek($proveedor, 0);
	  $row_proveedor = mysql_fetch_assoc($proveedor);
  }
?>
        </select></td>
      <td width="50%">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" align="right" nowrap class="Tcabeza">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" align="right" nowrap><input name="enviar" type="submit" class="button der" id="enviar" value="Editar">
        <input name="Restablecer" type="reset" class="button der" value="Restablecer">
        <input type="button" class="button der" onClick="location.href='principal.php'" value="Cancelar" /></td>
    </tr>
  </table>
  <input type="hidden" name="MM_update" value="form1">
  <input type="hidden" name="Con_Cedula" value="<?php echo $row_conductor['Con_Cedula']; ?>">
</form>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($conductor);

mysql_free_result($proveedor);
?>
