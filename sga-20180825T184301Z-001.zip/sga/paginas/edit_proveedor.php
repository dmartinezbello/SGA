<?php require_once('../Connections/conex.php'); ?>
<?php include('mensajes.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

$colname_duplicado = "-1";
if (isset($_POST['Pro_Rif'])) {
  $colname_duplicado = $_POST['Pro_Rif'];
}
mysql_select_db($database_conex, $conex);
$query_duplicado = sprintf("SELECT Pro_Rif FROM proveedor WHERE Pro_Rif = %s", GetSQLValueString($colname_duplicado, "text"));
$duplicado = mysql_query($query_duplicado, $conex) or die(mysql_error());
$row_duplicado = mysql_fetch_assoc($duplicado);
$totalRows_duplicado = mysql_num_rows($duplicado);

// Validar campos vacios y requeridos
	$error = 0;
	if (array_key_exists ('enviar', $_POST) && $_POST['Pro_Nombre']<>"" && $_POST['Pro_Rif']<>"" ){
if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE proveedor SET Pro_Nombre=%s, Pro_Rif=%s, Pro_Contacto=%s, Pro_Telefono=%s WHERE Pro_Codigo=%s",
                       GetSQLValueString($_POST['Pro_Nombre'], "text"),
                       GetSQLValueString($_POST['Pro_Rif'], "text"),
                       GetSQLValueString($_POST['Pro_Contacto'], "text"),
                       GetSQLValueString($_POST['Pro_Telefono'], "text"),
                       GetSQLValueString($_POST['Pro_Codigo'], "int"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($updateSQL, $conex) or die(mysql_error());
  //Borrar el array de datos, Enviar mensaje de edicion exitosa y redireccion a la lista de registros
	$_POST = array();
	echo "<script language='JavaScript'> alert('*** El proceso de edicion se realizo con exito');</script>";
	echo "<script language='Javascript'>location.href='list_proveedores.php';</script>";
	
}else {if (array_key_exists ('enviar', $_POST)){$error=1;}}
}



$colname_proveedor = "-1";
if (isset($_GET['codigo'])) {
  $colname_proveedor = $_GET['codigo'];
}
mysql_select_db($database_conex, $conex);
$query_proveedor = sprintf("SELECT * FROM proveedor WHERE Pro_Codigo = %s", GetSQLValueString($colname_proveedor, "int"));
$proveedor = mysql_query($query_proveedor, $conex) or die(mysql_error());
$row_proveedor = mysql_fetch_assoc($proveedor);
$totalRows_proveedor = mysql_num_rows($proveedor);


?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>editar almacen</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css">
<link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="40" align="center" valign="bottom"><h3>Editar de Proveedor</h3></td>
  </tr>
</table>
<p>&nbsp;</p>
<form method="post" name="form1" action="<?php echo $editFormAction; ?>">
  <table width="95%" border="0" align="center" cellpadding="5" cellspacing="2">
    <tr valign="baseline">
      <td colspan="2" align="left" nowrap>
		<?php if ($_POST && $error == 1) { echo $incompleto."<BR>";}?>
		<?php $pru =$totalRows_duplicado; if ($_POST && $pru > 0) { echo "<span class='obligatorio'>No se completo el proceso de registro porque ya existe uno identico. Por favor, vuelva a intentar introduciendo datos diferentes donde se refleja el icono: <span class='icon-obligaAzul'>&nbsp;&nbsp;&nbsp;&nbsp;</span></span>";}?></td>
    </tr>
    <tr valign="baseline">
      <td align="right" nowrap>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" align="left" nowrap class="Tcabeza"><h2>Descripci&oacute;n del proveedor</h2></td>
    </tr>
    <tr valign="baseline">
      <td width="50%" align="left" nowrap><label>Registro &Uacute;nico de Informaci&oacute;n Fiscal (RIF):
        <?php if ($_POST && $_POST['Pro_Rif'] == "") { echo $icono;}?>
      </label>
        <span id="sprytextfield2">
          <input name="Pro_Rifi" type="text" disabled class="textInput" value="<?php echo $row_proveedor['Pro_Rif']; ?>" size="32" readonly >
          <input name="Pro_Rif" type="hidden" class="textInput" value="<?php echo $row_proveedor['Pro_Rif']; ?>" size="32" >
        <span class="textfieldInvalidFormatMsg">Formato no v&aacute;lido.</span></span></td>
      <td width="50%">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td align="right" nowrap><label>Raz&oacute;n social:
        <?php if ($_POST && $_POST['Pro_Nombre'] == "") { echo $icono;}?>
      </label>
        <input name="Pro_Nombre" type="text" class="textInput" value="<?php echo $row_proveedor['Pro_Nombre']; ?>" size="32"></td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td width="50%" align="right" nowrap><label>Persona de contacto:</label>
        <input name="Pro_Contacto" type="text" class="textInput" value="<?php echo $row_proveedor['Pro_Contacto']; ?>" size="32"></td>
      <td width="50%"><label>Tel&eacute;fono:</label>
        <span id="sprytextfield1"><span id="sprytextfield3">
          <input name="Pro_Telefono" type="text" class="textInput" value="<?php echo $row_proveedor['Pro_Telefono']; ?>" size="32">
          <span class="textfieldInvalidFormatMsg">Formato no v&aacute;lido.</span></span><span class="textfieldInvalidFormatMsg">Formato invalido</span></span></td>
</tr>
    <tr valign="baseline">
      <td colspan="2" align="right" nowrap class="Tcabeza">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" align="right" nowrap><input name="enviar" type="submit" class="button der" id="enviar" value="Editar">
        <input name="Restablecer" type="reset" class="button der" value="Restablecer">
        <input type="button" class="button der" onClick="location.href='principal.php'" value="Cancelar" /></td>
    </tr>
    <tr valign="baseline"> </tr>
    <tr valign="baseline"> </tr>
  </table>
  <input type="hidden" name="MM_update" value="form1">
  <input type="hidden" name="Pro_Codigo" value="<?php echo $row_proveedor['Pro_Codigo']; ?>">
</form>
<p>&nbsp;</p>
<script type="text/javascript">
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "custom", {useCharacterMasking:true, isRequired:false, pattern:"0000-000 0000"});
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "custom", {pattern:"A-00000000-0", useCharacterMasking:true, isRequired:false});
</script>
</body>
<?php
mysql_free_result($proveedor);
mysql_free_result($duplicado);
?>
