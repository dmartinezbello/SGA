<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE proyecto SET Pro_Pozo=%s, Pro_Taladro=%s, Pro_Cliente=%s, Pro_Direccion=%s, Pro_Usuario=%s, Pro_Estatus=%s WHERE Pro_Logit=%s",
                       GetSQLValueString($_POST['Pro_Pozo'], "text"),
                       GetSQLValueString($_POST['Pro_Taladro'], "text"),
                       GetSQLValueString($_POST['Pro_Cliente'], "text"),
                       GetSQLValueString($_POST['Pro_Direccion'], "text"),
                       GetSQLValueString($_POST['Pro_Usuario'], "text"),
                       GetSQLValueString($_POST['Pro_Estatus'], "text"),
                       GetSQLValueString($_POST['Pro_Logit'], "text"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($updateSQL, $conex) or die(mysql_error());
  
  //Borrar el array de datos, Enviar mensaje de edicion exitosa y redireccion a la lista de registros
	$_POST = array();
	echo "<script language='JavaScript'> alert('*** El proceso de edicion se realizo con exito');</script>";
	echo "<script language='Javascript'>location.href='list_proyectos.php';</script>";
}

$colname_proyecto = "-1";
if (isset($_GET['codigo'])) {
  $colname_proyecto = $_GET['codigo'];
}
mysql_select_db($database_conex, $conex);
$query_proyecto = sprintf("SELECT * FROM proyecto WHERE Pro_Logit = %s", GetSQLValueString($colname_proyecto, "text"));
$proyecto = mysql_query($query_proyecto, $conex) or die(mysql_error());
$row_proyecto = mysql_fetch_assoc($proyecto);
$totalRows_proyecto = mysql_num_rows($proyecto);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>editar proyecto</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="../js/ajax.js"></script>
</head>

<body>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="40" align="center" valign="bottom"><h3>Editar de Proyecto</h3></td>
    </tr>
  </table>
  <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
    <table width="95%" border="0" align="center" cellpadding="5" cellspacing="2">
      <tr valign="baseline">
        <td colspan="3" nowrap><?php if ($_POST && $error == 1 && $totalRows_duplicado <= 0) { echo $incompleto."<BR>";}?>
          <?php if ($_POST && $totalRows_duplicado > 0) { echo "<span class='obligatorio'>No se completo el proceso de registro porque ya existe uno identico. Por favor, vuelva a intentar introduciendo datos diferentes donde se refleja el icono: <span class='icon-obligaAzul'>&nbsp;&nbsp;&nbsp;&nbsp;</span></span>";}?></td>
      </tr>
      <tr valign="baseline" class="Tcabeza">
        <td colspan="3" nowrap><h2>Datos del Proyecto</h2></td>
      </tr>
      <tr valign="baseline">
        <td width="25%" align="right" nowrap><label>Log-It:
          <?php if ($_POST && $_POST['Pro_Logit'] == "") { echo $icono;}?>
        </label>
          <input name="Pro_Logit2" type="text" disabled class="textInput" value="<?php echo $row_proyecto['Pro_Logit']; ?>" size="32"></td>
        <td width="25%" align="right" nowrap>&nbsp;</td>
        <td width="50%">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td width="25%" align="right" nowrap><label>Pozo:
          <?php if ($_POST && $_POST['Pro_Pozo'] == "") { echo $icono;}?>
        </label>
          <input name="Pro_Pozo" type="text" class="textInput mayusculas" value="<?php echo $row_proyecto['Pro_Pozo']; ?>" size="32"></td>
        <td width="25%" align="right" nowrap><label>Taladro:
          <?php if ($_POST && $_POST['Pro_Taladro'] == "") { echo $icono;}?>
        </label>
          <input name="Pro_Taladro" type="text" class="textInput mayusculas" value="<?php echo $row_proyecto['Pro_Taladro']; ?>" size="32"></td>
        <td width="50%">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td width="50%" colspan="2" align="right" nowrap><label>Cliente:
          <?php if ($_POST && $_POST['Pro_Cliente'] == "") { echo $icono;}?>
        </label>
          <input name="Pro_Cliente" type="text" class="textInput" value="<?php echo $row_proyecto['Pro_Cliente']; ?>" size="32"></td>
        <td width="50%">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td width="50%" colspan="2" align="right" nowrap><label>Ingeniero de proyecto:
          <?php if ($_POST && $_POST['Pro_Usuario'] == "") { echo $icono;}?>
        </label>
          <input name="Pro_Usuario" id="Pro_Usuario" type="text" class="textInput" value="<?php echo $row_proyecto['Pro_Usuario']; ?>" size="32" onBlur="Ingeniero();" ></td>
        <td width="50%"><div id="ingeniero">&nbsp;</div></td>
      </tr>
      <tr valign="baseline">
        <td colspan="3" align="right" nowrap><label>Direcci&oacute;n:
          <?php if ($_POST && $_POST['Pro_Direccion'] == "") { echo $icono;}?>
        </label>
          <textarea name="Pro_Direccion" cols="32" rows="3"><?php echo $row_proyecto['Pro_Direccion']; ?></textarea></td>
      </tr>
      <tr valign="baseline">
        <td colspan="3" align="right" nowrap class="Tcabeza">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td colspan="3" align="right" nowrap><input name="enviar" type="submit" class="button der" id="enviar" value="Editar">
          <input name="Restablecer" type="reset" class="button der" value="Restablecer">
          <input type="button" class="button der" onClick="history.back()" value="Volver" >
          <input name="atras" type="button" class="button" id="atras" value="Cancelar" onClick="javascript:history.back()" /></td>
      </tr>
    </table>
    <input type="hidden" name="MM_update" value="form1">
    <input type="hidden" name="Pro_Logit" value="<?php echo $row_proyecto['Pro_Logit']; ?>">
  </form>
  <p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($proyecto);
?>
