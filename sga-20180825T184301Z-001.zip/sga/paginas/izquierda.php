<?php //initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
  
  echo "<script> if (parent.frames.length > 0) { parent.location.href = '../index2.php'}</script>";
	
}
?>
<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_usuario = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_usuario = $_SESSION['MM_Username'];
}
mysql_select_db($database_conex, $conex);
$query_usuario = sprintf("SELECT Usuario, Nombres, Apellidos, Gin, Imagen FROM usuario WHERE Usuario = %s", GetSQLValueString($colname_usuario, "text"));
$usuario = mysql_query($query_usuario, $conex) or die(mysql_error());
$row_usuario = mysql_fetch_assoc($usuario);
$totalRows_usuario = mysql_num_rows($usuario);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Panel de tareas</title>
<link href="../css/sga.css" rel="stylesheet" type="text/css">
<style type="text/css">
body,td,th,p {
	font-size: 10px;
}
</style>
<link href="../css/estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
<table border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="left" valign="top">&nbsp;</td>
    <td align="left" valign="top"><?php if ($row_usuario['Imagen'] == "") {?><img src="../img/icon-usuario-v.png" width="60" height="60" alt="usuario" style=" padding-top:5px;"><?php } else {?> <img src="<?php echo $row_usuario['Imagen']; ?>" width="60" height="60" alt="usuario" style=" padding-top:7px;"> <?php }?></td>
    <td align="left" valign="top" >&nbsp;</td>
    <td align="left" valign="top" ><p style=" font-size:14px;"><?php echo $row_usuario['Nombres']; ?> <?php echo $row_usuario['Apellidos']; ?></p>
      <p style=" font-size:14px;"><strong>GIN:</strong> <?php echo $row_usuario['Gin']; ?></p>
    <p style=" font-size:14px;"><?php echo $row_usuario['Usuario']; ?>@slb.com</p></td>
  </tr>
  <tr>
    <td align="center" valign="top">&nbsp;</td>
    <td align="center" valign="top">
    <?php if ($_SESSION['MM_Username']<>"") {?>
        <a href="<?php echo $logoutAction ?>" target="mainFrame">Cerrar Sesi&oacute;n&nbsp;</a>
    <?php }?>
    </td>
    <td align="left" valign="top" >&nbsp;</td>
    <td align="left" valign="top" >&nbsp;</td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="5%" align="right">
    
    </td>
  </tr>
  <tr>
    <td height="5%" colspan="2" align="right" bgcolor="#F0F0F0">&nbsp;</td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td align="left" valign="middle"><h3>Estad&iacute;stica </h3></td>
    <td align="left" valign="middle"><img src="../img/estadisticas_exportacion.jpg" alt="estadisticas" width="61" height="47" class="der"></td>
  </tr>
  <tr>
    <td colspan="2"><p><img src="../img/icon-obligaAzul.png" width="9" height="9" alt="icono"> Lotes no evaluados <strong>(12)</strong></p>
        <p><img src="../img/icon-obligaAzul.png" width="9" height="9" alt="icono"> Lotes sin certificados de calidad <strong>(332)</strong></p>
      <p><img src="../img/icon-obligaAzul.png" width="9" height="9" alt="icono"> Productos registrados <strong>(198)</strong></p>
      <p><img src="../img/icon-obligaAzul.png" width="9" height="9" alt="icono"> Productos por recibir <strong>(332)</strong></p>
      <p><img src="../img/icon-obligaAzul.png" width="9" height="9" alt="icono"> Productos sin MSDS <strong>(3)</strong></p>
      <p><img src="../img/icon-obligaAzul.png" width="9" height="9" alt="icono"> Productos sin bolet&iacute;n t&eacute;cnico <strong>(6)</strong></p></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($usuario);
?>
