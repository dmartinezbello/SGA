<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_conex, $conex);
$query_listaAlmacenes = "SELECT * FROM almacen ORDER BY Alm_Nombre ASC";
$listaAlmacenes = mysql_query($query_listaAlmacenes, $conex) or die(mysql_error());
$row_listaAlmacenes = mysql_fetch_assoc($listaAlmacenes);
$totalRows_listaAlmacenes = mysql_num_rows($listaAlmacenes);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Listar almacenes</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="40" align="center" valign="bottom"><h3>Lista de Almacenes</h3></td>
  </tr>
</table>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="5">&nbsp;</td>
  </tr>
  <?php if ($totalRows_listaAlmacenes == 0) { // Show if recordset empty ?>
  <table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td align="center"><h2>Hasta el momento no hay registros para mostar</h2></td>
      </tr>
  </table>
  <?php } // Show if recordset empty ?>
<tr>
    <td height="15">&nbsp;
      <?php if ($totalRows_listaAlmacenes > 0) { // Show if recordset not empty ?>
  <table width="95%" border="0" align="center" cellpadding="5" cellspacing="1">
    <tr>
      <td colspan="4" align="right">
        <a href="add_almacen.php"><span class="izq">Agregar nuevo almac&eacute;n +</span></a>
        Registros listados(<?php echo $totalRows_listaAlmacenes; ?>)
        </td>
      </tr>
    <tr class="Tcabeza">
      <td width="5%"><p style="text-align:center">L&iacute;nea</p></td>
      <td width="75%"><p>Almacen</p></td>
      <td width="5%"><p style="text-align:center;">Editar</p></td>
      <td width="5%"><p style="text-align:center;">Eliminar</p></td>
      </tr>
    <?php do { $numero++; ?>
    <tr>
      <td width="5%" align="center" valign="middle" class="lineaInfPunta"><?php echo $numero; ?></td>
      <td width="75%" class="lineaInfPunta"><p><strong>C&oacute;digo:</strong>
        <?php echo $row_listaAlmacenes['Alm_Codigo']; ?></p>
        <p><strong>Nombre:</strong>
          <?php echo $row_listaAlmacenes['Alm_Nombre']; ?></p>
        <p><strong>Direcci&oacute;n:</strong>
          <?php echo $row_listaAlmacenes['Alm_Direccion']; ?></p></td>
      <td width="5%" align="center" valign="middle" class="lineaInfPunta"><a href="edit_almacen.php?codigo=<?php echo $row_listaAlmacenes['Alm_Codigo']; ?>"><span class="icon-editar">
        &nbsp;</span></a></td>
      <td width="5%" align="center" valign="middle" class="lineaInfPunta"><a href="del_almacen.php?codigo=<?php echo $row_listaAlmacenes['Alm_Codigo']; ?>"><span class="icon-del">&nbsp;</span></a></td>
      </tr>
    <?php } while ($row_listaAlmacenes = mysql_fetch_assoc($listaAlmacenes)); ?>
  </table>
  <?php } // Show if recordset not empty ?></td>
  </tr>
  <tr>
    <td height="5">&nbsp;</td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($listaAlmacenes);
?>
