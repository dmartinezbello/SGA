<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_conex, $conex);
$query_conductores = "SELECT conductor.Con_Cedula, conductor.Con_Nombre, conductor.Con_Apellido, proveedor.Pro_Nombre, proveedor.Pro_Rif FROM conductor, proveedor WHERE proveedor.Pro_Codigo=conductor.Pro_Codigo ORDER BY Con_Nombre, conductor.Con_Cedula ASC";
$conductores = mysql_query($query_conductores, $conex) or die(mysql_error());
$row_conductores = mysql_fetch_assoc($conductores);
$totalRows_conductores = mysql_num_rows($conductores);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Lista de conductores</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="40" align="center" valign="bottom"><h3>Lista de Conductores</h3></td>
    </tr>
  </table>
  <table width="95%" border="0" align="center" cellpadding="5" cellspacing="1">
    <tr>
      <td colspan="5" align="right">
      <a href="add_almacen.php"><span class="izq">Agregar nuevo conductor +</span></a>
        Registros listados(<?php echo $totalRows_conductores; ?>)
      </td>
    </tr>
    <tr class="Tcabeza">
      <td width="5%"><p style="text-align:center">L&iacute;nea</p></td>
      <td width="50%"><p>Datos del conductos</p></td>
      <td width="35%"><p>Datos del proveedor</p></td>
      <td width="5%"><p style="text-align:center;">Editar</p></td>
      <td width="5%"><p style="text-align:center;">Eliminar</p></td>
    </tr>
    <?php do { $numero++; ?>
      <tr>
        <td width="5%" align="center" valign="middle" class="lineaInfPunta"><?php echo $numero; ?></td>
        <td class="lineaInfPunta"><p><strong>C&eacute;dula:</strong> <?php echo $row_conductores['Con_Cedula']; ?></p>
          <p><strong>Nombre:</strong> <?php echo $row_conductores['Con_Nombre']; ?> <?php echo $row_conductores['Con_Apellido']; ?></p></td>
        <td class="lineaInfPunta"><p><strong>RIF:</strong> <?php echo $row_conductores['Pro_Rif']; ?></p>
        <p><strong>Empresa:</strong> <?php echo $row_conductores['Pro_Nombre']; ?></p></td>
        <td width="5%" align="center" valign="middle" class="lineaInfPunta"><a href="edit_conductor.php?codigo=<?php echo $row_conductores['Con_Cedula']; ?>"><span class="icon-editar"> &nbsp;</span></a></td>
        <td width="5%" align="center" valign="middle" class="lineaInfPunta"><a href="del_conductor.php?codigo=<?php echo $row_conductores['Con_Cedula']; ?>"><span class="icon-del">&nbsp;</span></a></td>
      </tr>
      <?php } while ($row_conductores = mysql_fetch_assoc($conductores)); ?>
  </table>
</body>
</html>
<?php
mysql_free_result($conductores);
?>
