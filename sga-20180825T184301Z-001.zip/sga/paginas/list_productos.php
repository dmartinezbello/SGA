<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_conex, $conex);
$query_consultaProductos = "SELECT * FROM productos ORDER BY Pro_Nombre ASC";
$consultaProductos = mysql_query($query_consultaProductos, $conex) or die(mysql_error());
$row_consultaProductos = mysql_fetch_assoc($consultaProductos);
$totalRows_consultaProductos = mysql_num_rows($consultaProductos);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Listar productos</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="40" align="center" valign="bottom"><h3>Lista de Productos Qu&iacute;micos</h3></td>
  </tr>
</table>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="5">&nbsp;</td>
  </tr>
   <?php if ($totalRows_consultaProductos == 0) { // Show if recordset empty ?>
  <table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td align="center"><h2>Hasta el momento no hay registros para mostar</h2></td>
      </tr>
  </table>
  <?php } // Show if recordset empty ?>
  <tr>
    <td height="15"><?php if ($totalRows_consultaProductos > 0) { // Show if recordset not empty ?>
         
<br>
        <table width="95%" border="0" align="center" cellpadding="5" cellspacing="1">
    <tr>
      <td colspan="11" align="right">
        <a href="add_producto.php"><span class="izq">Agregar nuevo producto +</span></a>
        Registros listados (<?php echo $totalRows_consultaProductos; ?>)
      </td>
      </tr>
    <tr>
      <td colspan="3" class="Tcabeza"><p>Especificaciones Generales</p></td>
      <td colspan="4" align="center" class="Tcabeza"><p style="text-align:center;">Clasificaci&oacute;n de Peligro</p></td>
      <td colspan="2" align="center" class="Tcabeza"><p style="text-align:center;">Descargas</p></td>
      <td colspan="2" align="center" class="Tcabeza"><p style="text-align:center;">Operaciones</p></td>
      </tr>
    <tr>
      <td width="25" align="left" class="Tcabeza"><p>L&iacute;nea</p></td>
      <td width="25" align="left" class="Tcabeza"><p>C&oacute;digo</p></td>
      <td align="left" class="Tcabeza"><p>Descripci&oacute;n</p></td>
      <td width="40" align="center" bgcolor="#0066FF" class="bordeNegroSolido" style="color:#FFF;">S</td>
      <td width="40" align="center" bgcolor="#FF0033" class="bordeNegroSolido" style="color:#FFF;">I</td>
      <td width="40" align="center" bgcolor="#FFCC00" class="bordeNegroSolido">R</td>
      <td width="40" align="center" class="bordeNegroSolido">P</td>
      <td width="60" align="center" class="Tcabeza"><p>Hoja de</p>
        <p> Seguridad</p></td>
      <td width="60" align="center" class="Tcabeza"><p>Boletin</p>
        <p> T&eacute;cnico</p></td>
      <td width="60" class="Tcabeza"><p style="text-align:center;">Editar</p></td>
      <td width="60" class="Tcabeza"><p style="text-align:center;">Eliminar</p></td>
      </tr>
    <?php do { $numero++; ?>
    <tr>
      <td align="center" class="lineaInfPunta"><?php echo $numero; ?></td>
      <td align="left" class="lineaInfPunta"><p><?php echo $row_consultaProductos['Pro_Codigo']; ?></p></td>
      <td align="left" class="lineaInfPunta"><p><?php echo $row_consultaProductos['Pro_Nombre']; ?>, <?php echo $row_consultaProductos['Pro_Empaque']; ?> de <?php echo $row_consultaProductos['Pro_Peso']; ?> <?php echo $row_consultaProductos['Pro_Unidad']; ?></p></td>
      <td align="center" class="lineaInfPunta"><p style="text-align:center;"><?php echo $row_consultaProductos['Pro_Salud']; ?></p></td>
      <td align="center" class="lineaInfPunta"><p style="text-align:center;"><?php echo $row_consultaProductos['Pro_Inflamabilidad']; ?></p></td>
      <td align="center" class="lineaInfPunta"><p style="text-align:center;"><?php echo $row_consultaProductos['Pro_Reactividad']; ?></p></td>
      <td align="center" class="lineaInfPunta"><p style="text-align:center;"><?php echo $row_consultaProductos['Pro_Proteccion']; ?></p></td>
      <td align="center" class="lineaInfPunta">
        <a href="<?php echo $row_consultaProductos['Pro_Msds'];?>" target="new"><span class="icon-descargar"> &nbsp;</span></a>
        </td>
      <td align="center" class="lineaInfPunta">
        <a href="<?php echo $row_consultaProductos['Pro_Tecnica']; ?>" target="new"><span class="icon-descargar">&nbsp;</span></a>
        </td>
      <td align="center" class="lineaInfPunta"><a href="edit_producto.php?codigo=<?php echo $row_consultaProductos['Pro_Codigo']; ?>"><span class="icon-editar"> &nbsp;</span></a></td>
      <td align="center" class="lineaInfPunta"><a href="del_producto.php?codigo=<?php echo $row_consultaProductos['Pro_Codigo']; ?>"><span class="icon-del">&nbsp;</span></a></td>
      </tr>
    <?php } while ($row_consultaProductos = mysql_fetch_assoc($consultaProductos)); ?>
  </table>
  <?php } // Show if recordset not empty ?></td>
  </tr>
  <tr>
    <td height="5">&nbsp;</td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($consultaProductos);
?>
