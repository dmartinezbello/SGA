<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_conex, $conex);
$query_proveedores = "SELECT * FROM proveedor ORDER BY Pro_Nombre ASC";
$proveedores = mysql_query($query_proveedores, $conex) or die(mysql_error());
$row_proveedores = mysql_fetch_assoc($proveedores);
$totalRows_proveedores = mysql_num_rows($proveedores);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Listar almacenes</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="40" align="center" valign="bottom"><h3>Lista de Proveedores</h3></td>
  </tr>
</table>
<table width="95%" border="0" align="center" cellpadding="5" cellspacing="1">
  <tr>
    <td colspan="7" align="right">
    <a href="add_proveedor.php"><span class="izq">Agregar nuevo proveedor +</span></a>
        Registros listados (<?php echo $totalRows_proveedores; ?>)
    </td>
    </tr>
  <tr class="Tcabeza">
    <td width="5%" align="center"><p style="text-align:center;">L&iacute;nea</p></td>
    <td width="20%"><p>Registro &Uacute;Inico de Informaci&oacute;n Fiscal</p></td>
    <td width="30%"><p>Raz&oacute;n social</p></td>
    <td width="20%"><p>Contacto</p></td>
    <td width="15%"><p>Tel&eacute;fono</p></td>
    <td width="5%"><p style="text-align:center;">Editar</p></td>
    <td width="5%"><p style="text-align:center;">Eliminar</p></td>
    </tr>
  <?php do { $numero++; ?>
    <tr>
      <td align="center" class="lineaInfPunta"><?php echo $numero; ?></td>
      <td class="lineaInfPunta"><p><?php echo $row_proveedores['Pro_Rif']; ?></p></td>
      <td class="lineaInfPunta"><p><?php echo $row_proveedores['Pro_Nombre']; ?></p></td>
      <td class="lineaInfPunta"><p><?php echo $row_proveedores['Pro_Contacto']; ?></p></td>
      <td class="lineaInfPunta"><p><?php echo $row_proveedores['Pro_Telefono']; ?></p></td>
      <td align="center" class="lineaInfPunta"><a href="edit_proveedor.php?codigo=<?php echo $row_proveedores['Pro_Codigo']; ?>"><span class="icon-editar"> &nbsp;</span></a></td>
      <td align="center" class="lineaInfPunta"><a href="del_proveedor.php?codigo=<?php echo $row_proveedores['Pro_Codigo']; ?>"><span class="icon-del">&nbsp;</span></a></td>
      </tr>
    <?php } while ($row_proveedores = mysql_fetch_assoc($proveedores)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($proveedores);
?>
