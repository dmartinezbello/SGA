<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_conex, $conex);
$query_proyectos = "SELECT Pro_Logit, Pro_Pozo, Pro_Taladro, Pro_Cliente, Pro_Direccion, Nombres, Apellidos, Usuario, Gin, Telefono, Imagen FROM proyecto, usuario WHERE Pro_Estatus  IS NULL   AND Usuario = Pro_Usuario ORDER BY Pro_Taladro ASC";
$proyectos = mysql_query($query_proyectos, $conex) or die(mysql_error());
$row_proyectos = mysql_fetch_assoc($proyectos);
$totalRows_proyectos = mysql_num_rows($proyectos);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Lista de proyectos</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="40" align="center" valign="bottom"><h3>Lista de Proyectos</h3></td>
    </tr>
  </table>
  <table width="95%" border="0" align="center" cellpadding="3" cellspacing="2">
    <tr>
      <td colspan="9" align="right"><a href="add_proyecto.php"><span class="izq">Agregar nuevo proyecto +</span></a>Registros listados(<?php echo $totalRows_proyectos; ?>)</td>
    </tr>
    <tr>
      <td width="5%" class="Tcabeza"><p class="textCenter">L&iacute;nea</p></td>
      <td width="20%" class="Tcabeza"><p>Taladro</p></td>
      <td width="10%" class="Tcabeza"><p>Pozo</p></td>
      <td width="10%" class="Tcabeza"><p>Logit</p></td>
      <td width="25%" class="Tcabeza"><p>Cliente</p></td>
      <td colspan="2" class="Tcabeza"><p>Ingeniero del proyecto:</p></td>
      <td width="5%" class="Tcabeza"><p class="textCenter">Editar</p></td>
      <td width="5%" class="Tcabeza"><p>Eliminar</p></td>
    </tr>
    <?php do { $num ++; ?>
      <tr>
        <td width="5%" rowspan="2" class="lineaInfPunta"><p class="textCenter"><?php echo $num; ?></p></td>
        <td width="20%"><p><?php echo $row_proyectos['Pro_Taladro']; ?></p></td>
        <td width="10%"><p><?php echo $row_proyectos['Pro_Pozo']; ?></p></td>
        <td width="10%"><p><?php echo $row_proyectos['Pro_Logit']; ?></p></td>
        <td width="25%"><p><?php echo $row_proyectos['Pro_Cliente']; ?></p></td>
        <td width="15%" rowspan="2" class="lineaInfPunta"><p><?php echo $row_proyectos['Nombres'].' '.$row_proyectos['Apellidos']; ?></p>
          <p>E-mail: <a href="mailto:<?php echo $row_proyectos['Usuario'].'@slb.com?subject='.$row_proyectos['Pro_Taladro'].'    ::    '.$row_proyectos['Pro_Pozo']; ?>"><?php echo $row_proyectos['Usuario']; ?>@slb.com</a></p>
          <p>GIN: <?php echo $row_proyectos['Gin']; ?></p>
        <p>Tel&eacute;fono: <?php echo $row_proyectos['Telefono']; ?></p></td>
        <td width="5%" rowspan="2" valign="bottom" class="lineaInfPunta"><img src="<?php if ($row_proyectos['Imagen'] == ''){ echo "http://localhost/sga/img/icon-usuario-v.png"; }else { echo $row_proyectos['Imagen'];} ?>" width="62" height="62"></td>
        <td width="5%" rowspan="2" align="center" class="lineaInfPunta"><a href="edit_proyecto.php?codigo=<?php echo $row_proyectos['Pro_Logit']; ?>"><span class="icon-editar"> &nbsp;</span></a></td>
        <td width="5%" rowspan="2" align="center" class="lineaInfPunta"><a href="del_proyecto.php?codigo=<?php echo $row_proyectos['Pro_Logit']; ?>"><span class="icon-del">&nbsp;</span></a></td>
      </tr>
      <tr>
        <td colspan="4" valign="top" class="lineaInfPunta"><p><strong>Direcci&oacute;n:</strong> <?php echo $row_proyectos['Pro_Direccion']; ?></p></td>
      </tr>
      <?php } while ($row_proyectos = mysql_fetch_assoc($proyectos)); ?>
  </table>
</body>
</html>
<?php
mysql_free_result($proyectos);
?>
