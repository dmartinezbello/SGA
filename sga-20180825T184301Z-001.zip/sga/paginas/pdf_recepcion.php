<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_conex, $conex);
$query_agregados = "SELECT recepcion.Pro_Codigo, CONCAT( productos.Pro_codigo, ' - ',Pro_Nombre , ', ' , Pro_Empaque , ' de ' , Pro_Peso , ' ' , Pro_Unidad ) AS Descripcion, Sol_Odc, Rec_Solicitud, SUM(Rec_Cantidad) AS Total FROM recepcion, productos, solicitud WHERE Rec_Numero ='".$_GET['recepcion']."' AND Rec_Solicitud = Sol_Serial AND productos.Pro_Codigo = recepcion.Pro_Codigo GROUP BY recepcion.Pro_Codigo, Sol_Odc, Rec_Solicitud ORDER BY recepcion.Pro_Codigo, Sol_Odc, Rec_Solicitud ASC";
$agregados = mysql_query($query_agregados, $conex) or die(mysql_error());
$row_agregados = mysql_fetch_assoc($agregados);
$totalRows_agregados = mysql_num_rows($agregados);

mysql_select_db($database_conex, $conex);
$query_usuario = "SELECT Ent_Usuario, Ent_Observacion, Nombres, Apellidos, Gin FROM entrada, usuario WHERE Ent_Numero =  '".$_GET['recepcion']."' AND Ent_Usuario = Usuario";
$usuario = mysql_query($query_usuario, $conex) or die(mysql_error());
$row_usuario = mysql_fetch_assoc($usuario);
$totalRows_usuario = mysql_num_rows($usuario);

$colname_almacen = "-1";
if (isset($_GET['recepcion'])) {
  $colname_almacen = $_GET['recepcion'];
}
mysql_select_db($database_conex, $conex);
$query_almacen = sprintf("SELECT almacen.Alm_Codigo, almacen.Alm_Nombre, almacen.Alm_Direccion FROM entrada, almacen WHERE Ent_Numero = %s AND almacen.Alm_Codigo = entrada.Alm_Codigo", GetSQLValueString($colname_almacen, "text"));
$almacen = mysql_query($query_almacen, $conex) or die(mysql_error());
$row_almacen = mysql_fetch_assoc($almacen);
$totalRows_almacen = mysql_num_rows($almacen);

?>
<?php 
require ("../librerias/fpdf.php");
$GLOBALS['Email'] = $row_usuario['Ent_Usuario'];
$GLOBALS['Nombre'] = $row_usuario['Nombres'];
$GLOBALS['Apellido'] = $row_usuario['Apellidos'];
$GLOBALS['Gin'] = $row_usuario['Gin'];
$GLOBALS['Observacion'] = $row_usuario['Ent_Observacion'];
$GLOBALS['Almacen'] = $row_almacen['Alm_Nombre'];
$GLOBALS['Codigo_Almacen'] = $row_almacen['Alm_Codigo'];
$GLOBALS['Direccion_Almacen'] = $row_almacen['Alm_Direccion'];
class PDF extends FPDF 
{
var $widths;
var $aligns;
function SetWidths($w)
{
	//Set the array of column widths
	$this->widths=$w;
}


function SetAligns($a)
{
	//Set the array of column alignments
	$this->aligns=$a;
}

function Row($data)
{
	$this->SetDrawColor(233,233,233);
    //Ancho del borde (1 mm)
    $this->SetLineWidth(0.3);
   //Calculate the height of the row
	$nb=0;
	for($i=0;$i<count($data);$i++)
		$nb=max($nb,$this->NbLines($this->widths[$i],$data[$i]));
	$h=5*$nb;
	//Issue a page break first if needed
	$this->CheckPageBreak($h);
	//Draw the cells of the row
	for($i=0;$i<count($data);$i++)
	{
		$w=$this->widths[$i];
		$a=isset($this->aligns[$i]) ? $this->aligns[$i] : 'L';
		//Save the current position
		$x=$this->GetX();
		$y=$this->GetY();
		//Draw the border
		$this->Rect($x,$y,$w,$h);
		//Print the text
		$this->MultiCell($w,5,$data[$i],0,$a);
		//Put the position to the right of the cell
		$this->SetXY($x+$w,$y);
	}
	//Go to the next line
	$this->SetDrawColor(0,0,0);
    $this->SetFillColor(255,255,255);
    $this->SetTextColor(0,0,0);
    //Ancho del borde (1 mm)
    $this->SetLineWidth(0.1);
	$this->Ln($h);
}

function CheckPageBreak($h)
{
	//If the height h would cause an overflow, add a new page immediately
	if($this->GetY()+$h>$this->PageBreakTrigger)
		$this->AddPage($this->CurOrientation);
}

function NbLines($w,$txt)
{
	//Computes the number of lines a MultiCell of width w will take
	$cw=&$this->CurrentFont['cw'];
	if($w==0)
		$w=$this->w-$this->rMargin-$this->x;
	$wmax=($w-2*$this->cMargin)*1000/$this->FontSize;
	$s=str_replace("\r",'',$txt);
	$nb=strlen($s);
	if($nb>0 and $s[$nb-1]=="\n")
		$nb--;
	$sep=-1;
	$i=0;
	$j=0;
	$l=0;
	$nl=1;
	while($i<$nb)
	{
		$c=$s[$i];
		if($c=="\n")
		{
			$i++;
			$sep=-1;
			$j=$i;
			$l=0;
			$nl++;
			continue;
		}
		if($c==' ')
			$sep=$i;
		$l+=$cw[$c];
		if($l>$wmax)
		{
			if($sep==-1)
			{
				if($i==$j)
					$i++;
			}
			else
				$i=$sep+1;
			$sep=-1;
			$j=$i;
			$l=0;
			$nl++;
		}
		else
			$i++;
	}
	return $nl;
}
// Cabecera de p�gina
function Header()
{
    // Logo
		 $this->SetXY(10, 2);
		 $this->Image('../Img/logo_slb.png',8,5,50);
	 //Encabezado
		 $this->SetXY(10,7);
		 $this->SetFont('slb','',12);
		 $this->Cell(275,4,"RECEPCION DE PRODUCTOS EN ALMACEN",0,0,'C');
	 // Direccion Fiscal 
		 $this->SetFont('slbB','',10);
		 $this->SetXY(20,2);
		 $this->Cell(26,32,"Schlumberger de Venezuela S.A.",0,0,'C');
		 $this->SetFont('slbB','',10);
		 $this->Cell(-48,43,"Direcci�n Fiscal:",0,0,'C');
		 $this->SetFont('slb','',10);
		 $this->Cell(81,50,"Av. Rio Caura, Centro Empresarial Torre Humboldt,",0,0,'C');
		 $this->Cell(-73,57,"Piso 13, Ofic. 13, Prados del Este - Telf.:(0212) 907.47.11,",0,0,'C');
		 $this->Cell(35,64,"Caracas 1080, Venezuela",0,0,'C');
		 $this->Cell(-35,71,"R.I.F. No.: J-00329781-0",0,0,'C');
    // Datos del almacen 
		 $this->SetXY(80,17);
		 $this->Cell(50,4,"ALMACEN:",0,1,'L');
	 // $this->Line(80,21,130,21);
		 $this->SetXY(80,21);
		 $this->SetFont('slbB','',9);
		 $this->Cell(70,4,$GLOBALS['Almacen'],0,0,'L');
		 $this->SetFont('slb','',10);
		 $this->SetXY(80,25);
		 $this->Cell(50,4,"C�digo: ".$GLOBALS['Codigo_Almacen'],0,0,'L');
		 $this->SetXY(80,29);
		 $this->MultiCell(50, 4,$GLOBALS['Direccion_Almacen'],0,1);
	 // Datos del Proveedor
		 $this->SetXY(140,17);
		 $this->Cell(50,4,"PROVEEDOR:",0,1,'L');
	 //$this->Line(140,21,190,21);
		 $this->SetXY(140,21);
		 $this->SetFont('slbB','',10);
		 $this->Cell(70,4,"Servicios y Soluciones DM",0,0,'L');
		 $this->SetFont('slb','',10);
		 $this->SetXY(140,25);
		 $this->Cell(50,4,"R.I.F. No.: J-00329781-0",0,0,'L');
		 $this->SetXY(140,29);
		 $this->Cell(50,4,"Contacto: Daniel Martinez",0,0,'L');
		 $this->SetXY(140,33);
		 $this->Cell(50,4,"Tel�fono: 0414-674 3868",0,0,'L');
	 // Datos del Conductor
		 $this->SetXY(200,17);
		 $this->Cell(50,4,"TRANSPORTISTA:",0,1,'L');
	 //$this->Line(200,21,250,21);
		 $this->SetXY(200,21);
		 $this->SetFont('slbB','',10);
		 $this->Cell(70,4,"Daniel Martinez",0,0,'L');
		 $this->SetFont('slb','',10);
		 $this->SetXY(200,25);
		 $this->Cell(50,4,"Licencia: 19.037.064",0,0,'L');
		 $this->SetXY(200,29);
		 $this->Cell(50,4,"Empresa: Servicios y Soluciones DM",0,0,'L');
		 $this->SetXY(200,33);
		 $this->Cell(50,4,"R.I.F. No.: J-00329781-0",0,0,'L');
	  // Fecha
		 $this->SetXY(250,17);
		 $this->Cell(35,4,"FECHa Y HORA:",0,1,'R');
	 //$this->Line(200,21,250,21);
		 $this->SetXY(250,21);
		 $this->SetFont('slbB','',9);
		 $this->Cell(35,4,"2014-01-29 22:07:41",0,0,'R');
	
	//$this->Cell(16,57,"Avenida Principal Punta de Mata, Zona Industrial, Galpon M-I SWACO. Punta de Mata, Edo. Monagas, 6201, VE",0,0,'C');
	//Ancho del borde (1 mm)

    // incluir fuente SLB
		$this->SetFont('slb','',10);
	// Linea horizontal
		$this->Line(10,42,285,42);
    // Salto de l�nea
    	$this->Ln(20);
	//Numero de Control
		$NC = $_GET['recepcion'];
		$this->SetXY(250,8);
		$this->SetFont('slb','',10);
		$this->Cell(35,4,'NUMERO DE CONTROL',0,0,'R');
		$this->SetTextColor(255, 0, 0);
		$this->SetXY(250,12);
		$this->SetFont('slb','',14);
		$this->Cell(35,6,$NC,0,0,'R');
		$this->Ln(-10);
}
// Pie de p�gina
function Footer()
{
	
	// Linea horizontal
		//$this->Line(10,180,285,180);
    	$this->SetY(-20);
		$this->SetXY(10, 180);
		$this->SetFont('slbB','',10);
		$this->Cell(83,4,"Recibido por:",1,0);
		$this->SetFont('slb','',9);
		$this->SetXY(10, 185); 
		$this->Cell(83,4,$GLOBALS['Nombre']." ".$GLOBALS['Apellido'],0,1);
		
		$this->SetXY(10, 189); 
		$this->Cell(83,4,$GLOBALS['Email']."@slb.com",0,1,'J',true);
		
		$this->SetXY(10, 193); 
		$this->Cell(83,4,"GIN: ".$GLOBALS['Gin']."         ....................................................................................",0,1);
		$this->SetXY(95, 180);
		$this->SetFont('slbB','',10);
		$this->Cell(190,4,"Observacion(nes):",1,1);
		$this->SetXY(95, 185);
		$this->SetFont('slb','',9);
		$this->MultiCell(190,3,$GLOBALS['Observacion']." ",0,1,'J',true);
		$this->SetFont('slb','',9);
		$this->SetXY(10, 180);
		$this->Cell(83,22,'',1,0);
		
    // N�mero de p�gina
		$this->SetFont('slb','',8);
		$this->SetXY(100, 203);
		$this->Cell(190,4,'P�g. '.$this->PageNo().'/{nb}',0,0,'R');
		$this->SetXY(95, 180);
		$this->Cell(190,22,'',1,0);
}

function Cell($w, $h=0, $txt='', $border=0, $ln=0, $align='', $fill=false, $link='')
{
    $k=$this->k;
    if($this->y+$h>$this->PageBreakTrigger && !$this->InHeader && !$this->InFooter && $this->AcceptPageBreak())
    {
        $x=$this->x;
        $ws=$this->ws;
        if($ws>0)
        {
            $this->ws=0;
            $this->_out('0 Tw');
        }
        $this->AddPage($this->CurOrientation);
        $this->x=$x;
        if($ws>0)
        {
            $this->ws=$ws;
            $this->_out(sprintf('%.3F Tw',$ws*$k));
        }
    }
    if($w==0)
        $w=$this->w-$this->rMargin-$this->x;
    $s='';
    if($fill || $border==1)
    {
        if($fill)
            $op=($border==1) ? 'B' : 'f';
        else
            $op='S';
        $s=sprintf('%.2F %.2F %.2F %.2F re %s ',$this->x*$k,($this->h-$this->y)*$k,$w*$k,-$h*$k,$op);
    }
    if(is_string($border))
    {
        $x=$this->x;
        $y=$this->y;
        if(is_int(strpos($border,'L')))
            $s.=sprintf('%.2F %.2F m %.2F %.2F l S ',$x*$k,($this->h-$y)*$k,$x*$k,($this->h-($y+$h))*$k);
        if(is_int(strpos($border,'T')))
            $s.=sprintf('%.2F %.2F m %.2F %.2F l S ',$x*$k,($this->h-$y)*$k,($x+$w)*$k,($this->h-$y)*$k);
        if(is_int(strpos($border,'R')))
            $s.=sprintf('%.2F %.2F m %.2F %.2F l S ',($x+$w)*$k,($this->h-$y)*$k,($x+$w)*$k,($this->h-($y+$h))*$k);
        if(is_int(strpos($border,'B')))
            $s.=sprintf('%.2F %.2F m %.2F %.2F l S ',$x*$k,($this->h-($y+$h))*$k,($x+$w)*$k,($this->h-($y+$h))*$k);
    }
    if($txt!='')
    {
        if($align=='R')
            $dx=$w-$this->cMargin-$this->GetStringWidth($txt);
        elseif($align=='C')
            $dx=($w-$this->GetStringWidth($txt))/2;
        elseif($align=='FJ')
        {
            //Set word spacing
            $wmax=($w-2*$this->cMargin);
            $this->ws=($wmax-$this->GetStringWidth($txt))/substr_count($txt,' ');
            $this->_out(sprintf('%.3F Tw',$this->ws*$this->k));
            $dx=$this->cMargin;
        }
        else
            $dx=$this->cMargin;
        $txt=str_replace(')','\\)',str_replace('(','\\(',str_replace('\\','\\\\',$txt)));
        if($this->ColorFlag)
            $s.='q '.$this->TextColor.' ';
        $s.=sprintf('BT %.2F %.2F Td (%s) Tj ET',($this->x+$dx)*$k,($this->h-($this->y+.5*$h+.3*$this->FontSize))*$k,$txt);
        if($this->underline)
            $s.=' '.$this->_dounderline($this->x+$dx,$this->y+.5*$h+.3*$this->FontSize,$txt);
        if($this->ColorFlag)
            $s.=' Q';
        if($link)
        {
            if($align=='FJ')
                $wlink=$wmax;
            else
                $wlink=$this->GetStringWidth($txt);
            $this->Link($this->x+$dx,$this->y+.5*$h-.5*$this->FontSize,$wlink,$this->FontSize,$link);
        }
    }
    if($s)
        $this->_out($s);
    if($align=='FJ')
    {
        //Remove word spacing
        $this->_out('0 Tw');
        $this->ws=0;
    }
    $this->lasth=$h;
    if($ln>0)
    {
        $this->y+=$h;
        if($ln==1)
            $this->x=$this->lMargin;
    }
    else
        $this->x+=$w;
}
///////////////////////////////////////////////////////////////////
// Tabla coloreada
function FancyTable($header)
{
    $this->SetFont('slb','',0);
		 //Color Cabecera Gris
		 $this->SetFillColor(240,240,240);	 
		 //Color Cabecera M-I SWACO
		 //$this->SetFillColor(255,110,0);
		 ////Color Cabecera SLB
		 //$this->SetFillColor(0,57,100);
		 //$this->SetTextColor(255,255,255);
	 //Color del texto de la cabecera
    $this->SetTextColor(0,0,0);
	 //Color de la linea de la cabecera
	 $this->SetDrawColor(233,233,233);
    //Ancho del borde (1 mm)
    $this->SetLineWidth(0.3);
    $this->SetFont('','',9);
    // Cabecera
	 
    $w = array(15, 97, 30, 20, 20, 20, 20, 33, 20);
    for($i=0;$i<count($header);$i++)
        $this->Cell($w[$i],8,$header[$i],1,0,'C',true);
		  //Color del textp del contenido
		  $this->SetTextColor(0,0,0);
}
}
 
$pdf=new PDF('L','mm','A4');
$pdf->AddFont('slbB','','slbBold.php');
$pdf->AddFont('slb','','normal.php');
$pdf->AddPage();
$pdf->AliasNbPages();
$pdf->SetFont('slbB','',8);
$pdf->SetXY(10, 24);
$pdf->Ln(20);
$pdf->SetFont('slbB','',9);
//Tabla 

$pdf->SetWidths(array(15, 147,40, 53,20));
$pdf->SetAligns(array('C', 'J', 'C', 'C', 'C'));

//Imprimir Header Tabla
$header = array('LINEA', 'LOTE', 'BULTO(S)', 'UNIDAD(ES)', 'RECIBIDO', 'MUESTRA', 'EMBALAJE', 'DOCUMENTO DE ENTREGA', 'TOTAL');
$pdf->FancyTable($header);
$pdf->Ln();
$pdf->SetFont('slb','',8);

//Imprimir contenido de la tabla
 do { $num ++;
 	$linea = $num;
	$desc= $row_agregados['Descripcion'];
	$odc= 'Orden de Compra: '.$row_agregados['Sol_Odc'];
	$solicitud= 'Solicitud/BOL: '.$row_agregados['Rec_Solicitud'];
	$total = $row_agregados['Total'];
	
	//Tabla 
	$pdf->SetWidths(array(15, 147,40, 53,20));
	$pdf->SetAligns(array('C', 'J', 'C', 'C', 'C'));
	$pdf->Row(array($linea, $desc, $odc,$solicitud,$total ));
	
//Consulta
mysql_select_db($database_conex, $conex);
$query_linea = "
SELECT Rec_Serial, Rec_Lote, Rec_Paleta, Rec_Cxu, Rec_Cantidad, Rec_Prueba, Rec_Embalaje, Rec_Entrega
FROM recepcion
WHERE Pro_Codigo =  '".$row_agregados['Pro_Codigo']."'
AND Rec_Solicitud = '".$row_agregados['Rec_Solicitud']."'
";
$linea = mysql_query($query_linea, $conex) or die(mysql_error());
$row_linea = mysql_fetch_assoc($linea);
$totalRows_linea = mysql_num_rows($linea);
	
	//lineas
	do {
		$lote = $row_linea['Rec_Lote'];
		$bulto = $row_linea['Rec_Paleta'];
		$unidades = $row_linea['Rec_Cxu'];
		$cantidad = $row_linea['Rec_Cantidad'];
		$muestra = $row_linea['Rec_Prueba'];
		$embalaje = $row_linea['Rec_Embalaje'];
		$entrega = $row_linea['Rec_Entrega'];
		
		$pdf->SetWidths(array(15, 97, 30, 20, 20, 20, 20, 33, 20));
		$pdf->SetAligns(array('C', 'J', 'C', 'C', 'C', 'C', 'C', 'C', 'C'));
		
		$pdf->Row(array('', $lote, $bulto, $unidades, $cantidad, $muestra, $embalaje, $entrega,''));
   } while ($row_linea = mysql_fetch_assoc($linea));  
	
} while ($row_agregados = mysql_fetch_assoc($agregados)); 	



//Crear el PDF
$NC= $_GET['recepcion']; 
$pdf->Output($row_Entrada['Alm_Codigo']." ".$NC,I);
?>
<?php
mysql_free_result($agregados);

mysql_free_result($usuario);

mysql_free_result($almacen);
?>
