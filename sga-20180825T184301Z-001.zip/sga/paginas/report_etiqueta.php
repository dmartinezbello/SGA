<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_detalles = "-1";
if (isset($_GET['codigo'])) {
  $colname_detalles = $_GET['codigo'];
}
mysql_select_db($database_conex, $conex);
$query_detalles = sprintf("SELECT Pro_Codigo, Pro_Nombre, Pro_Empaque, Pro_Peso, Pro_Unidad, Pro_Salud, Pro_Inflamabilidad, Pro_Reactividad, Pro_Proteccion FROM productos WHERE Pro_Codigo = %s", GetSQLValueString($colname_detalles, "text"));
$detalles = mysql_query($query_detalles, $conex) or die(mysql_error());
$row_detalles = mysql_fetch_assoc($detalles);
$totalRows_detalles = mysql_num_rows($detalles);$colname_detalles = "-1";
if (isset($_GET['codigo'])) {
  $colname_detalles = $_GET['codigo'];
}
$ea_detalles = "-1";
if (isset($_GET['recepcion'])) {
  $ea_detalles = $_GET['recepcion'];
}
mysql_select_db($database_conex, $conex);
$query_detalles = sprintf("SELECT Pro_Codigo, Pro_Nombre, Pro_Empaque, Pro_Peso, Pro_Unidad, Pro_Salud, Pro_Inflamabilidad, Pro_Reactividad, Pro_Proteccion, entrada.Ent_Fecha, entrada.Ent_Usuario FROM productos, entrada WHERE Pro_Codigo = %s AND entrada.Ent_Numero=%s", GetSQLValueString($colname_detalles, "text"),GetSQLValueString($ea_detalles, "text"));
$detalles = mysql_query($query_detalles, $conex) or die(mysql_error());
$row_detalles = mysql_fetch_assoc($detalles);
$totalRows_detalles = mysql_num_rows($detalles);
?>
<style type="text/css">
body{
	font-family: Arial, Helvetica, sans-serif;
	margin:0px; }
.fuente30 {
	font-size: 30px;
	font-weight: bold;
}

.fuente20 {
	font-size: 20px;
}
</style>

<table width="60%" border="0" align="center">
  <tr>
    <td width="300">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
    <td height="50" colspan="3" align="center" valign="top" class="fuente30"><?php echo $_GET['codigo']; ?></td>
    <td width="100">&nbsp;</td>
    <td width="130">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
    <td width="130">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="3" align="center" class="fuente20"><?php echo $row_detalles['Pro_Nombre']; ?></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td width="180">&nbsp;</td>
    <td width="180">&nbsp;</td>
    <td width="160" align="right" class="fuente30">&nbsp;</td>
    <td align="right" class="fuente30"><?php echo $row_detalles['Pro_Salud']; ?></td>
    <td class="fuente30">&nbsp;</td>
    <td height="80" class="fuente30">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="right" class="fuente30">&nbsp;</td>
    <td align="right" class="fuente30"><?php echo $row_detalles['Pro_Inflamabilidad']; ?></td>
    <td class="fuente28">&nbsp;</td>
    <td height="80" class="fuente28">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="right" class="fuente30">&nbsp;</td>
    <td align="right" class="fuente30"><?php echo $row_detalles['Pro_Reactividad']; ?></td>
    <td class="fuente28">&nbsp;</td>
    <td height="80" class="fuente28">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="right" class="fuente30">&nbsp;</td>
    <td align="right" class="fuente30"><?php echo $row_detalles['Pro_Proteccion']; ?></td>
    <td class="fuente28">&nbsp;</td>
    <td height="80" class="fuente28">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td>&nbsp;</td>
    <td height="40">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="center">&nbsp;</td>
    <td height="40" align="center"><?php echo $row_detalles['Ent_Fecha']; ?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td width="130">&nbsp;</td>
    <td width="130" height="50"><?php echo $row_detalles['Ent_Usuario']; ?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td height="50"><?php echo $row_detalles['Ent_Proveedor']; ?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td height="50"><?php echo $row_detalles['Pro_Empaque']; ?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="center" class="fuente20">&nbsp;</td>
    <td align="center" class="fuente20">&nbsp;</td>
    <td align="right" class="fuente20">&nbsp;</td>
    <td height="35" align="right" class="fuente20">x</td>
  </tr>
  <tr>
    <td height="60" colspan="7" align="center" valign="top"><span class="fuente20"><?php echo $_GET['lote']; ?></span></td>
  </tr>
  <tr>
    <td height="50" colspan="7" align="center"><span class="fuente30"><?php echo $_GET['uxp']; ?></span></td>
  </tr>
  <tr>
    <td height="50" colspan="7" align="center" class="fuente30"><?php echo $row_detalles['Pro_Peso']; ?> <?php echo $row_detalles['Pro_Unidad']; ?>s</td>
  </tr>
  <tr>
    <td colspan="7" class="fuente30" align="center"><?php $PBruto= $row_detalles['Pro_Peso'] * $_GET['uxp']; echo $PBruto;?> <?php echo $row_detalles['Pro_Unidad']; ?>s</td>
  </tr>
</table>
<?php
mysql_free_result($detalles);
?>
