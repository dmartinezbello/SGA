<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="iso-8859-2">
<title>.: SGA :.</title>
</head>
<frameset rows="84,*,5%" cols="*" frameborder="NO" border="0" framespacing="0">
  <frame src="cabecera.php" name="topFrame" scrolling="NO" noresize title="superior">
  <frameset cols="20%,*" framespacing="0" frameborder="no" border="0" bordercolor="#F0F0F0" >
    <frame src="izquierda.php" name="leftFrame" scrolling="NO" noresize title="izquierdo" style="border:1px solid #CCCCCC;">
    <frame src="cuerpo.php" name="mainFrame" title="cuerpo">
  </frameset>
<frame src="pie.php" name="pie" scrolling="NO" noresize title="pie"></frameset>
<noframes><body>
</body></noframes>
</html>
